make
sudo make install
sudo /etc/init.d/php5-fpm restart
