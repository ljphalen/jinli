<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class AboutController extends Client_BaseController {

    public $actions = array(
        'tjUrl' => '/index/tj'
    );

    public function indexAction() {
    	//客户端关于页面
    }
    
}