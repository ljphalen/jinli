<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * 日志上报域名首页
 * @author master
 *
 */
class IndexController extends Log_BaseController {

	/**
	 * 接口说明
	 */
	public function indexAction(){
		exit('Log upload system server v 1.0');
	}
}
