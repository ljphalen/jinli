<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Account_Cache_UserInfo
 * @author fanch
 *
*/
class Account_Cache_UserInfo extends Cache_Base{
	public $expire = 60;
}