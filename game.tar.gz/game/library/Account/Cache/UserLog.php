<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Account_Cache_UserLog
 * @author fanch
 *
*/
class Account_Cache_UserLog extends Cache_Base{
	public $expire = 60;
}