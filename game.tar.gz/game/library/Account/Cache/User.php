<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Account_Cache_User
 * @author fanch
 *
*/
class Account_Cache_User extends Cache_Base{
	public $expire = 60;
}