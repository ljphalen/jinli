<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Account_Dao_UserLog
 * @author fanch
 *
*/
class Account_Dao_UserLog extends Common_Dao_Base{
	protected $_name = 'game_user_log';
	protected $_primary = 'id';
}