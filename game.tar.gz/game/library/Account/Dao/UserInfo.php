<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Account_Dao_UserInfo
 * @author fanch
 *
*/
class Account_Dao_UserInfo extends Common_Dao_Base{
	protected $_name = 'game_user_info';
	protected $_primary = 'id';
}