<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Account_Dao_User
 * @author fanch
 *
*/
class Account_Dao_User extends Common_Dao_Base{
	protected $_name = 'game_user';
	protected $_primary = 'id';
}