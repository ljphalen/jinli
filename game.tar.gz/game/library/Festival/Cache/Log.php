<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * web广告Cache文件
 * web_Cache_Ad
 * @author tiansh
 *
 */
class Festival_Cache_Log extends Cache_Base{
	public $expire = 60;
}
