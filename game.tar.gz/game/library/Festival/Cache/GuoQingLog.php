<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class Festival_Cache_GuoQingLog extends Cache_Base{
	public $expire = 1;
}