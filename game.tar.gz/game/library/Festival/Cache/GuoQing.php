<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class Festival_Cache_GuoQing extends Cache_Base{
	public $expire = 1;
}