<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * H5 广告DAO 文件
 * Game_Dao_Ad
 * @author rainkid
 *
 */
class Festival_Dao_Log extends Common_Dao_Base{
	protected $_name = 'game_festival_log';
	protected $_primary = 'id';
}