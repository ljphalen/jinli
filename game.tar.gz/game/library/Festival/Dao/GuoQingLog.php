<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Festival_Dao_GuoQingLog
 * @author lichanghua
 *
 */
class Festival_Dao_GuoQingLog extends Common_Dao_Base{
	protected $_name = 'game_answer_log';
	protected $_primary = 'id';
}