<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * web广告DAO 文件
 * web_Dao_Ad
 * @author ljphalen
 *
 */
class Web_Dao_Ad extends Common_Dao_Base{
	protected $_name = 'web_ad';
	protected $_primary = 'id';
}