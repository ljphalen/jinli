<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Sdk_Cache_Ad
 * @author luojiapeng
 *
 */
class Sdk_Cache_Ad extends Cache_Base{
	public $expire = 60;
}
