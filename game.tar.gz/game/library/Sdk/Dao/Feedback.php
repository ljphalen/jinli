<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Sdk_Dao_Ad
 * @author luojiapeng
 * 
 */
class Sdk_Dao_Feedback extends Common_Dao_Base{
	protected $_name = 'game_sdk_feedback';
	protected $_primary = 'id';
	
}