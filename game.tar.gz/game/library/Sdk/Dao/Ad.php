<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Sdk_Dao_Ad
 * @author luojiapeng
 * 
 */
class Sdk_Dao_Ad extends Common_Dao_Base{
	protected $_name = 'game_sdk_ad';
	protected $_primary = 'id';
	
}