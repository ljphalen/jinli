<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Cache_ScoreLogs
 * @author fanch
 *
 */
class Resource_Cache_ScoreLogs extends Cache_Base{
	public $expire = 60;
}
