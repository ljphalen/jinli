<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Cache_Attribute
 * @author 
 *
 */
class Resource_Cache_Attribute extends Cache_Base{
	public $expire = 60;
}

