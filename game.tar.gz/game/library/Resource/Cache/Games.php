<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Cache_Games
 * @author 
 *
 */
class Resource_Cache_Games extends Cache_Base{
	public $expire = 60;
}

