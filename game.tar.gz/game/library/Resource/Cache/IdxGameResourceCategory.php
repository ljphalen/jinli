<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_IdxGameResourceCategory
 * @author lichanghua
 *
 */
class Resource_Cache_IdxGameResourceCategory extends Cache_Base{
	public $expire = 60;
}
