<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Cache_Category
 * @author lichanghau
 *
 */
class Resource_Cache_Category extends Cache_Base{
	public $expire = 60;
}