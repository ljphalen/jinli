<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_IdxGameResourceCategory
 * @author lichanghua
 *
 */
class Resource_Dao_IdxGameResourceCategory extends Common_Dao_Base{
	protected $_name = 'idx_game_resource_category';
	protected $_primary = 'id';
}
