<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_IdxGameResourceLabel
 * @author lichanghua
 *
 */
class Resource_Dao_IdxGameResourceLabel extends Common_Dao_Base{
	protected $_name = 'idx_game_resource_label';
	protected $_primary = 'id';
}
