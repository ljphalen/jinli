<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_Attribute
 * @author lichanghau
 *
 */
class Resource_Dao_Attribute extends Common_Dao_Base{
	protected $_name = 'game_resource_attribute';
	protected $_primary = 'id';
}
