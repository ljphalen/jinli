<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_ScoreLogs
 * @author fanch
 *
 */
class Resource_Dao_ScoreLogs extends Common_Dao_Base{
	protected $_name = 'game_resource_score_logs';
	protected $_primary = 'id';
}
