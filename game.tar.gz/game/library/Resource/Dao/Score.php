<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_Score
 * @author fanch
 *
 */
class Resource_Dao_Score extends Common_Dao_Base{
	protected $_name = 'game_resource_score';
	protected $_primary = 'id';
}
