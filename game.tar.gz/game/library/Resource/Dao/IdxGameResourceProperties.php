<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_IdxGameResourceProperties
 * @author lichanghua
 *
 */
class Resource_Dao_IdxGameResourceProperties extends Common_Dao_Base{
	protected $_name = 'idx_game_resource_properties';
	protected $_primary = 'id';
}
