<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_IdxGameResourceType
 * @author lichanghua
 *
 */
class Resource_Dao_IdxGameResourceType extends Common_Dao_Base{
	protected $_name = 'idx_game_resource_model';
	protected $_primary = 'id';
}
