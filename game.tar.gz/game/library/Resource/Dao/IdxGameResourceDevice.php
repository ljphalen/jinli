<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_IdxGameResourceDevice
 * @author lichanghua
 *
 */
class Resource_Dao_IdxGameResourceDevice extends Common_Dao_Base{
	protected $_name = 'idx_game_resource_device';
	protected $_primary = 'id';
}