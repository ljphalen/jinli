<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Resource_Dao_Img
 * @author rainkid
 *
 */
class Resource_Dao_Img extends Common_Dao_Base{
	protected $_name = 'game_resource_imgs';
	protected $_primary = 'id';
}