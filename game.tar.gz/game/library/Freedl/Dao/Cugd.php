<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Dao_Cugd
 * @author fanch
 *
 */
class Freedl_Dao_Cugd extends Common_Dao_Base{
	protected $_name = 'game_client_freedl_cugd';
	protected $_primary = 'id';
}