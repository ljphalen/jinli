<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Dao_IdxGameTmpFreedlHd
 * @author lichanghua
 *
 */
class Freedl_Dao_IdxGameTmpFreedlHd extends Common_Dao_Base{
	protected $_name = 'idx_game_client_freedl_tmp';
	protected $_primary = 'id';
}
