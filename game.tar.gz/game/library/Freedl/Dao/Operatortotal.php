<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Dao_Operatortotal
 * @author lichanghua
 *
 */
class Freedl_Dao_Operatortotal extends Common_Dao_Base{
	protected $_name = 'game_client_freedl_operatortotal';
	protected $_primary = 'id';
}
