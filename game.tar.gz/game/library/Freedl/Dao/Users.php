<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Dao_Users
 * @author lichanghua
 *
 */
class Freedl_Dao_Users extends Common_Dao_Base{
	protected $_name = 'game_client_freedl_users';
	protected $_primary = 'id';
	
	/**
	 *
	 * 根据参数统计流量消耗总数
	 * @param array $params
	 */
	public function getUsersList() {
		$sql = sprintf('SELECT *,count(region) AS num FROM %s GROUP BY region', $this->getTableName());
		return Db_Adapter_Pdo::fetchAll($sql);
	}
	
	public function getUsersCount() {
		$sql = sprintf('SELECT count(*) from (SELECT *,count(region) AS num FROM game_client_freedl_users GROUP BY region) as a', $this->getTableName());
		return Db_Adapter_Pdo::fetchCloum($sql, 0);
	}
}
