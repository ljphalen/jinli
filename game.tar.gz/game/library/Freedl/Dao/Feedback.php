<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Dao_Feedback
 * @author lichanghua
 *
 */
class Freedl_Dao_Feedback extends Common_Dao_Base{
	protected $_name = 'game_client_freedl_feedback';
	protected $_primary = 'id';
}
