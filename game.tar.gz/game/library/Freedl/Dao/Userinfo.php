<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Dao_Userinfo
 * @author lichanghua
 *
 */
class Freedl_Dao_Userinfo extends Common_Dao_Base{
	protected $_name = 'game_client_freedl_userinfo';
	protected $_primary = 'id';
	
	
	/**
	 *
	 * 根据参数统计流量消耗总数
	 * @param array $params
	 */
	public function getCount($params = array()) {
		$where = Db_Adapter_Pdo::sqlWhere($params);
		$sql = sprintf('SELECT SUM(consume) FROM %s WHERE %s', $this->getTableName(), $where);
		return Db_Adapter_Pdo::fetchCloum($sql, 0);
	}
	
	/**
	 * 查询同一个iccid同一个活动当天每个游戏的下载次数
	 * @param string $iccid iccid
	 * @param string $activityId 活动id
	 */
	public function getDlTimes($iccid, $activityId, $startTime = 0){
		$sql = sprintf("SELECT `game_id`, COUNT(`task_flag`) AS dltimes FROM %s WHERE `iccid`='%s' AND `activity_id`=%s AND TO_DAYS(FROM_UNIXTIME(`create_time`)) = TO_DAYS(now())", $this->getTableName(), $iccid, $activityId);
		if($startTime) $sql.=' AND create_time > ' . $startTime;
		$sql.=' GROUP BY `game_id`';
		return Db_Adapter_Pdo::fetchAll($sql);
	}
	
	/**
	 * 查询特定iccid用户指定活动中流量记录
	 * @param string $iccid
	 * @param string $activityId
	 * @param number $type
	 * @return string
	 */
	public function getTraffic($iccid, $activityId, $type, $startTime = 0){
		switch ($type){
			case 1://当前小时
				$where = 'FROM_UNIXTIME(`refresh_time`, "%Y%m%d%H") = FROM_UNIXTIME(UNIX_TIMESTAMP(), "%Y%m%d%H")';
				break;
			case 2://当天
				$where = 'FROM_UNIXTIME(`refresh_time`, "%Y%m%d") = FROM_UNIXTIME(UNIX_TIMESTAMP(), "%Y%m%d")';
				break;
			case 3://当月
				$where = 'FROM_UNIXTIME(`create_time`, "%Y%m") = FROM_UNIXTIME(UNIX_TIMESTAMP(), "%Y%m")';
				break;
		}
		if($startTime) $where.=' AND create_time > ' . $startTime;
		
		$sql = sprintf("SELECT SUM(`consume`) FROM %s WHERE `iccid`='%s' AND `activity_id`=%s AND %s", $this->getTableName(), $iccid, $activityId, $where);
		return Db_Adapter_Pdo::fetchCloum($sql, 0);
	}
}
