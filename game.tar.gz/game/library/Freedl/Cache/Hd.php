<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Cache_Hd
 * @author lichanghua
 *
 */
class Freedl_Cache_Hd extends Cache_Base{
	public $expire = 0;
}