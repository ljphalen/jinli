<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Freedl_Service_Permission
 * 免流量涉及的权限service
 * @author fanch
 *
 */
class Freedl_Service_Permission extends Common_Service_Base{
	
	/**
	 * 检查免流量活动是否有效
	 * @param unknown_type $iccid
	 * @return number
	 */
	public static function checkActivity($iccid, $activityId = 0) {
		if (!$iccid) return array();
		
		$icc_arr = Freedl_Service_IccidConvert::convert($iccid);
		$operator = current($icc_arr);
		
		$params = array();
		$params['status'] = 1;
		$params['start_time'] = array('<=', Common::getTime());
		$params['end_time'] = array('>=', Common::getTime());
		//中国移动活动
		if($operator == 'cmcc')  $params['htype'] = 1;
		//中国联通
		if($operator == 'cu')  $params['htype'] = 2;
		
		if($activityId)  $params['id'] = $activityId;
		$info = Freedl_Service_Hd::getByFreedl($params, array('id'=>'DESC','start_time'=>'DESC'));
		if($info) return $info;
		return array();
	}
	
	/**
	 * 检查是否为黑名单用户
	 * @param unknown_type $iccid
	 * @param unknown_type $uname
	 * @param unknown_type $imei
	 */
	public static function checkBlacklist($iccid,$uuid,$imei) {
		$cache = Common::getCache();
		$ckey = '-freedl-black';
		$data = $cache->get($ckey);
		if(!$data['iccid'] && !$data['uuid'] && !$data['imei']){
			//缓存没值，先设置缓存值
			$data = array(
					'iccid'=> self::_getBlackData($type=1),
					'uuid'=> self::_getBlackData($type=2),
					'imei'=> self::_getBlackData($type=3)
			);
			$cache->set($ckey, $data, 60*60*24);
		}
		if(in_array($iccid, $data['iccid']) && $data) return 1;
		if(in_array($uuid, $data['uuid']) && $data) return 1;
		if(in_array($imei, $data['imei']) && $data) return 1;
		return 0;
	}
	
	/**
	 * 检查是否为已经领取
	 * @param unknown_type $iccid
	 * @param unknown_type $uname
	 * @param unknown_type $imei
	 */
	public static function checkReceive($iccid, $activityId) {
		$cache = Common::getCache();
		$ckey = '-freedl-rec' . $activityId . '-' . $iccid;
		$cdata = $cache->get($ckey);
		if($cdata == false){
			$params = array();
			$params['iccid'] = $iccid;
			$params['activity_id'] = $activityId;
			$ret = Freedl_Service_Receive::getBy($params);
			$cdata = ($ret) ? 1 : 0;
			$cache->set($ckey, $cdata, 1*24*60*60);//cache数据为1天有效
		}
		return $cdata;
	}
	
	/**
	 * 按照iccid | uuid | imei 查找黑名单数据
	 * @param int $type
	 */
	private static function _getBlackData($type) {
		$tmp = array();
		$ret = Freedl_Service_Blacklist::getsByBlacklist(array('status'=>1,'utype'=>$type));
		foreach($ret as $key=>$value){
			if($type == 1) {
				$tmp[]= $value['iccid'];
			} else if($type == 2){
				$userInfo = Account_Service_User::getUser(array('uname'=>$value['uname']));
				$tmp[]= $userInfo['uuid'];
			} else {
				$tmp[]= $value['imei'];
			}
		}
		return $tmp;
	}
	
	/**
	 * 更新黑名单缓存
	 * @param array $data
	 * @param int $type
	 * @param boolen $status
	 * @return boolean
	 */
	public static function setBlackData($data, $type, $status) {
		$cache = Common::getCache();
		$ckey = '-freedl-black';
		$cdata = $cache->get($ckey);
		if(!$cdata['iccid'] && !$cdata['uuid'] && !$cdata['imei']){
			//缓存没值，先设置缓存值
			$cdata = array(
					'iccid'=> self::_getBlackData($type=1),
					'uuid'=> self::_getBlackData($type=2),
					'imei'=> self::_getBlackData($type=3)
			);
		}
		//添加iccid,uuid,imei到缓存中
		if(!in_array($data['iccid'], $cdata['iccid']) && $type == 1 && $status ==1) array_push($cdata['iccid'], $data['iccid']);
		if(!in_array($data['uuid'], $cdata['uuid']) && $type == 2 && $status == 1) array_push($cdata['uuid'], $data['uuid']);
		if(!in_array($data['imei'], $cdata['imei']) && $type == 3 && $status ==1) array_push($cdata['imei'], $data['imei']);
		//从缓存中移除iccidiccid,uuid,imei
		if(in_array($data['iccid'], $cdata['iccid']) && !$status && $type == 1) $cdata['iccid'] = self::_getArrayData($data['iccid'], $cdata['iccid']);
		if(in_array($data['uuid'], $cdata['uuid']) && !$status && $type == 2) $cdata['uuid'] = self::_getArrayData($data['uuid'], $cdata['uuid']);
		if(in_array($data['imei'], $cdata['imei']) && !$status && $type == 3) $cdata['imei'] = self::_getArrayData($data['imei'], $cdata['imei']);
		$cache->set($ckey, $cdata, 60*60*24);
		return true;
	}
	
	/**
	 * 删除数组中某个值
	 * @param array $data
	 * @param string $value
	 * @param boolen $type
	 */
	private static function _getArrayData($value, $data) {
		foreach($data as $k=>$v){
			if(in_array($value, $data)) unset($data[$k]);
		}
		return $data;
	}
	
	/**
	 * 通过sp参数解析机型，sdk版本，android版本
	 * @param string $sp
	 * @return array
	 */
	public static function getConvertSpData($sp) {
		$arr_sp = explode("_", $sp);
		//获取机型
		$mode = $arr_sp[0];
		//获取sdk版本
		$version = $arr_sp[1];
		//获取android版本
		$sys_version = substr($arr_sp[3],7);
		return array($mode, $version, $sys_version);
	}
	
	/**
	 * 检查是否为已经领取
	 * @param unknown_type $iccid
	 * @param unknown_type $uname
	 * @param unknown_type $imei
	 */
	public static function addReceive($iccid,$uname,$uuid,$imei,$activityId,$sp,$client_pkg) {
		$userInfo = Account_Service_User::getUserInfo(array('uname'=>$uname));
		$sp_arr = self::getConvertSpData($sp);
		$client_pkg = 2;
		if($client_pkg == "com.android.amigame") {
			$client_pkg = 1;
		}
		$data = array(
					'id'=>'',
					'activity_id'=>$activityId,
					'iccid'=>$iccid,
					'uuid'=>$uuid,
					'imei'=>$imei,
					'uname'=>$uname,
					'nickname'=>$userInfo['nickname'],
					'model'=>$sp_arr[0],
					'client_pkg'=>$client_pkg,
					'version'=>$sp_arr[1],
					'sys_version'=>$sp_arr[2],
					'create_time'=>Common::getTime(),
			);
		$ret = Freedl_Service_Receive::add($data);
		return $ret;
	}
}