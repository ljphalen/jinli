<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Bbs_Dao_Bbs
 * @author luojiapeng
 * 
 */
class Bbs_Dao_Bbs extends Common_Dao_Base{
	protected $_name = 'game_bbs';
	protected $_primary = 'id';
	
}