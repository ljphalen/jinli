<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Sdk_Cache_Bbs
 * @author luojiapeng
 *
 */
class Bbs_Cache_Bbs extends Cache_Base{
	public $expire = 60;
}
