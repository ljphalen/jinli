<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * @author lichanghau
 *
 */
class Game_Dao_GamePrice extends Common_Dao_Base{
	protected $_name = 'game_price';
	protected $_primary = 'id';
}