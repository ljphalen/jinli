<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * H5 广告DAO 文件
 * Game_Dao_Ad
 * @author rainkid
 *
 */
class Game_Dao_Ad extends Common_Dao_Base{
	protected $_name = 'game_ad';
	protected $_primary = 'id';
}