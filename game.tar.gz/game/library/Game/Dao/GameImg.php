<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Dao_Ad
 * @author rainkid
 *
 */
class Game_Dao_GameImg extends Common_Dao_Base{
	protected $_name = 'games_imgs';
	protected $_primary = 'id';
}