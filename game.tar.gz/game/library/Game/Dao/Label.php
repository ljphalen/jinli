<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * @author lichanghau
 *
 */
class Game_Dao_Label extends Common_Dao_Base{
	protected $_name = 'game_label';
	protected $_primary = 'id';
}