<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Dao_IdxGameLabel
 * @author lichanghua
 *
 */
class Game_Dao_IdxGameLabel extends Common_Dao_Base{
	protected $_name = 'idx_game_label';
	protected $_primary = 'id';
}
