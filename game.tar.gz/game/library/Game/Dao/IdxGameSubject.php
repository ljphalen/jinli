<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Dao_IdxGameSubject
 * @author lichanghua
 *
 */
class Game_Dao_IdxGameSubject extends Common_Dao_Base{
	protected $_name = 'idx_game_subject';
	protected $_primary = 'id';
}
