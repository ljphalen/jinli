<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Cache_Game
 * @author tiansh
 *
 */
class Game_Cache_Game extends Cache_Base{
	public $expire = 60;
}
