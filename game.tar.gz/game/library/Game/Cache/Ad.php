<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * web广告Cache文件
 * web_Cache_Ad
 * @author tiansh
 *
 */
class Game_Cache_Ad extends Cache_Base{
	public $expire = 60;
}
