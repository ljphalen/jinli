<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Cache_Subject
 * @author tiansh
 *
 */
class Game_Cache_Subject extends Cache_Base{
	public $expire = 60;
}
