<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_FateRule
 * @author rainkid
 *
 */
class Client_Cache_FateRule extends Cache_Base{
	public $expire = 60;
}