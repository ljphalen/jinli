<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Giftlog
 * @author lichanghua
 *
 */
class Client_Cache_Giftlog extends Cache_Base{
	public $expire = 60;
}