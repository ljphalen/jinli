<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Recommend
 * @author lichanghua
 *
 */
class Client_Cache_Recommend extends Cache_Base{
	public $expire = 60;
}
