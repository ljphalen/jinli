<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Game
 * @author 
 *
 */
class Client_Cache_Game extends Cache_Base{
	public $expire = 60;
}
