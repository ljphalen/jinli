<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Column
 * @author fanch
 *
 */
class Client_Cache_Column extends Cache_Base{
	public $expire = 60;
}
