<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Installe
 * @author lichanghau
 *
 */
class Client_Cache_Installe extends Cache_Base{
	public $expire = 60;
}