<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Hd
 * @author lichanghua
 *
 */
class Client_Cache_Hd extends Cache_Base{
	public $expire = 60;
}