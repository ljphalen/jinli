<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Subject
 * @author tiansh
 *
 */
class Client_Cache_Subject extends Cache_Base{
	public $expire = 60;
}
