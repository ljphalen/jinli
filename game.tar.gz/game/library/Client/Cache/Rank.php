<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Rank
 * @author lichanghua
 *
 */
class Client_Cache_Rank extends Cache_Base{
	public $expire = 60;

	public function getMostGames($limit,$date) {
		$args = func_get_args();
		return call_user_func_array(array($this->_getDao(), __FUNCTION__), $args);
	}

	public function getMostGamescount($limit,$date) {
		$args = func_get_args();
		return call_user_func_array(array($this->_getDao(), __FUNCTION__), $args);
	}
}
