<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Gift
 * @author 
 *
 */
class Client_Cache_Gift extends Cache_Base{
	public $expire = 60;
}
