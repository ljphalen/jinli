<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_IdxGameClientBesttj
 * @author lichanghua
 *
 */
class Client_Cache_IdxGameClientBesttj extends Cache_Base{
	public $expire = 60;
}

