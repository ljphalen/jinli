<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Tuijian
 * @author lichanghau
 *
 */
class Client_Cache_Tuijian extends Cache_Base{
	public $expire = 60;
}
