<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Taste
 * @author lichanghua
 *
 */
class Client_Cache_Taste extends Cache_Base{
	public $expire = 60;
}
