<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_FateLog
 * @author rainkid
 *
 */
class Client_Cache_FateLog extends Cache_Base{
	public $expire = 60;
	
	public function groupBy($params){
		$args = func_get_args();
		return call_user_func_array(array($this->_getDao(), __FUNCTION__), $args);
	}
}
