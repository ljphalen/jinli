<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Ad
 * @author tiansh
 *
 */
class Client_Cache_Ad extends Cache_Base{
	public $expire = 60;
}
