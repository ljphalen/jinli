<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Cache_Category
 * @author tiansh
 *
 */
class Client_Cache_Category extends Cache_Base{
	public $expire = 60;
}
