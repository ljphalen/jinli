<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Dao_Tuijian
 * @author lichanghau
 *
 */
class Client_Dao_Tuijian extends Common_Dao_Base{
	protected $_name = 'idx_game_client_news';
	protected $_primary = 'id';
}
