<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_IdxGameClientSubject
 * @author lichanghua
 *
 */
class Client_Dao_IdxGameClientSubject extends Common_Dao_Base{
	protected $_name = 'idx_game_client_subject';
	protected $_primary = 'id';
}
