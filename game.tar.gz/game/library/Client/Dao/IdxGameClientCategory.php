<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_IdxGameClientCategory
 * @author lichanghua
 *
 */
class Client_Dao_IdxGameClientCategory extends Common_Dao_Base{
	protected $_name = 'idx_game_client_category';
	protected $_primary = 'id';
}
