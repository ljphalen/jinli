<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Ad
 * @author lichanghua
 * 8.20 改造
 */
class Client_Dao_Ad extends Common_Dao_Base{
	protected $_name = 'game_client_ad';
	protected $_primary = 'id';
	
}