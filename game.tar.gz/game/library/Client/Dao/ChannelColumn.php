<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 *
 * Client_Dao_ChannelColumn
 * @author fanch
 *
*/
class Client_Dao_ChannelColumn extends Common_Dao_Base{
	protected $_name = 'game_client_channel_column';
	protected $_primary = 'id';
}