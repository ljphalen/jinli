<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Column
 * @author luojiapeng
 *
 */
class Client_Dao_ColumnLog extends Common_Dao_Base{
	protected $_name = 'game_client_column_log';
	protected $_primary = 'id';	
}