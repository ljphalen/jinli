<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_CommentLog
 * @author lichanghua
 *
 */
class Client_Dao_CommentLog extends Common_Dao_Base{
	protected $_name = 'game_client_comment_log';
	protected $_primary = 'id';	
}