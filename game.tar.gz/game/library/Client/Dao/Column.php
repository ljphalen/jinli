<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Column
 * @author rainkid
 *
 */
class Client_Dao_Column extends Common_Dao_Base{
	protected $_name = 'game_client_column';
	protected $_primary = 'id';	
}