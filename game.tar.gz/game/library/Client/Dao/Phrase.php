<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Phrase
 * @author lichanghua
 *
 */
class Client_Dao_Phrase extends Common_Dao_Base{
	protected $_name = 'game_client_phrase';
	protected $_primary = 'id';
}
