<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Comment
 * @author lichanghau
 *
 */
class Client_Dao_Comment extends Common_Dao_Base{
	protected $_name = 'game_client_comment';
	protected $_primary = 'id';	
}