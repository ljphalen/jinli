<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Activity
 * @author lichanghua
 *
 */
class Client_Dao_Activity extends Common_Dao_Base{
	protected $_name = 'game_client_activity';
	protected $_primary = 'id';
	
}