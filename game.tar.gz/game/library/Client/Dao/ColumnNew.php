<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Column
 * @author luojiapeng
 *
 */
class Client_Dao_ColumnNew extends Common_Dao_Base{
	protected $_name = 'game_client_column_new';
	protected $_primary = 'id';	
}