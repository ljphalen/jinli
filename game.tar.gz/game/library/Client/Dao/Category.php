<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Category
 * @author lichanghua
 *
 */
class Client_Dao_Category extends Common_Dao_Base{
	protected $_name = 'game_client_category';
	protected $_primary = 'id';

}
