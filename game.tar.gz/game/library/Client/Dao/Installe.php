<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Installe
 * @author lichanghau
 *
 */
class Client_Dao_Installe extends Common_Dao_Base{
	protected $_name = 'game_client_installe';
	protected $_primary = 'id';
}
