<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Game_Dao_Subject
 * @author lichanghau
 *
 */
class Client_Dao_Subject extends Common_Dao_Base{
	protected $_name = 'game_client_subject';
	protected $_primary = 'id';
}
