<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Taste
 * @author lichanghua
 *
 */
class Client_Dao_Taste extends Common_Dao_Base{
	protected $_name = 'idx_game_client_taste';
	protected $_primary = 'id';
}
