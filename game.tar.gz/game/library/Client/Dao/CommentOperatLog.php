<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_CommentOperatLog
 * @author lichanghua
 *
 */
class Client_Dao_CommentOperatLog extends Common_Dao_Base{
	protected $_name = 'game_client_comment_operat_log';
	protected $_primary = 'id';	
}