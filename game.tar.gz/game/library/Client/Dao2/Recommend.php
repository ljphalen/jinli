<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Client_Dao_Recommend
 * @author lichanghua
 *
 */
class Client_Dao_Recommend extends Common_Dao_Base{
	protected $_name = 'dlv_game_recomend';
	protected $_primary = 'id';
	
	/**
	 *
	 * @param unknown_type $start
	 * @param unknown_type $limit
	 * @param unknown_type $params
	 * del ok
	 */
	public function getCanUseGames($params, $start, $limit) {
		$where = Db_Adapter_Pdo::sqlWhere($params).$sql;
		$sql = sprintf('SELECT * FROM %s WHERE 1 %s AND %s ORDER BY id DESC LIMIT %d,%d',$this->getTableName(), $where ,$start, $limit);
		return $this->fetcthAll($sql);
	}
	
	/**
	 *
	 * @param unknown_type $start
	 * @param unknown_type $limit
	 * @param unknown_type $params
	 * del ok
	 */
	public function getCanUseGamesCount($params) {
		$where = Db_Adapter_Pdo::sqlWhere($params).$sql;
		$sql = sprintf('SELECT COUNT(*) FROM %s WHERE 1 %s AND %s',$this->getTableName(), $where);
		return Db_Adapter_Pdo::fetchCloum($sql, 0);
	}
	
	//ok
	public function turncateRecommend() {
		$sql = sprintf('TRUNCATE %s',$this->getTableName());
		return Db_Adapter_Pdo::execute($sql, array(), false);
	}
}
