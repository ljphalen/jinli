<?php
include 'common.php';
/**
 *基于流量上报日志汇总数据
 */
 //初始化原始日志表数据  --  获取要处理的表数据
 $item = Glog_Service_FreedlProgress::getBy(array('status'=>0), array('create_time'=>'asc'));
 //没有日志记录
 if(empty($item)) exit('not progress data');
 $tableName = 'freedl_log_' . $item['table_ymd'];
 $startPos = $item['progress_id'];
 $limit = 10;
 $logs = Glog_Service_TrafficLog::getLimit($tableName, array('id' => array('>', $startPos)), $limit); //每次获取10条原始日志做处理
if(empty($logs)) exit('not found logs');
foreach ($logs as $value){
	//数据汇总处理
	list($ret, $black) = Freedl_Service_Process::cronHandle($value);
	//有异常的数据丢弃
	if(!$ret) continue;
	//处理黑名单用户数据
	if($black) Freedl_Service_Process::addFreedlBlackCache($value['iccid']);
	//更新用户流量消耗cache数据
	Freedl_Service_Process::updateFreedlUserCache($value['iccid'], $value['upload_size']);
	//更新日志处理进度表数据
	Glog_Service_FreedlProgress::updateBy(array('progress_id' => $value['id']), array('id' => $item['id']));
	//已汇总的活动下载量缓存清零
	$ckey = 'freedl_pv_' . $value['activity_id'];
	Common::getCache()->delete($ckey);
	echo "freedl_log_{$value['id']}----ok\r\n";
	sleep(1);
}

//处理表非今日的表数据做处理完整状态的校验
if($item['table_ymd'] != date('Ymd')){
	$gret = Glog_Service_FreedlProgress::getBy(array('id' => $item['id'], 'status'=>0));
	if($gret && ($gret['last_id'] == $gret['process_id'])){
		//更新日志表处理完成为态
		Glog_Service_FreedlProgress::updateBy(array('status'=>1), array('id'=>$gret['id']));
	}
}
echo CRON_SUCCESS;