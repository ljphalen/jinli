<?php
include 'common.php';
/**
 *update game_resource_games version_code
 */

list(,$gifts) = Client_Service_Gift::getAllGift();
foreach($gifts as $key=>$value) {
	//剩余礼包数量
	$remain_nums = Client_Service_Giftlog::getGiftlogByStatus(0,$value['id']);
	//已经抢过的礼包数量
	$nums = Client_Service_Giftlog::getGiftlogByStatus(1,$value['id']);
	//更新礼包表新增礼包总数量(nums)和剩余礼包数量(remain_nums)
	$ret = Client_Service_Gift::updateGift(array('nums'=>($nums + $remain_nums),'remain_nums'=>$remain_nums),$value['id']);
}

echo CRON_SUCCESS;