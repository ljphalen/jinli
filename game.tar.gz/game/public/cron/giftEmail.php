<?php
include 'common.php';

//获取队列的key值
$data =  json_decode(Common::getQueue()->pop('game_gift'),TRUE);
if($data){
	$body = '游戏ID为"'.$data['game_id'].'"的"'.$data['game_name'].'"游戏，发布的礼包名称为"'.$data['gift_name'].'" 还剩余的数量为："'.$data['remain_gifts'].'"个，请及时添加。';
	$ret  = Common::sendEmail('礼包警告',$body,$data['email']);
	echo CRON_SUCCESS;
	exit;
}
