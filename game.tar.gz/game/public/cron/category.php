<?php
include 'common.php';
/**
 *变更游戏分类信息
 */

$webroot = Common::getWebRoot();
list($total,$games) = Resource_Service_Games::getAllResourceGames();
$dataPath = Common::getConfig('siteConfig', 'dataPath');
$path = $dataPath.'/c3.csv';

$file = fopen($path,'r+');
$data = array();
while ($data = fgetcsv($file)) {
	$gameId = $data[0];
	$categoryId = $data[1];
	$network = $data[2];
	modifyC($gameId, $categoryId);
	modifyN($gameId,$network);
	echo "{$gameId}--->ok\r\n";
}
fclose($file);

function modifyC($gameId, $categoryId){
	//修改分类
	$categoryDao = Common::getDao("Resource_Dao_IdxGameResourceCategory");
	$allCategpry = $categoryDao->getsBy(array('game_id'=>$gameId));
	//多条记录，第一条记录修改，其他删除。
	$i=1;
	foreach ($allCategpry as $key=>$value){
		if($i==1){
			//修改
			$categoryDao->updateBy(array('category_id'=>$categoryId), array('id'=>$value['id']));
		}else{
			//删除
			$categoryDao->deleteBy(array('id'=>$value['id']));
		}
		$i++;
	}
}

function modifyN($gameId, $network){
	//修改联网类型
	$btype='103';//线上联网类型为103
	$labelDao = Common::getDao("Resource_Dao_IdxGameResourceLabel");
	$allNet = $labelDao->getsBy(array('btype' => $btype, 'game_id' => $gameId));
	//多条记录，第一条记录修改，其他删除。
	$i=1;
	foreach ($allNet as $key=>$value){
		if($i==1){
			//修改
			$labelDao->updateBy(array('label_id' => $network), array('id' => $value['id']));
		}else{
			//删除
			$labelDao->deleteBy(array('id' => $value['id']));
		}
		$i++;
	}
}
