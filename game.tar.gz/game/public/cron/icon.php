<?php
include 'common.php';

function getAppData($id){
	$url = sprintf('http://dev.game.gionee.com/api/get?appid=%s', $id);
	$curl = new Util_Http_Curl($url);
	$response = $curl->get();
	$tmp = array();
	$tmp = json_decode($response, true);
	$result = explode('|', $tmp['data']['icon']);
	return $result;		
}
//icon 图片顺序混乱修复。
$startTime = '1412870400'; //2014-10-10 00:00:00
$dbDao = Common::getDao("Resource_Dao_Games");
$ret = $dbDao->getsBy(array('online_time' => array('>', $startTime),'status'=>1));
foreach ($ret as $value){
	//通过接口获取appid的数据
	$icons = getAppData($value['appid']);
	$data = array(
			'img'=> $icons[0],
    		'mid_img'=> $icons[1],
			'big_img'=> $icons[2]
	 );
	$item = Resource_Service_Games::updateResourceGames($data, $value['id']);
	//更新icons数据
	if($item) echo "{$value['id']}--->ok\r\n";
}
echo CRON_SUCCESS;