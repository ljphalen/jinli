<?php
include 'common.php';
/**
 *处理游戏同步队列中操作触发的联通免流量操作
 *
 */
$item = Common::getQueue()->pop('GSQ:cugd-notify');
if($item){
	//数据转换
	$item = json_decode($item, true);
	$gid = $item['data']['gameid'];
	switch ($item['action']){
		case 'CU_ADDGAME':
			//增加新游戏
			$game = Resource_Service_Games::getGameAllInfo(array('id'=>$gid), false, false);
			$resquest = Freedl_Service_Cugd::fillData($game);
			$ret = Api_Freedl_Cu_Gd::addcontent($resquest);
			if($ret['errcode']=='0') {
				//构造联通免流量资源库数据
				$data = array(
						'game_id'=> $gid,
						'app_id' => $game['appid'],
						'version' => $game['version'],
						'version_code' => $game['version_code'],
						'content_id' => $ret['resultData']['contentId'],
						'cu_status' => 1,
						'create_time' => Common::getTime(),
				);
				//增加记录到免流量资源表
				Freedl_Service_Cugd::addCugd($data);
			}
			echo "CU_ADDGAME-game:{$gid}-ok\r\n";
			break;
		case 'CU_UPDATEGAME':
			//获取要更新的免流量资料信息
			$item = Freedl_Service_Cugd::getBy(array('game_id' => $gid));
			if(!$item) exit('cugame not found');
			//构造联通免流量游戏更新游戏数据
			$game = Resource_Service_Games::getGameAllInfo(array('id'=>$gid), false, false);
			$resquest = Freedl_Service_Cugd::fillData($game);
			$ret = Api_Freedl_Cu_Gd::updatecontent($item['content_id'], $gid, $resquest);
			if($ret['errcode']=='0') {
				//获取非线上版本的免流量游戏，确保该游戏有且仅有一条处于待审核的更新对应数据
				$cugame = Freedl_Service_Cugd::getBy(array('game_id' => $gid, 'online_flag' => 0));
				if($cugame){
					//构造更新联通免流量资源库数据
					$data = array(
							'version' => $game['version'],
							'version_code' => $game['version_code'],
							'cu_status' => 1,
							'create_time' => Common::getTime(),
					);
					//更新记录到免流量资源表
					Freedl_Service_Cugd::updateCugd($data, array('id' => $ret['id']));
				}else{
					//构造一条处于未上线的免流量游戏数据到联通内容库中
					$data = array(
						'game_id'=> $gid,
						'app_id' => $game['appid'],
						'version' => $game['version'],
						'version_code' => $game['version_code'],
						'content_id' => $ret['resultData']['contentId'],
						'cu_status' => 1,
						'create_time' => Common::getTime(),
					);
					//增加记录到免流量资源表
					Freedl_Service_Cugd::addCugd($data);
				}
			}
			echo "CU_UPDATEGAME-game:{$gid}-ok\r\n";
			break;
		case 'CU_OFFGAME':
			//关闭游戏
			//获取线上的版本记录
			$cugame = Freedl_Service_Cugd::getBy(array('game_id' => $gid, 'online_flag' => 1));
			//发送游戏下线请求到联通免流量接口
			$ret = Api_Freedl_Cu_Gd::updatestatus($cugame['content_id'], $gid, 'invalid');
			if($ret['errcode']=='0') {
				//更新免流量游戏对应资源数据
				Freedl_Service_Cugd::updateCugd(array('status'=> '0', 'cu_status' => '5'), array('game_id' => $ret['id']));
			}
			echo "CU_OFFGAME-game:{$gid}-ok\r\n";
			break;
	}
}
echo CRON_SUCCESS;