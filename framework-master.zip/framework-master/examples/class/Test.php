<?php
namespace BL;

class Test
{
    static function test1($str)
    {
        return "hello-soa-finish: $str";
    }

    static function hello()
    {
        return array('key1' => 'A', 'key2' => 'B');
    }
}