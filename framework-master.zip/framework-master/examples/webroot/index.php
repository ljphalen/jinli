<?php
Swoole::$php->http->header('Gateway-Interface', 'PHP-5.4.6');
echo "<h1>hello world</h1>";
