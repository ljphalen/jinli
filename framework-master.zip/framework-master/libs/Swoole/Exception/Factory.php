<?php
namespace Swoole\Exception;

class Factory extends \Exception
{

}