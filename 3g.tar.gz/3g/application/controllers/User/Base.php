<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * User_BaseController
 * @author tiansh
 *
 */
class User_BaseController extends Common_BaseController {
	public $userInfo;
	public $actions = array();

	public function init() {
		parent::init();
		$staticroot = Yaf_Application::app()->getConfig()->staticroot;
		$webroot    = Common::getCurHost();
		$controller = $this->getRequest()->getControllerName();
		$this->assign("webroot", $webroot);
		$this->assign("staticSysPath", $staticroot . '/sys');
		$this->assign("staticResPath", $staticroot . '/apps/3g');
		$this->checkRight();
		$this->checkToken();

		foreach ($this->actions as $key => $value) {
			$this->assign($key, $value . "?t_bi=" . $this->getSource());
		}

		$this->defaultAction(true);

		//PV统计
		Common::getCache()->increment('3g_pv');

		if (Gionee_Service_User::getToday()) {
			Common::getCache()->increment('3g_uv');
		}
	}
	
	public function getSource() {
		return Util_Cookie::get('3G-SOURCE', true);
	}

	public function checkRight() {
		$this->userInfo = Gionee_Service_User::isLogin();
		$module         = $this->getRequest()->getModuleName();
		$controller     = $this->getRequest()->getControllerName();
		$action         = $this->getRequest()->getActionName();

		if (!$this->userInfo && !$this->inLoginPage()) {
			$webroot = Common::getCurHost();
			$url     = sprintf("%s/user/login/index?refer=%s", $webroot, $webroot . '/' . $module . '/' . $controller . '/' . $action);
			$this->redirect($url);
		}
	}

	public function inLoginPage() {
		$module     = $this->getRequest()->getModuleName();
		$controller = $this->getRequest()->getControllerName();
		$action     = $this->getRequest()->getActionName();

		if ($module == 'User' && ($controller == 'Login' || $controller == 'Register' || ($controller == 'Index' && ($action = 'signin' || $action == 'signin_post')))) {
			return true;
		}
		return false;
	}

	/**
	 * 检查token
	 */
	protected function checkToken() {
		if (!$this->getRequest()->isPost()) {
			return true;
		}
		$post   = $this->getRequest()->getPost();
		$result = Common::checkToken($post['token']);
		if (Common::isError($result)) {
			$this->output(-1, $result['msg']);
		}
		return true;
	}

	/**
	 * @param int $code
	 * @param string $msg
	 * @param string $data
	 */
	public function output($code, $msg = '', $data = array()) {
		exit(json_encode(array(
			'success' => $code == 0 ? true : false,
			'msg'     => $msg,
			'data'    => $data
		)));
	}
}
