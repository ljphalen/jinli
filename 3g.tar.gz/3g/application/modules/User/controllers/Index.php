<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *用户中心首页
 */
class IndexController extends User_BaseController {

	public $actions = array(

	);

	public function indexAction(){
		$login =Common_Service_User::checkLogin('/user/index/index');//检测用户是否登陆
		if($login['key'] =='0') $this->redirect($login['msg']);

		Gionee_Service_Log::pvLog('user_index');
		Gionee_Service_Log::uvLog('user_index', $this->getSource());
		$start_time = array('>=',mktime('0','0','0'));
		$end_time  = array('<=',mktime('23','59','59'));
		$userInfo = $this->userInfo;
		//得到用户积分信息
		$userScore = Common_Service_User::getUserScore($userInfo['id']);
		//获得用户等级等级信息
		$levelMsg = Common_Service_User::getUserLevelInfo($userInfo['id'], $userInfo['user_level'],$userInfo['level_group']);
		//获得是否有未读内站信
		$unread = Common_Service_User::isexistsUnreadMessage($userInfo['id']);
		$products = $this->_getProduces();//赚取积分活动分类(生产类)
		$sign = $this->_checkUserSign($start_time, $end_time, $userInfo['id']);//检测打卡情况
		$ads =	Common_Service_User::getAdsByPageType('index'); //获得首页广告
		$signConfig = Common::getConfig('userConfig','signin');
		$this->assign('ads', $ads);					 	//首页广告
		$this->assign('unread', $unread); 			//是否有未读信息
		$this->assign('levelMsg', $levelMsg);	//用户等级信息
		$this->assign('userInfo', $userInfo);		//用户信息
		$this->assign('scoreInfo', $userScore);	//用户积分
		$this->assign('products', $products); 	//所有产生积分物品
		$this->assign('sign', $sign);						//用户打卡情况
		$this->assign('signConfig', $signConfig);
	}
	
	/**
	 * 获得所以产生积分的物品分类
	 * @return boolean
	 */
	private  function _getProduces(){
		$rs = Common::getCache();
		$produceKey = 'USER:GOODS:PRODUCT';
		$products = $rs->get($produceKey);
		$products = '';
		if(empty($products)){
			$products = User_Service_Category::getsBy(array('group_id'=>'2','status'=>'1'),array('sort'=>'DESC','id'=>'DESC'));
			$rs->set($produceKey,$products,60);
		}
		return $products;
	}
	
	/**
	 *用户已完成任务列表
	 */
	private   function _doneTasks($start,$end,$uid=0){
		$rs = Common::getCache();
		$taskKey = 'USER:GOODS:DONE:'.$uid;
		$doneTasks = $rs->get($taskKey);
		if(empty($doneTasks)){
			$params = array();
			$params['group_id'] = array("IN",array('1','2')); //只能是生产类
			$params['add_time'] = array($start,$end);
			$params['uid'] = $uid;
			$doneTasks = User_Service_ScoreLog::checkTasks($params,array('group_id','score_type'));
			$rs->set($taskKey,$doneTasks,24*3600);
		}
		return $doneTasks;
	}
	
	private  function _checkUserSign($start,$end,$uid){
		if(!$uid) return false;
		$params = array();
		$params['group_id'] = 1;
		$params['add_time'] = array($start,$end);
		$params['uid'] = $uid;
		$res = User_Service_Earn::getBy($params,array('id'=>'DESC'));
		return $res;
	}
}