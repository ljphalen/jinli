<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 积分兑换类（如兑换话费／流量等）
 * @author panxb
 *
 */
class GoodsController extends  User_BaseController
{
	public  $pageSize =5;
	//生产积分物品列表
	public function producesAction(){
		$login = Common_Service_User::checkLogin('/user/goods/produces');//检测登陆
		if($login['key'] == '0') $this->redirect($login['msg']);
		
		Gionee_Service_Log::pvLog('user_produces');
		Gionee_Service_Log::uvLog('user_produces', $this->getSource());
		
		 $attachPath = Yaf_Application::app()->getConfig()->attachroot.'/attachs';
		//获取积分数
		$uid = $this->userInfo['id'];
		$userScores = User_Service_Gather::getBy(array('uid'=>$uid));
		$catId = $this->getInput('cat_id');
		$page = $this->getInput('page');
		$page = max($page,1);
		if(!intval($catId)) $this->output('-1','信息有错！');
		$cateInfo = User_Service_Category::get($catId);
			$params= $p =  array();
			$params['cat_id'] = $p['cat_id'] =  $catId; 
			$params['status'] = 1; 
			$params['start_time']  = array('<=',time());
			$params['end_time']   = array('>=',time());
			list($total,$list) = User_Service_Produce::getList($page,$this->pageSize, $params,array('sort'=>'DESC','id'=>'DESC'));
			//查询用户已領取的商品ID
			$p ['uid'] = $uid;
			$p['group_id'] = 2;
			$p['add_time'] = array(array('>=',mktime(0,0,0)),array('<=',mktime(23,59,59)));
			$ids = User_Service_Earn::getDayEarnedGoodsIds($p);
			foreach ($list as $k=>$v){
				$list[$k]['get'] = in_array($v['id'], $ids)?1:0;
				$list[$k]['image'] = $attachPath.$v['image'];
			}
		$more  =$total  >  ($page * $this->pageSize) ?true:false;
		if($page >1){ //page 大于1 时为ajax获取数据 否则为直接渲染视图
			$this->output('0','',array('list'=>$list,'hasNext' =>$more,'cat_id'=>$catId,'score_type'=>$cateInfo['score_type']));
		}else{
			$this->assign('more', $more);
			$this->assign('userScores', $userScores);
			$this->assign('cat_id', $catId);
			$this->assign('catInfo', $cateInfo);
			$this->assign('list', $list);
			$ads = Common_Service_User::getAdsByPageType('pwords');
			$this->assign('wordAds', Common_Service_User::getAdsByPageType('pwords'));
		}
	}

	/**
	 * 用户赚取积分的动作（包括打卡，看图等)
	 */
	public function earnAction(){
		$login =Common_Service_User::checkLogin('/user/index/index');		//检测是否登陆
		if(!$login['key']) $this->redirect($login['msg']);
		$userInfo =$this->userInfo;
		$postData = $this->getInput(array('goods_id','group_id','score_type'));
		$params  =$p = array();
		$earned = 0;//默认获得的积分数 
		$redirectUrl = ''; //跳转URL
		if($postData['group_id'] == 1){//签到
			$params['cat_id'] = $params['goods_id']=  0;
			$signConfig = Common::getConfig('userConfig','signin');
			$earned = $signConfig['scores'];
		}elseif ($postData['group_id'] == 2){ //看图片等送积分
			if(!intval($postData['goods_id']) ){
					$this->output('-1','参数有错！');
			}
			$goods = User_Service_Produce::get($postData['goods_id']);
			$params['cat_id'] 				= $goods['cat_id'];
			$params['goods_id'] 		= $goods['id'];
			$earned 							= $goods['scores'];
			$redirectUrl 						= $goods['link'];
		}
		$params['add_time'] 	 	= array(array('>=',mktime('0','0','0')),array('<=',mktime('23','59','59')));
		$params['uid'] 					= $userInfo['id'];
		$params['group_id'] 		= $postData['group_id']?$postData['group_id']:1;
		 $signFlag = User_Service_Earn::getBy($params);//检测当天是否已经打卡
		  if($signFlag){
			if($params['group_id'] == 1){
					$this->output('-1','您今天已经完成签到，请明天再来！');
			}else{
					$this->output('-1','您已领取今天的活动奖励，请完成其它任务!');
				}
		}  
		$p = array(
			'uid'		=>$userInfo['id'],
			'group_id'				=>$params['group_id'],
			'cat_id'					=>$params['cat_id'],
			'goods_id'				=>$params['goods_id'],
			'score'						=>$earned,
			'level_group'			=>$userInfo['level_group'],
			'user_level'			=>$userInfo['user_level'],
			'score_type'			=>$postData['score_type']?$postData['score_type']:101
		);
		$changeScores 		= Common_Service_User::scoreVarify($p);
		if($changeScores){
			$this->output('0','领取积分成功！',array('increScores'=>$changeScores,'redirect'=>$redirectUrl));
		}
		$this->output('-1','操作失败');
	}
	
	//消费积分物品列表
	public function xfAction(){
		$postData = $this->getInput(array('page','cat_id'));
		$callback = empty($postData['cat_id'])?'/user/goods/xf?cat_id='.$postData['cat_id']:'/user/goods/xf';
		$login =Common_Service_User::checkLogin($callback);
		if(!$login['key'])  $this->redirect($login['msg']);
		Gionee_Service_Log::pvLog('user_cosume_list');
		Gionee_Service_Log::uvLog('user_cosume_list', $this->getSource());
		$page = max($postData['page'],1);
		$userScores = User_Service_Gather::getBy(array('uid'=>$this->userInfo['id']));
		$params = array();
		$postData['cat_id']?$params['cat_id'] 	 = $postData['cat_id']:'';
		$params['start_time']  = array('<=',time());
		$params['end_time'] 	= array('>=',time());
		$params['status'] = 1;
		list($total,$data) = User_Service_Commodities::getList($page, 20,$params,array('sort'=>'DESC','id'=>'DESC'));
		$ads  = Common_Service_User::getAdsByPageType('cosume');
		$this->assign('ads', $ads);
		$this->assign('userScores', $userScores);
		$this->assign('total', $total);
		$this->assign('data', $data);
		$this->assign('refurl', $_SERVER['REQUEST_URI']);
	}
	
	//检测用户当前可用积分是否足够兑换指定的商品
	public function  ajaxCheckScoreAction(){
		$login =Common_Service_User::checkLogin('/user/index/index');
		if(!$login['key'])  $this->redirect($login['msg']);
		$goods_id = $this->getInput('goods_id');
		$refurl = $this->getInput('refurl');
		//查看是否为等级物品
		$goodsInfo = User_Service_Commodities::get($goods_id);
		if($goodsInfo['number']< 1){
			$this->output('-1','您要兑换的商品数量不足!');
		}
		$costScore = $goodsInfo['scores'];
		if($goodsInfo['is_special']  == '1'){
			$privilegeMsg = Common_Service_User::getCateAndGoodsLevelInfo(2,$goodsInfo['cat_id'],$goodsInfo['goods_id'],$this->userInfo['user_level'],$this->userInfo['level_group']);
			if($privilegeMsg['levelScore'] >0){
				$costScore = $privilegeMsg['levelScore'];
			}
		}
		//用户积分信息
		$userScores =  User_Service_Gather::getBy(array('uid'=>$this->userInfo['id']));
		$remined =  $userScores['remained_score'] - $costScore;
		if($remined >= 0){
			$webroot= Common::getCurHost();
			$refurl = $refurl?$webroot.$refurl:$webroot.'/user/index/index';
			$this->output('0','',array('redirect'=>$webroot."/User/goods/detail?goods_id={$goods_id}&refurl={$refurl}"));
		}else{
			$this->output('-1','您的积分不够！');
		}
	}
	/**
	 * 兑换详情页
	 */
	public function detailAction(){
		$login =Common_Service_User::checkLogin('/user/index/index');
		if(!$login['key']) $this->redirect($login['msg']);
		Gionee_Service_Log::pvLog('user_cosume_detail');
		Gionee_Service_Log::uvLog('user_cosume_detail', $this->getSource());
		$postData = $this->getInput(array('goods_id','refurl'));
		if(!intval($postData['goods_id'])) return false;
		$goodsInfo = User_Service_Commodities::get($postData['goods_id']);
		if(!empty($goodsInfo['card_id'])){
			$cardInfo = User_Service_CardInfo::get($goodsInfo['card_id']);
			$this->assign('exType', $cardInfo['group_type']);
		}
		$userScores = Common_Service_User::getUserScoresMsg($this->userInfo['id']);
		$this->assign('userScores', $userScores);
		$this->assign('goodsInfo', $goodsInfo);
		$this->assign('userInfo', $this->userInfo);
		$this->assign('refurl', $postData['refurl']);
		
	}
	/**
	 * 积分兑换接口
	 * @param int 		$cat_id  			分类ID
	 * @param int		$goods_id 		物品ID
	 * @param int		$scores			默认所需消费积分数
	 * @param int		$goods_number	兑换物品数 (默认为1)
	 * @param int 		$address_id		收贷地址ID （可为空)
	 */
	public function exchangeAction(){
		$login =Common_Service_User::checkLogin('/user/index/index');
		if(!$login['key'])  $this->redirect($login['msg']);//检测登陆状态
		$postData = $this->getInput(array('goods_id','tel','inprice','refurl'));
		$goods = User_Service_Commodities::get($postData['goods_id']);
		if(!empty($postData['tel']) && !preg_match('/^1[3|5|7|8|9]\d{9}$/',$postData['tel']) ){//如果为虚拟商品，则认为是充流量包或充话费
			$this->output('-1','手机号码格式有误,请核实!');
		}
		$uid = $this->userInfo['id'];
		if($goods['is_special'] ==1){ //检测是否为会员等级商品，如果是等级商品，则根据当前用户等级查看相应的消耗积分数
			$goods['scores'] = $this->_getRealCostScores($goods['id'],$goods['scores'], $this->userInfo['level_group'], $this->userInfo['user_level'], $uid);
		}
		try{
			Common_Service_Base::beginTransaction();
			$ret= User_Service_Gather::frozenUserScores($goods,$uid); //冻结积分并写日志
			$success = User_Service_Order::generateOrder($uid,$goods,$postData);		//生成订单
			if($ret&& $success['key']){
				$redirect = Common::getCurHost()."/user/goods/success?goods_id={$postData['goods_id']}&refUrl={$postData['refurl']}";
				if($goods['goods_type'] == 1 && $goods['card_id']){ //充值或礼品卡等虚拟商品处理
					$res = User_Service_CardInfo::handleVgoodsOrder($goods['card_id'],$success['data']['order_sn']);
					if($res['key'] =='1'){ 
						Common_Service_Base::commit();
						$this->output('0',$res['msg'],array('redirect'=>$redirect));
					}else{
						Common_Service_Base::rollBack();
						$this->output($res['key'],$res['msg'],array('redirect'=>''));
					}
				}else{
					Common_Service_Base::commit();
					$this->output('0','订单提交成功!',array('redirect'=>$redirect));
				}
			}else {
				Common_Service_Base::rollBack();
				$this->output('-1','操作失败!');
			}
		}catch(Exception  $e){
			Common_Service_Base::rollBack();
			$this->output('-1','系统错误,请稍后再试!');
		}
	}
	
	
	/**
	 * 提交成功页
	 */
	
	public function successAction(){
		$login = Common_Service_User::checkLogin('/user/exchange/index');
		if($login['key'] =='0')  $this->redirect($login['msg']);//检测登陆状态
		Gionee_Service_Log::pvLog('user_cosume_success');
		Gionee_Service_Log::uvLog('user_cosume_success', $this->getSource());
		$post = $this->getInput(array('goods_id','refurl'));
		if(!intval($post['goods_id'])) $this->output('-1','参数有错!');
		$userScores = User_Service_Gather::getBy(array('uid'=>$this->userInfo['id']));
		$goodsInfo = User_Service_Commodities::get($post['goods_id']);
		$this->assign('userScores', $userScores);
		$this->assign('refurl', $post['refurl']);
		$this->assign('goods', $goodsInfo);
	}
	
	/**
	 * 获得等级商品真正兑换消耗积分信息
	 */
	 private function _getRealCostScores($goods_id,$scores,$levelGroup,$userLevel,$uid)
	 {
	 	$realScore = $scores;
		$var = array(
				'group_id'=>'3',
				'goods_id'=>$goods_id,
				'level_group'=>$levelGroup,
				'user_level'=>$this->userInfo['user_level']
		);
		$privilegeInfo = User_Service_Uprivilege::getBy($var);
		if(!empty($privilegeInfo) && $privilegeInfo['scores'] > 0){
			$realScore = $privilegeInfo['scores'];
		}
		return $realScore;
	}
}