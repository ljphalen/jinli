<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

//个人设置
class CenterController extends  User_BaseController {
	
	public $pageSize = 10;
	
	public function indexAction(){
		$login =Common_Service_User::checkLogin('/user/center/index');		//检测登陆状态
		if($login['key'] =='0') $this->redirect($login['msg']);
		
		Gionee_Service_Log::pvLog('user_center_index');
		Gionee_Service_Log::uvLog('user_center_index', $this->getSource());
		$type  = $this->getInput('type');
		$userInfo = $this->userInfo;
		$userScore = Common_Service_User::getUserScore($userInfo['id']);//用户可用积分
		$params = $cities =  array();
		$params['id'] = array('IN',array($userInfo['province_id'],$userInfo['city_id']));
		$areaInfo = Gionee_Service_Area::getCityNameByIds($params);
		$levelMsg = Common_Service_User::getUserLevelInfo($userInfo['id'], $userInfo['user_level'], $userInfo['level_group']);//用户等级信息
		if($userInfo['province_id'] >0){
			$cities = Common_Service_User::getAreaDataByParentId($userInfo['province_id']);
		}
		$hasUnread = Common_Service_User::isexistsUnreadMessage($userInfo['id']);//是否有未读站内信
		$this->assign('upScore', explode('-', $levelMsg['nextLevelMsg']['range'])[0]);
		$this->assign('userMsg', $userInfo);
		$this->assign('scoreMsg', $userScore);
		$this->assign('levelMsg', $levelMsg);
		$this->assign('provinces', Common_Service_User::getAreaDataByParentId());
		$this->assign('cities', $cities);
		$this->assign('type', $type);
		$this->assign('areaInfo', $areaInfo);
		$this->assign('unread', $hasUnread);
	}
	
	public function editPostAction(){
		$login = Common_Service_User::checkLogin('/user/center/index');
		if($login['key'] == '0') $this->redirect($login['msg']);
		$postData = $this->getInput(array('nickname','qq','email','province_id','city_id', 'address','sex'));
		if(mb_strlen($postData['nickname'])>30){
			$this->output('-1','用户昵称太长');
		}
		if(trim($postData['email'])){
			if( !filter_var($postData['email'], FILTER_VALIDATE_EMAIL)){
				$this->output('-1','您填写的email格式不正确!');
			}
		}
		if(mb_strlen(trim($postData['address']))> 80){
			$this->output('-1','地址长度不能超过80个字符!');
		}
		$ret = Gionee_Service_User::updateUser($postData, $this->userInfo['id']);
		if($ret){
			$this->output('0','修改成功!',array('redirect'=>Common::getCurHost().'/user/center/index'));
		}else{
			$this->output('-1','修改失败!');
		}
	}

	//站内信列表
	public function msgAction(){
		$login = Common_Service_User::checkLogin('/user/center/index');
		if($login['key'] == '0') $this->redirect($login['msg']);
		
		Gionee_Service_Log::pvLog('user_innermsg');
		Gionee_Service_Log::uvLog('user_innermsg', $this->getSource());
		$page  = $this->getInput('page');
		$page = max($page,1);
		$uid = $this->userInfo['id'];
		$key = "USER:INNERMSG:".$uid.":PAGE:".$page;
		$data = Common::getCache()->get($key);
		if(empty($data)){
			list($total,$data) = User_Service_InnerMsg::getList($page, $this->pageSize, array('uid'=>$uid), array('id'=>'DESC'));
			foreach ($data as $k=>$v){
				$data[$k]['add_time'] = date('m月d日 H:i:s',$v['add_time']);
			}
			Common::getCache()->set($key,$data,60);
		}
		//把所有未读信件标为已读
		User_Service_InnerMsg::updateBy(array('is_read'=>1), array('uid'=>$uid));
		Common::getCache()->delete('USER:INMSG:'.$uid);
		$more = $total >($page *$this->pageSize)?true:false;
		if($page>1){ //ajax请求
			$this->output('0','',array('list'=>$data,'hasNext'=>$more));
		}else{ //直接渲染视图
			$this->assign('list', $data);
			$this->assign('more', $more);
			$this->assign('referURL', $_SERVER["HTTP_REFERER"]);
		}
	}
	
	/**
	 * 获取用户所有积分变化日志
	 */
	public function scoreAction(){
		$loginInfo = Common_Service_User::checkLogin('/user/center/score');
		if(!$loginInfo['key'])  $this->redirect($loginInfo['msg']);
		
		Gionee_Service_Log::pvLog('user_scorelog');
		Gionee_Service_Log::uvLog('user_scorelog', $this->getSource());
		list($count1,$mixData) = User_Service_ScoreLog::getList(1,$this->pageSize,array('uid'=>$this->userInfo['id']),array('id'=>'DESC')); //所有记录
		$params2 = $params3  = array();
		$params2['uid'] = $params3['uid'] = $this->userInfo['id'];
		$params2['affected_score'] = array('>=',0);
		$params3['affected_score'] = array('<',0);
		list($count2,$increData) = User_Service_ScoreLog::getList(1,$this->pageSize,$params2,array('id'=>'DESC')); //赚取积分的日志
		list($count3,$descData) = User_Service_ScoreLog::getList(1,$this->pageSize,$params3,array('id'=>'DESC')); //消费积分日志
		$data = array('mix'=>array('count'=>$count1,'data'=>$mixData),'incre'=>array('count'=>$count2,'data'=>$increData),'desc'=>array('count'=>$count3,'data'=>$descData));
		//用户当前积分数
		$scoreInfo = User_Service_Gather::getBy(array('uid'=>$this->userInfo['id']));
		$this->assign('scoreInfo', $scoreInfo);
		$this->assign('data', $data);
		$this->assign('actions', Common::getConfig('userConfig','actions'));
		$this->assign('pageSize', $this->pageSize);	
		$this->assign('referURL', $_SERVER["HTTP_REFERER"]);
	}
	
	/**
	 * ajax 获取积分数据 
	 */
	public function ajaxScoreAction(){
		$postData = $this->getInput(array('page','type'));
		$params = array();
		if(in_array($postData['type'], array('1','2'))){
			if($postData['type'] == '1'){
				$params['affected_score']= array('>=',0);
			}else{
				$params['affected_score'] = array('<',0);
			}
		}
		$params['uid'] = $this->userInfo['id'];
		list($total,$dataList) = User_Service_ScoreLog::getList($postData['page'],$this->pageSize,$params,array('id'=>'DESC'));
		$actions = Common::getConfig('userConfig','actions');
		foreach ($dataList as $k=>$v){
			$dataList[$k]['score_type'] = $actions[$v['score_type']];
			$dataList[$k]['add_time'] = date('m月d日',$v['add_time']);
		}
		$hasNext = $total > $postData['page'] * $this->pageSize ? true:false; //是否还有分页数据
		$this->output('0','',array('list'=>$dataList,'hasNext'=>$hasNext));
	}
	
	/**
	 * 获取城市信息
	 */
	public function ajaxGetAreaDataListAction(){
		$province_id = $this->getInput('province_id'); 
		if(!$province_id) $this->output('-1','请选择省份信息');
		$dataList=  Common_Service_User::getAreaDataByParentId($province_id);
		$this->output(0,'',$dataList);
	}
	
}
