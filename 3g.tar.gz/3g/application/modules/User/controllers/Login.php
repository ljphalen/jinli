<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * 登录
 * @author tiansh
 *
 */
class LoginController extends User_BaseController {

	public $actions = array(
		'loginUrl'  => '/user/login/login',
		'logoutUrl' => '/user/login/logout',
		'indexUrl'  => '/user/login/index'
	);



	public function indexAction() {
	
	}

	public function loginAction() {
		//已经登录

		$webroot = Common::getCurHost();
		$code = $this->getInput('code');
		/* if (!Gionee_Service_User::isLogin()){
		 $this->redirect($webroot.'/user/login/index');
		} */
		if (!$code) $this->redirect($webroot . '/user/login/logout');

		$callback = $webroot . $this->actions['loginUrl'];
		$from = $this->getInput('f');
		$flag = false;
		if(in_array($from,	 array('1','2','3'))){
				$callback.="?f=$from";
				$flag = true;
		}
		$ret      = Api_Gionee_Oauth::accessToken($code, $callback);
		if (!$ret) $this->output(-1, '登录失败0.');
		
		$info = Api_Gionee_Oauth::verify($ret);
		if (!$info) $this->output(-1, '登录失败4.');
		
		$mobile = str_replace('+86', '', $info['tn']);

		if (!$mobile || !$info['u']) $this->redirect($webroot . '/user/login/index');
		$user = Gionee_Service_User::getUserByName($mobile);

		if (!$user) {
			$parms = array();
			$parms = array('username' => $mobile, 'mobile' => $mobile, 'out_uid' => $info['u']);
			if($flag){
				$parms['come_from'] = $from;
			}
			$ret = Gionee_Service_User::addUser($parms);
			if (!$ret) $this->output(-1, '登录失败.');
			$user = Gionee_Service_User::getByOutUid($info['u']);
		}
		//用户统计表中是否有信息，没有就添加
		$userScores = User_Service_Gather::getBy(array('uid'=>$user['id']));
		if(empty($userScores)){
			User_Service_Gather::add(array('uid'=>$user['id']));
		}
		
		if (!$user['out_uid']) {
			$ret = Gionee_Service_User::updateUser(array('out_uid' => $info['u']), $user['id']);
		}
		if (!$ret) $this->output(-1, '登录失败.');
		$ret = Gionee_Service_User::login($user['out_uid'], $user['password']);
		if (!$ret) $this->output(-1, '登录失败.');
		
		$refer = Util_Cookie::get('GIONEE_LOGIN_REFER', true);
		if ($refer) {
			$this->redirect($refer);
		}else{
			echo "<html><head><meta charset='utf8'></head><body><script type='text/javascript' charset='utf8'>alert('登陆失败，可能原因：COOKIE未启用。请在设置->隐私与安全->COOKIE中查看是否开启接受COOKIE选项！'); setTimeout(location.href='{$webroot}/nav/index',3);</script></body></html>";
			exit();
		}
	}

	/**
	 *
	 * 退出登录
	 */
	public function logoutAction() {
		Gionee_Service_User::logout();
		$webroot = Common::getCurHost();
		$this->redirect($webroot);
	}
}
