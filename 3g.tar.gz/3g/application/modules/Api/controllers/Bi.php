<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 *  *BI统计接口
 *  * @author tiger
 *
 */
class BIController extends Api_BaseController {

	public $modules = array('banner广告模块', '搜索模块', '热门站点模块', '分类栏目模块', '其它');

	//导航页关键字
	public function urlAction() {
		$tStr = $this->getInput('t');
		$tArr = explode(',', $tStr);
		$rc   = Common::getCache();
		$list = array();
		foreach ($tArr as $t) {
			$tmpInfo = $rc->get('ToUrl:' . $t);
			$info    = json_decode($tmpInfo, true);
			$title   = $column_name = $type_name = $module = '';
			if ($info['type'] == 'NAV') {
				$content     = Gionee_Service_Ng::get($info['id']);
				$title       = $content['title'];
				$column      = Gionee_Service_NgColumn::get($content['column_id']);
				$column_name = $column['name'];
				$type        = Gionee_Service_NgType::get($column['type_id']);
				$type_name   = $type['name'];
				//获得模块名
				if ($type['id'] == '1' && $column['style'] == 'img1') {
					$module = $this->modules[0];
				} elseif ($type['id'] == '1' && $column['style'] == 'hot_nav') {
					$module = $this->modules[2];
				} elseif (in_array($type['id'], array(2, 3, 4, 5, 6))) {
					$module = $this->modules[3];
				} else {
					$module = $this->modules[4];
				}
			}
			$list[] = array(
				't'         => $t,
				'id'        => $info['id'],
				'type'      => $info['type'],
				'title'     => $title,
				'col_name'  => $column_name,
				'type_name' => $type_name,
				'module'    => $module,
				'url'       => html_entity_decode($info['_url']),
			);
		}

		echo json_encode($list);
		exit;
	}
}