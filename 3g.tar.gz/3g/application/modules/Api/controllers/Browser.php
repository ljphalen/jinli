<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * 黑白名单网址接口
 * @author tiger
 *
 */
class BrowserController extends Api_BaseController {

	public $perpage = 20;

	/**
	 * 浏览器配置接口
	 */
	public function settingAction() {
		$page_version     = $this->getInput('page_version');
		$bookmark_version = $this->getInput('bookmark_version');
		$blackurl_version = $this->getInput('blackurl_version');

		$json_data = array();
		if (!empty($page_version)) {
			//三屏配置
			$v = Gionee_Service_Config::getBy(array('3g_key' => 'page_version'));
			if ($page_version != $v['3g_value']) {
				$pages  = array();
				$result = Gionee_Service_Page::getAll(array('sort' => 'ASC'));
				foreach ($result as $key => $value) {
					$pages[] = array(
						'sort'         => $value['sort'],
						'name'         => $value['name'],
						'type'         => $value['page_type'],
						'url'          => $value['url'],
						'is_default'   => $value['is_default'],
						'url_download' => ''
					);
				}
				$page        = array('type' => 'page', 'version' => $v['3g_value'], 'data' => $pages);
				$json_data[] = $page;
			}
		}

		if (!empty($bookmark_version)) {
			//默认应用
			$v = Gionee_Service_Config::getValue('bookmark_version_1');
			if ($bookmark_version != $v) {
				$path = Common::getConfig('siteConfig', 'attachPath');
				$apps = array();

				$params = array(
					'ver'     => array('&', 1),
				);

				$result = Gionee_Service_Bookmark::getsBy($params, array('sort' => 'ASC'));
				foreach ($result as $key => $value) {
					$apps[] = array(
						'sort'      => $value['sort'],
						'name'      => $value['name'],
						'icon'      => Util_Image::base64($path . $value['icon']),
						'backgroud' => $value['backgroud'],
						'url'       => $value['url'],
						'is_delete' => $value['is_delete'],
					);
				}
				$onlineapp   = array('type' => 'onlineapp', 'version' => $v, 'data' => $apps);
				$json_data[] = $onlineapp;
			}
		}

		if (!empty($blackurl_version)) {
			//url过滤
			$blackurl_version = $this->getInput('blackurl_version');
			$v                = Gionee_Service_Config::getBy(array('3g_key' => 'blackurl_version'));
			if ($blackurl_version != $v['3g_value']) {
				$menus  = array();
				$result = Gionee_Service_Blackurl::getAll(array('status' => 'ASC'));
				foreach ($result as $key => $value) {
					$menus[] = array(
						'name' => $value['name'],
						'url'  => $value['url'],
						'type' => $value['status'],
					);
				}
				$urlfilter   = array('type' => 'urlfilter', 'version' => $v['3g_value'], 'data' => $menus);
				$json_data[] = $urlfilter;
			}
		}

		$this->output(0, '', $json_data);
		exit;
	}

	/**
	 * 欢迎图片
	 */
	public function welcomeAction() {
		$welcome_version = $this->getInput('version');
		$v               = Gionee_Service_Config::getBy(array('3g_key' => 'welcome_version'));
		if ($welcome_version != $v['3g_value']) {
			$list = Gionee_Service_Welcome::getAll(array('sort' => 'ASC'));
			$path = Common::getConfig('siteConfig', 'attachPath');
			$date = array();
			foreach ($list as $value) {
				$date[] = array(
					'name' => $value['name'],
					'url'  => $value['url'],
					'img'  => Util_Image::base64($path . $value['img']),
					'sort' => $value['sort'],
				);
			}
			$json_data = array('version' => $v['3g_value'], 'images' => $date);
			$this->output(0, '', $json_data);
		}

		exit;
	}

	/**
	 * 闪屏接口
	 */
	public function splashAction() {
		$version = $this->getInput('version');
		list($total, $result) = Gionee_Service_Splash::getCanUseSplashs(0, 100, array('version' => $version));

		$attachroot = Yaf_Application::app()->getConfig()->attachroot;
		$output     = array();
		if ($total) {
			$output = array(
				'img'   => $attachroot . $result[0]['img_url'],
				'title' => $result[0]['title'],
			);
		}
		echo json_encode($output);
		exit;
	}

	/**
	 * 白名单接口
	 */
	public function whiteAction() {
		$this->urllist(1);
	}

	/**
	 * 黑名单接口
	 */
	public function blackAction() {
		$this->urllist(0);
	}

	public function staticAction() {
		$fid = $this->getInput('fid');
		list($content, $finfo) = Gionee_Service_Config::version_static($fid);
		//header('Content-Type: application/octet-stream');
		header('Content-Type: text/' . $finfo['extension']);
		echo $content;
		exit;
	}

	public function categoryAction() {
		$column_version = $this->getInput('version');
		$ver            = Gionee_Service_Config::getValue('column_version');
		if ($column_version != $ver) {
			$page      = max(1, intval($this->getInput('page')));
			$perpage   = intval($this->getInput('perpage'));
			$type      = intval($this->getInput('type'));
			$timestamp = intval($this->getInput('timestamp'));

			if ($perpage) {
				$this->perpage = $perpage;
			}

			$s_count = Gionee_Service_OutNews::getCountBy($timestamp);
			$s_count = Common::resetKey($s_count, 'source_id');

			$params = array();
			if ($type) $params['ptype'] = $type;
			$params['status'] = 1;

			list($total, $result) = Gionee_Service_Column::getList($page, $this->perpage, $params);
			$hasnext = (ceil((int)$total / $this->perpage) - ($page)) > 0 ? true : false;

			$tmp        = array();
			$attachroot = Yaf_Application::app()->getConfig()->attachroot;

			foreach ($result as $key => $value) {
				$tmp[] = array(
					'id'     => $value['source_id'],
					'sort'   => $value['sort'],
					'name'   => $value['title'],
					'type'   => $value['ptype'],
					'islink' => $value['pptype'],
					'link'   => $value['link'],
					'img'    => $attachroot . '/attachs' . $value['img'],
					'color'  => $value['color'],
					'total'  => intval($s_count[$value['source_id']]['total']),
				);
			}

			$out = array(
				'version'   => $ver,
				'timestamp' => time(),
				'list'      => $tmp,
				'hasnext'   => $hasnext,
				'curpage'   => $page
			);

			$this->output(0, '', $out);
		}
		exit;
	}

	/**
	 * QQ新闻列表接口
	 */
	public function newsAction() {
		$page      = intval($this->getInput('page'));
		$perpage   = intval($this->getInput('perpage'));
		$source_id = intval($this->getInput('type_id'));

		$news_id = intval($this->getInput('news_id'));
		$act     = $this->getInput('act');

		if ($perpage) $this->perpage = $perpage;

		//$this->perpage = min(14, $perpage);
		if ($page < 1) $page = 1;

		$params['source_id'] = $source_id;
		if ($news_id && $act) {
			if ($act == 'pre') {
				$params['id'] = array('<', $news_id);
			} else {
				$params['id'] = array('>', $news_id);
			}
		}

		list($total, $result) = Gionee_Service_OutNews::getList($page, $this->perpage, $params, array('id' => 'DESC'));

		$tmp = array();
		foreach ($result as $key => $value) {
			array_pop($value);
			$tmp[] = $value;
		}
		$hasnext = (ceil((int)$total / $this->perpage) - ($page)) > 0 ? true : false;


		$out = array(
			'list'      => $tmp,
			'hasnext'   => $hasnext,
			'curpage'   => $page,
			'timestamp' => Common::getTime()
		);

		$this->output(0, '', $out);

	}

	/**
	 * 新闻内容接口
	 */
	public function news_contentAction() {
		$id   = intval($this->getInput('id'));
		$info = Gionee_Service_OutNews::get($id);
		$this->output(0, '', json_decode($info['content'], true));
	}

	/**
	 * 新闻详情接口，预加载，一次取多条
	 * perpage 条数
	 * type_id 分类id
	 * channel_id 渠道 1：QQ新闻 2：...
	 * news_id 新闻id
	 * act pre or next
	 */
	public function news_detailsAction() {
		$perpage    = intval($this->getInput('perpage'));
		$source_id  = intval($this->getInput('type_id'));
		$channel_id = intval($this->getInput('channel_id'));
		$news_id    = intval($this->getInput('news_id'));
		$act        = $this->getInput('act');

		if ($perpage) $this->perpage = $perpage;

		$params['source_id'] = $source_id;
		if ($news_id && $act) {
			if ($act == 'pre') {
				$params['id'] = array('<=', $news_id);
			} else {
				$params['id'] = array('>=', $news_id);
			}
		}

		$tmp = array();

		//$hasnext = (ceil((int) $total / $this->perpage) - ($page)) > 0 ? true : false;
		//$this->output(0, '', array('list'=>$tmp, 'hasnext'=>$hasnext, 'curpage'=>$page, 'timestamp'=>Common::getTime()));
		$this->output(0, '', array('list' => $tmp));

	}


	/**
	 * 服务器本地配置测试接口
	 */
	public function LocalAction() {
		$data = Gionee_Service_LocalInterface::getAll();
		/* foreach ($data[1] as $k=>$v){
			 $data[1][$k]['info'] = str_replace('"',"'",$v['info']);
		 } */
		$this->assign('data', $data[1]);
	}

	/**
	 *
	 * @param unknown_type $status
	 */
	private function urllist($status) {
		header('Content-Type: text/xml');
		$output = array('<?xml version="1.0" encoding="UTF-8"?>', '<list>');
		list(, $result) = Gionee_Service_Blackurl::getList(0, 100, array('status' => $status));
		foreach ($result as $key => $value) {
			array_push($output, sprintf('<group name="%s">%s</group>', $value['name'], $value['url']));
		}
		array_push($output, '</list>');
		print_r(implode("", $output));
		exit;
	}

	/**
	 * 支持4.0
	 * 搜索引擎
	 */
	public function searchUrlAction() {
		$app		= $this->getInput('app');
		$type       = $this->getInput('type');
		$attachroot = Yaf_Application::app()->getConfig()->attachroot;
		$inputV     = $this->getInput('ver');
		$appver     = $this->getInput('app_ver');
		$where      = array('type' => 1);
		if (!empty($app)) {
			foreach(Gionee_Service_Browserurl::$app as $k => $v) {
				if($v == $app) {
					$where['app'] = array('&', $k);
					break;
				}
			}
		}
		$list       = Gionee_Service_Browserurl::getsBy($where, array('sort' => 'DESC'));
		foreach ($list as $val) {
			$tmp[] = array(
				'id'        => $val['id'],
				'type'      => 0,
				'name'      => $val['name'],
				'url'       => html_entity_decode($val['url']),
				'iconUrl'   => $attachroot . '/attachs' . $val['icon'],
				'operation' => $val['operation'],
			);
		}

		$ret = array(
			'timestamp' => time(),
			'list'      => $tmp,
		);
		$this->output(0, '', $ret);
	}

	/**
	 * 支持4.0
	 * 推荐网址
	 */
	public function recUrlAction() {
		$attachroot = Yaf_Application::app()->getConfig()->attachroot;
		$inputV     = $this->getInput('ver');
		$appver     = $this->getInput('app_ver');
		$where      = array('type' => 2);
		$list       = Gionee_Service_Browserurl::getsBy($where);
		foreach ($list as $val) {
			$tmp[] = array(
				'id'        => $val['id'],
				'name'      => $val['name'],
				'showUrl'   => html_entity_decode($val['show_url']),
				'realUrl'   => html_entity_decode($val['url']),
				'iconUrl'   => $attachroot . '/attachs' . $val['icon'],
				'operation' => $val['operation'],
			);
		}

		$ret = array(
			'timestamp' => time(),
			'list'      => $tmp,
		);
		$this->output(0, '', $ret);
	}

	/**
	 * 支持4.0
	 * 网址库
	 */
	public function urlListAction() {
		$attachroot = Yaf_Application::app()->getConfig()->attachroot;
		$inputV     = $this->getInput('ver');
		$appver     = $this->getInput('app_ver');
		$where      = array('type' => 3);
		$list       = Gionee_Service_Browserurl::getsBy($where);
		foreach ($list as $val) {
			$tmp[] = array(
				'id'        => $val['id'],
				'name'      => $val['name'],
				'showUrl'   => html_entity_decode($val['show_url']),
				'realUrl'   => html_entity_decode($val['url']),
				'iconUrl'   => $attachroot . '/attachs' . $val['icon'],
				'operation' => $val['operation'],
			);
		}

		$ret = array(
			'timestamp' => time(),
			'list'      => $tmp,
		);
		$this->output(0, '', $ret);
	}

	/**
	 * 支持4.0
	 * 轻应用
	 */
	public function webAppAction() {
		$appver    = $this->getInput('app_ver');
		$inputV    = $this->getInput('ver');
		$model     = $this->getInput('model');
		$operators = $this->getInput('operators');//运营商
		$list      = array();
		$v         = Gionee_Service_Config::getValue('bookmark_version_4');
		if ($inputV != $v) {
			$params = array(
				'ver'     => array('&', 4),
				'op_type' => !empty($operators) ? $operators : 'OP00',
			);

			$attachroot = Yaf_Application::app()->getConfig()->attachroot;

			$result = Gionee_Service_Bookmark::getsBy($params, array('sort' => 'ASC'));
			foreach ($result as $key => $value) {
				$list[] = array(
					'id'         => $value['id'],
					'name'       => $value['name'],
					'iconUrl'    => $attachroot . '/attachs' . $value['icon'],
					'background' => $value['backgroud'],
					'url'        => html_entity_decode($value['url']),
					'deletable'  => $value['is_delete'],
					'operation'  => $value['operation'],
				);
			}
		}

		$ret = array(
			'timestamp' => time(),
			'list'      => $list,
		);
		$this->output(0, '', $ret);
	}

	/**
	 * 支持3.1
	 * 轻应用
	 */
	public function webAppV1Action() {
		$inputV    = $this->getInput('ver');
		$model     = $this->getInput('model');
		$operators = $this->getInput('operators');//运营商
		$appver    = $this->getInput('app_ver');

		$v   = Gionee_Service_Config::getValue('bookmark_version_2');
		$ret = array();
		if ($inputV != $v) {
			$params = array(
				'ver'     => array('&', 2),
				'op_type' => !empty($operators) ? $operators : 'OP00',
			);

			$path   = Common::getConfig('siteConfig', 'attachPath');
			$apps   = array();
			$result = Gionee_Service_Bookmark::getsBy($params, array('sort' => 'ASC'));
			foreach ($result as $key => $value) {
				$apps[] = array(
					'id'         => $value['id'],
					'sort'       => $value['sort'],
					'name'       => $value['name'],
					'icon'       => Util_Image::base64($path . $value['icon']),
					'background' => $value['backgroud'],
					'url'        => html_entity_decode($value['url']),
					'is_delete'  => $value['is_delete'],
					'operation'  => $value['operation'],
				);
			}
			$ret[] = array('type' => 'onlineapp', 'version' => $v, 'data' => $apps);
		}

		$this->output(0, '', $ret);
	}

	/**
	 * 热词
	 */
	public function searchHotWordsAction() {
		$app = $this->getInput('app');

		$arr = Common::getCache()->get("baidu_hotwords");

		$tmp = array_rand($arr, 4);
		$t = array();
		foreach ($tmp as $n) {
			$val = $arr[$n];
			$t[] = array('keyword' => $val['text'], 'url' => $val['url']);
		}

		$ret = array(
			'timestamp' => time(),
			'list'      => $t,
		);
		$this->output(0, '', $ret);

	}

	/**
	 * 关键字匹配
	 */
	public function searchLikeWordsAction() {

		$keyword = $this->getInput('keyword');
		$app     = $this->getInput('app');
		$from    = Gionee_Service_Baidu::getFromNo();

		$rcKey   = 'LIKE_WORDS:' . crc32($keyword);
		$content = Common::getCache()->get($rcKey);
		if (empty($content)) {
			$url     = "http://m.baidu.com/su?from={$from}&wd={$keyword}&ie=utf-8&action=opensearch";
			$curl    = new Util_Http_Curl ($url);
			$content = $curl->get();
			Common::getCache()->set($rcKey, $content, 600);
		}

		$ret = array(
			'timestamp' => time(),
		);

		if (!empty($content)) {
			$result         = json_decode($content, true);
			$ret['keyword'] = $result[0];
			$ret['list']    = $result[1];
		}

		$this->output(0, '', $ret);
	}


	public function startAction() {
		$ret = time();
		$this->output(0, '', $ret);
	}

}
