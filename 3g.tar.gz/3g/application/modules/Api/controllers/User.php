<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
//用户中心接口

class UserController extends Api_BaseController{
	
	//广告Api
	public function adsAction(){
		$identifer = $this->getInput('identifer');
		$posInfo = Gionee_Service_Position::getBy(array('identifier'=>$identifer));
		if(!$posInfo) $this->output('-1','对不起，该广告位已不存在！');
		$key = '3G:USER:ADS';
		$ads = Common::getCache()->get($key);
		if(empty($ads)){
			$params = array();
			$params['pos_id'] = $posInfo['id'];
			$params['status'] = 1;
			$params['start_time'] = array('<=',Common::getTime());
			$params['end_time'] = array('>=',Common::getTime());
			$ads = Gionee_Service_Ads::getsBy($params,array('sort'=>'DESC','id'=>'DESC'));
			Common::getCache()->set($key,$ads,60);
		}
		$this->assign('0', '',json_encode($ads));
	}
}