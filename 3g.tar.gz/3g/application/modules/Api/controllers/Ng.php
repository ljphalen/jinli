<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * 导航接口
 */
class NgController extends Api_BaseController {
	/**
	 * 分类展开接口
	 */
	public function listAction() {
		$type_id   = $this->getInput('type_id');
		$clientVer = $this->getInput('ver'); //客户端版本号
		Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_NG_LIST, $type_id); //统计数据
		$verKey     = Gionee_Service_Ng::KEY_NG_TYPE_VER . $type_id;
		$serviceVer = Common::getCache()->get($verKey);
		if ($clientVer != $serviceVer) {
			$data = Gionee_Service_Ng::getTypeData($type_id);
			if (empty($data['content'])) {
				$this->output(0, '', array('data' => '-1', 'ver' => $clientVer));
			}
			$this->output(0, '', array('data' => $data['content'], 'ver' => $serviceVer));
		}
		$this->output(0, '', array('data' => '-1', 'ver' => $serviceVer));
	}

	//顶部广告接口
	public function adAction() {
		$rc   = Common::getCache();
		$cVer = $this->getInput('ver');
		$vKey = Gionee_Service_Ng::KEY_NG_AD; //版本号相关的缓存内容
		$sVer = $rc->get($vKey);
		$t_bi = $this->getSource();
		$flag = Gionee_Service_Config::getValue('activity_1111');
		Gionee_Service_Log::uvLog('3g_ad', $t_bi);
		if ($cVer != $sVer) {
			$ads = Gionee_Service_Ng::getAds(); //数据库中内容
			$this->output(0, '', array('msg' => $ads, 'ver' => $sVer, 'act11' => !empty($flag) ? 1 : 0));
			exit;
		}
		
		$this->output(0, '', array('msg' => '-1', 'ver' => $sVer, 'act11' => !empty($flag) ? 1 : 0));
	}

	//百度关键字
	public function baiduAction() {
		$json_data = Gionee_Service_Baidu::apiKeys();
		//shuffle($result);//将数组打乱
		$this->output(0, '', $json_data);
	}

	//导航子页接口
	public function cateAction() {
		$type_id = intval($this->getInput('type_id'));
		$orderBy = array('sort' => 'ASC', 'id' => 'ASC');
		$type    = Gionee_Service_NgType::getBy(array('id' => $type_id, 'page_id' => 2, 'status' => 1), $orderBy);
		if (!$type_id || !$type) {
			$this->redirect($this->actions['indexUrl']);
		}
		$pageData['cinner'] = array('data' => Gionee_Service_Ng::getTypeData($type_id));

		$this->output(0, '', $pageData);
	}


	//新闻资讯头条
	public function newsAction() {
		$inputArr = $this->getInput(array('ngid', 'switchCnt', 'limit'));
		$switch   = empty($inputArr['switchCnt']) ? 1 : intval($inputArr['switchCnt']);
		$limit    = empty($inputArr['limit']) ? 20 : intval($inputArr['limit']);

		$rcKey    = Gionee_Service_Ng::KEY_NG_NEWS_LIST . $inputArr['ngid'] . $limit;
		$newsList = Common::getCache()->get($rcKey);
		if (!empty($newsList)) {
			$this->output(0, '', $newsList);
		}

		$ngInfo = Gionee_Service_Ng::get($inputArr['ngid']);
		if (empty($ngInfo)) {
			$this->output(-1, '没有这栏目');
		}
		$ext                   = json_decode($ngInfo['ext'], true);
		$inputArr['source_id'] = $ext['newsSourceId'];

		$dataList = Gionee_Service_OutNews::getListBySourceId($inputArr['source_id'], $limit);
		$list     = array();
		foreach ($dataList as $k => $v) {
			$list[] = array(
				'id'    => $v['id'],
				'pos'   => $k + 1,
				'link'  => Common::tjurl(Common::getCurHost() . '/index/tj', $v['id'], 'NAVNEWS', $v['url'], $this->getSource()),
				'title' => $v['title']
			);
		}

		$newsList['list'] = $list;

		Common::getCache()->set($rcKey, $newsList, 600);

		$this->output(0, '', $newsList);
	}

}