<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class RechargeController extends Api_BaseController {

	//获得手机归属地及充值实际所需金额
	public function infoAction() {
		$postData = $this->getInput(array('mobile', 'goods_id'));
		if (!intval($postData['mobile'])) $this->output('-1', '请检查手机号是否正确！');
		if (!intval($postData['goods_id'])) $this->output('-1', '参数有误！');
		$goods = User_Service_Commodities::get($postData['goods_id']);
		if (empty($goods)) $this->output('-1', '参数有误');
		$money = intval($goods['price']);
		if ($postData['mobile'] && (Util_String::strlen($postData['mobile']) > 7)) {
			$subPhone = Util_String::substr($postData['mobile'], 0, 7);
			$res      = Api_Ofpay_Recharge::checkMobileStatus($postData['mobile'], $money);
			if ($res['cardinfo']['retcode'] != 1) {
				$this->output('-1', '运营商系统维护中，暂不能充值！', array('inprice' => $res['cardinfo']['inprice']));
			}
			$data = array(
				'inprice'  => Common::money($res['cardinfo']['inprice']),
				'outprice' => $goods['price'],
				'area'     => $res['cardinfo']['game_area']
			);
			$this->output('0', '', $data);
		} else {
			$card_info = array(
				'inprice'  => $money ? $money : 0,
				'outprice' => $goods['price'],
				'area'     => ''
			);
			$this->output(-1, '', $card_info);
		}
	}


	/**
	 * 充值返回的数据接口
	 * 更新本地订单状态
	 * order_status  订单的状态    0,未处理，1：处理成功，2:处理中，－1：取消订单
	 * ret_status 主要针对 欧飞充值平台返回的状态    0：未处理，1：充值成功 2：充值进行中 -1: 充值失败
	 */
	public function responseAction() {
		$userInfo = Gionee_Service_User::isLogin();
		$postData = $this->getInput(array('ret_code', 'sporder_id', 'ordersuccesstime', 'err_msg'));
		$order    = User_Service_Order::getBy(array('order_sn' => $postData['sporder_id']));
		$data     = array();
		if ($order) {
			switch ($postData['ret_code']) {
				case 0: {//进行中
					$data['order_status'] = 2;
					$data['rec_status']   = 2;
					break;
				}
				case 1: {//充值成功
					$data['order_status']    = 1;
					$data['rec_status']      = 1;
					$data['shipping_status'] = 1;
					break;
				}
				case 9: {//充值失败
					$data['order_status'] = -1;
					$data['rec_code']     = -1;
					break;
				}
			}
			$data['desc']           = $postData['err_msg'];
			$data['rec_order_time'] = strtotime($postData['ordersuccesstime']);
			$result                 = User_Service_Order::update($data, $order['id']);//更新订单状态
			//写订单状态更新日志
			$log = Common_Service_User::scorelog(array('order_id' => $order['id'], 'action_user' => 'system', 'order_status' => $data['order_status'], 'pay_status' => 1, 'shipping_status' => 1, 'add_time' => $postData['ordersuccesstime'], 'action_note' => $postData['err_msg']));
			//写Api调用返回结果的日志
			$api = User_Service_Recharge::add(array('status' => $postData['ret_code'], 'add_time' =>strtotime($postData['ordersuccesstime']), 'order_sn' => $postData['sporder_id'], 'desc' => json_encode(array('orderinfo' => $postData)), 'api_type' => 'recharge'));
		}
		//只有充值成功或失败时才给用户发站内信
		if (in_array($postData['ret_code'], array('1', '9'))) {
			$status = 1;//订单状态用于前台显示
			if ($postData['ret_code'] == '1') {
				Common_Service_User::changeUserScores($order['id'], 401, '-');//冻结积分状态更新,充值成功就扣除冻结积分，失败就返回积分
			} else {
				$status  = -1;
				Common_Service_User::changeUserScores($order['id'], 205);
			}
			Common_Service_User::sendInnerMsg(array('uid'=>$order['uid'],'classify'=>1,'status'=>$status,'recharge_mobile'=>$order['recharge_mobile'],'recharge_money'=>$order['order_amount']),'recharge_msg_tpl');
		}
		exit;
	}

	public function reissueAction() {
		$order_sn = $this->getInput('order_sn');
		$res      = Api_Ofpay_Recharge::reissue($order_sn);
		$this->output($res['msginfo']['retcode'] == 1 ? '0' : '-1', $res['msginfo']['err_msg']);
	}
}