<?php

if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 免费电话管理
 */
class VoipController extends Admin_BaseController {

	public $actions = array(
		'indexUrl'       => '/Admin2/VoIP/index',
		'addUrl'         => '/Admin2/VoIP/add',
		'addPostUrl'     => '/Admin2/VoIP/addPost',
		'eddUrl'         => '/Admin2/VoIP/edit',
		'editPostUrl'    => '/Admin2/VoIP/editPost',
		'userUrl'        => '/Admin2/VoIP/user',
		'deleteUrl'      => '/Admin2/VoIP/delete',
		'logUrl'         => '/Admin2/VoIP/log',
		'deleteLogUrl'   => '/Admin2/VoIP/deleteLog',
		'service'        => '/Admin2/VoIP/service',
		'serviceList'    => '/Admin2/VoIP/serviceList',
		'servicePost'    => '/Admin2/VoIP/servicePost',
		'serviceEdit'    => '/Admin2/VoIP/serviceEdit',
		'censusUrl'      => '/Admin2/VoIP/census',
		'userLogUrl'     => '/Admin2/VoIP/userLog',
		'calledLogUrl'   => '/Admin2/VoIP/calledLog',
		'callDetailUrl'  => '/Admin2/VoIP/callDetail',
		'tipsListUrl'    => '/Admin2/VoIP/tips',
		'connectedUrl'   => '/Admin2/VoIP/connected',
		'cDetailUrl'     => '/Admin2/VoIP/cDetail',
		'connected1Url'  => '/Admin2/VoIP/connected1',
		'cDetail1Url'    => '/Admin2/VoIP/cDetail1',
		'periodUrl'      => '/Admin2/VoIP/period',
		'newRegisterUrl' => '/Admin2/VoIP/newUser',
	);

	public $fptMsg = 'ftp://gionee:keepc.com@113.31.81.154:9926/';
	public $pageSize = 20;

	public function  indexAction() {
		$page = $this->getInput('page');
		list($total, $dataList) = Gionee_Service_VoIP::getListByPage($page, $this->pageSize, array(), array('id' => 'DESC'));
		foreach ($dataList as $k => $v) {
			$used                    = Gionee_Service_VoIPUser::getCount(array('pid' => $v['id']));
			$dataList[$k]['remined'] = $v['number'] - $used;
		}
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['indexUrl'] . "/?"));
	}

	public function configAction() {


		$data = $this->getPost(array('accountSid', 'accountToken', 'appId', 'month_call_time', 'show_number'));
		if (!empty($data['accountSid'])) {
			Gionee_Service_Config::setValue('voip_config', json_encode($data));
			$this->output(0, '添加成功！');
		}
		$data = Gionee_Service_Config::getValue('voip_config');

		$tel  = new Vendor_Tel();
		$info = $tel->getAccountInfo();
		$this->assign('data', json_decode($data, true));
		$this->assign('info', $info);

	}

	public function addAction() {
	}

	public function addPostAction() {
		$dataList             = $this->getInput(array('start_time', 'end_time', 'valid_time', 'number', 'status', 'sort'));
		$dataList['add_time'] = time();
		$insert               = Gionee_Service_VoIP::insert($dataList);
		if ($insert) {
			$this->output(0, '添加成功！');
		} else {
			$this->output(-1, '添加失败！');
		}
	}

	public function editAction() {
		$id      = $this->getInput('id');
		$message = Gionee_Service_VoIP::get($id);
		$this->assign('msg', $message);
		$this->assign('id', $id);
	}

	public function editPostAction() {
		$data = $this->getInput(array('id', 'start_time', 'end_time', 'valid_time', 'number', 'status', 'sort'));
		$edit = Gionee_Service_VoIP::update($data['id'], $data);
		if ($edit) {
			$this->output(0, '编辑成功！');
		} else {
			$this->output('-1', '编辑失败！');
		}
	}

	public function deleteAction() {
		$id  = $this->getInput('id');
		$res = Gionee_Service_VoIP::delete($id);
		if ($res) $this->output(0, '操作成功');
		else $this->output('-1', '操作失败');
	}

	public function userAction() {
		$page = $this->getInput('page');
		list($total, $dataList) = Gionee_Service_VoIPUser::getDataList($page, 20, array(), array('id' => 'DESC'));
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, 20, $this->actions['userUrl'] . "/?"));
	}

	public function logAction() {
		$page = $this->getInput('page');
		list($total, $dataList) = Gionee_Service_VoIPLog::getList($page, $this->pageSize, array(), array('id' => 'DESC'));
		$this->assign('dataList', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['logUrl'] . "/?"));
	}

	public function deleteLogAction() {
		$id  = $this->getInput('id');
		$res = Gionee_Service_VoIPLog::delete($id);
		if ($res) {
			$this->output('0', 'Success');
		} else {
			$this->output('-1', 'Failed');
		}

	}

	public function serviceAction() {

	}

	public function servicePostAction() {
		$postData = $this->getInput(array('name', 'sort', 'contact', 'status'));
		if (!$postData['name'] || !$postData['contact']) {
			$this->output('-1', '数据不能为空');
		}
		$dataList = array();
		$data     = json_encode(array('name' => $postData['name'], 'contact' => $postData['contact'], 'sort' => $postData['sort'], 'status' => $postData['status']));
		$services = Gionee_Service_Config::getValue('yx_customer_service');
		if ($services) {
			$services = json_decode($services, true);
			array_unshift($services, $data);
			$dataList = $services;
		} else {
			$dataList[] = $data;
		}
		$res = Gionee_Service_Config::setValue('yx_customer_service', json_encode($dataList));
		if ($res) {
			$this->output(0, '添加成功！');
		} else {
			$this->output('-1', '添加失败');
		}
	}

	public function serviceListAction() {
		$dataList = Gionee_Service_Config::getValue('yx_customer_service');
		$dataList = json_decode($dataList, true);
		$arr      = array();
		foreach ($dataList as $k => $v) {
			$arr[] = json_decode($v, true);
		}
		$this->assign('list', $arr);
	}

	public function serviceEditAction() {
		$postData = $this->getInput(array('service'));
		$temp     = array();
		foreach ($postData['service'] as $k => $v) {
			array_push($temp, json_encode($v));
		}
		$res = Gionee_Service_Config::setValue('yx_customer_service', json_encode($temp));
		if ($res) {
			$this->output('0', "编辑成功");
		} else {
			$this->output('-1', '编辑失败');
		}
	}

	//PV&UV统计
	public function censusAction() {
		$ym = $this->getPost('ym');
		if (empty($ym)) {
			$ym = date('Ym');
		}
		$where = array(
			'date' => array(array('>=', $ym . '01'), array('<=', $ym . '31')),
			'key'  => array('IN', array('voip_pv', 'voip_uv', 'voip_pv_list', 'voip_uv_list', 'voip_pv_call', 'voip_uv_call', 'voip_pv_call1', 'voip_uv_call1'))
		);

		$dataList = Gionee_Service_Log::getsBy($where, array('date' => 'DESC'));

		$result = array();
		foreach ($dataList as $k => $v) {
			$result[$v['date']][$v['key']] = $v['val'];
		}
		$this->assign('ym', $ym);
		$this->assign('dataList', $result);
	}

	//用户统计
	public function userLogAction() {
		$page = $this->getInput('page');
		$page = max(1, $page);
		list($dayCount, $userCount) = Gionee_Service_VoIPUser::getCountByDate(($page - 1) * $this->pageSize, $this->pageSize, array('sta' => '1'), array('date'), array('date' => 'DESC'));
		$total = Gionee_Service_VoIPUser::getCount(array('sta' => 1));

		$this->assign('dataList', $userCount);
		$this->assign('total', $total);
		$this->assign('pager', Common::getPages($dayCount, $page, $this->pageSize, $this->actions['userLogUrl'] . "?"));
	}

	public function userMsgAction() {
		$page = $this->getInput('page');
		$page = max($page, 1);
		$date = $this->getInput('date');
		if (!$date) $this->output('-1', '参数错误!');
		list($total, $dataList) = Gionee_Service_VoIPUser::getDataList($page, $this->pageSize, array('date' => $date), array('id' => 'DESC'));
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['callDetailUrl'] . "?date={$date}&"));
		$this->assign('datList', $dataList);

	}

	//拔打统计
	public function calledLogAction() {
		$page = $this->getInput('page');
		$page = max($page, 1);
		//总点击拔打按钮的次数
		list($total, $dataList) = Gionee_Service_VoIPLog::getCensusDataByDate($page, $this->pageSize, array(), array('date'), array('id' => 'DESC'));
		$this->assign('dataList', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['calledLogUrl'] . "?"));
	}

	//针对单个用户拔号统计
	public function perCallTimesAction() {
		$page  = $this->getInput('page');
		$date  = $this->getInput('date');
		$total = $this->getInput('total');
		$where = array('date' => $date);
		$data  = Gionee_Service_VoIPLog::getPerUserCallTimesInfo(max($page, 1), $this->pageSize, $where, array('caller_phone'), array('id' => 'DESC'));
		$this->assign('data', $data);
		$this->assign('date', $date);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['perCallTimes'] . "?date={$date}&total={$total}&"));
	}

	public function perCallTimesExportAction() {
		$date  = $this->getInput('date');
		$where = array('date' => $date);
		$order = array('id' => 'desc');
		$list  = Gionee_Service_VoIPLog::getsBy($where, $order);

		$headers  = array('id', 'caller_phone', 'called_phone', 'duration', 'called_time', 'connected_time', 'hangup_time');
		$filename = 'calltimes_' . date('YmdHis') . '.csv';
		//header( 'Content-Type: text/csv; charset=utf-8' );
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment;filename=' . $filename);
		$fp = fopen('php://output', 'w');

		fputcsv($fp, $headers);
		foreach ($list as $fields) {
			$fields['area'] = iconv('UTF8', 'GBK', $fields['area']);

			$row = array(
				$fields['id'],
				$fields['caller_phone'],
				$fields['called_phone'],
				$fields['duration'],
				date('Y-m-d H:i:s', $fields['called_time']),
				!empty($fields['connected_time']) ? date('Y-m-d H:i:s', $fields['connected_time']) : 0,
				!empty($fields['hangup_time']) ? date('Y-m-d H:i:s', $fields['hangup_time']) : 0,
			);
			fputcsv($fp, $row);
		}
		fclose($fp);
		exit;
	}

	//拔打详情
	public function callDetailAction() {
		$page = $this->getInput('page');
		$date = $this->getInput('date');
		list($total, $dataList) = Gionee_Service_VoIPLog::getList(max(1, $page), $this->pageSize, array('date' => $date), array('id' => 'desc'));
		$this->assign('dataList', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['callDetailUrl'] . "?date={$date}&"));
	}

	//文字广告内容
	public function tipsAction() {
		$content  = Gionee_Service_Config::getValue('3g_voip_tips');
		$voip_ads = Gionee_Service_Config::getValue('3g_voip_ads');
		$this->assign('content', $content);
		$this->assign('voip_ads', $voip_ads);
	}

	public function editTipsAction() {
		$tips     = trim($_POST['3g_voip_tips']);
		$voip_ads = $this->getInput('3g_voip_ads');
		$res      = Gionee_Service_Config::setValue('3g_voip_tips', $tips);
		$tipKey   = '3g:VOIP:TIPS';
		Common::getCache()->set($tipKey, $tips, 24 * 3600);
		$res2 = Gionee_Service_Config::setValue('3g_voip_ads', $voip_ads);
		if ($res && $res2) $this->output('0', '操作成功!');
		else $this->output('-1', '操作失败');
	}

	//接通记录
	public function connected1Action() {
		$m     = $this->getInput('m');
		$list  = Gionee_Service_VoIPLog::getCalledStat($m, true);
		$list2 = Gionee_Service_VoIPLog::getCalledStat($m);
		$tmp   = array();
		foreach ($list2 as $val) {
			$tmp[$val['date']] = $val;
		}
		$this->assign('dataList', $list);
		$this->assign('dataList1', $tmp);
	}


	public function cDetail1Action() {
		$page = $this->getInput('page');
		$date = $this->getInput('date');
		list($total, $list) = Gionee_Service_VoIPLog::getList($page, $this->pageSize, array('date' => $date), array('id' => 'desc'));
		$this->assign('dataList', $list);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['cDetail1Url'] . "/?date={$date}&"));
	}

	public function connectedAction() {
		$page = $this->getInput('page');
		$page = max($page, 1);
		$rKey = 'VOIP:COMMONTIUNATE:' . (($page - 1) * 10 + 1) . ' - ' . $page * 10;
		$res  = Common::getCache()->get($rKey);
		if (empty($res)) {
			for ($i = ($page - 1) * 10 + 1; $i <= $page * 10; $i++) {
				$count   = 0;
				$seconds = 0; //通话时长
				$dateStr = date('Ymd', strtotime("-$i days"));
				//$tjData = Gionee_Service_Log::getBy(array('date'=>$dateStr,'key'=>'voip_pv'));//PV信息
				$filename = $this->fptMsg . $dateStr . '.txt';
				if (file_exists($filename) != false) {
					$data = file_get_contents($this->fptMsg . $dateStr . '.txt');
					if (!empty($data)) {
						$arrayData = explode("\n", trim($data));
						$count     = count($arrayData);
					}
					$caller = array();
					foreach ($arrayData as $v) {
						$temp = explode(',', $v);
						$seconds += $temp[3];
						$caller[$temp[0]]++;
					}
					$res[] = array(
						'connetedNum' => $count, //总通话次数
						'date'        => strtotime("-$i days"), //日期
						'seconds'     => $seconds,    //总通话时长
						'perSeconds'  => $count ? bcdiv($seconds, $count, 2) : '---', //接通电话的人均通话时间(秒)
						'perTimes'    => $count ? bcdiv($count, count($caller), 2) : '0',//用户平均通话次数(已接通用户)
						'callerNum'   => count($caller), // 拔打用户数
					);
				}
				Common::getCache()->set($rKey, $res, 12 * 3600);
			}
		}
		$this->assign('dataList', $res);
		$this->assign('pager', Common::getPages($this->_fileCount(), $page, 10, $this->actions['connectedUrl'] . "/?"));
	}


	public function cDetailAction() {
		$date     = $this->getInput('date');
		$fileName = $this->fptMsg . $date . '.txt';
		$list     = array();
		if (file_exists($fileName)) {
			$content = file_get_contents($fileName);
			if ($content) {
				$arrContent = explode("\n", trim($content));
				foreach ($arrContent as $v) {
					$list[] = explode(',', $v);
				}
			}
		}
		$this->assign('dataList', $list);
	}

	//通话时段统计
	public function periodAction() {
		$date = $this->getInput('date');
		!$date && $date = date('Ymd', strtotime('-1 day'));
		if (strtotime($date) > time()) {
			$this->output('-2', '时间不能大于当前时间');
		}
		$rKey = '3G:VOIP:PERIOD:' . $date;
		$ret  = Common::getCache()->get($rKey);
		if (empty($ret)) {
			$periodMsg = array();
			$amount    = 0;
			$date      = date('Ymd', strtotime($date));
			$fileName  = $this->fptMsg . $date . ".txt";
			if (file_exists($fileName)) {
				$data = file_get_contents($fileName);
				if (!empty($data)) {
					$hours   = array();
					$arrData = explode("\n", trim($data));
					$amount  = count($arrData);
					foreach ($arrData as $v) {
						$temp = explode(',', $v);
						list($year, $month, $day, $hour, $minus, $seconds) = preg_split('/[- :]/', $temp[2]);
						$hours[intval($hour)]++;
					}
					for ($i = 0; $i < 24; $i++) {
						$periodMsg[$i] = 0;
						if (in_array($i, array_keys($hours))) {
							$periodMsg[$i] = $hours[$i];
						}
					}
					$ret = array('data' => $periodMsg, 'amount' => $amount);
					Common::getCache()->set($rKey, $ret, 12 * 3600);
				}
			}
		}
		$this->assign('data', $ret);
		$this->assign('date', $date);
	}

	/**
	 * 通过畅聊接口新增的用户数
	 */
	public function newUserAction() {
		$page                = $this->getInput('page');
		$page                = max($page, 1);
		$params              = array();
		$params['come_from'] = 2;
		list($numbers, $dataList) = Gionee_Service_User::countByDays($page, $this->pageSize, $params);
		$sum = 0;
		foreach ($numbers as $v) {
			$sum += $v['total'];
		}
		$this->assign('dataList', $dataList);
		$this->assign('sum', $sum);
		$this->assign('pager', Common::getPages(count($numbers), $page, $this->pageSize, $this->actions['newRegisterUrl'] . "/?"));
	}

	/**
	 * 文件总数
	 */
	private function _fileCount() {
		$fileDir = $this->fptMsg;
		if (is_dir($fileDir)) {
			$i      = 0;
			$handle = opendir($fileDir);
			while (false != ($file = @readdir($handle))) {
				if ($file != '.' || $file != '..') {
					$i++;
				}
			}
			closedir($handle);
		}
		return $i;
	}

	public function billListAction() {
		$tel  = new Vendor_Tel();
		$date = $this->getInput('date');
		$list = $tel->getBillList($date);
		echo json_encode($list);
		exit;
	}
}