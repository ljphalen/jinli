<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 系统设置
 * @author rainkid
 */
class ConfigController extends Admin_BaseController {

	public $actions = array(
		'editUrl'        => '/Admin2/config/index',
		'editPostUrl'    => '/Admin2/config/edit_post',
		'delFileUrl'     => '/Admin2/config/delResFile',
		'extractFileUrl' => '/Admin2/config/extractResFile',
		'loglist'        => '/Admin2/config/loglist',
		'incomeUrl'      => '/Admin2/config/income',
		'errLogDelUrl'   => '/Admin2/config/errLogDel',
		'errLogUrl'      => '/Admin2/config/errlog',
		'cronLogUrl'     => '/Admin2/config/cronlog',
		'uconfigUrl'	 =>'/Admin2/config/uconfig',
		'editMsgTplUrl'=>'/Admin2/config/editMsgTpl',
	);


	public function indexAction() {
		$configs = Gionee_Service_Config::getAllConfig();
		$this->assign('configs', $configs);
	}

	public function cleanverAction() {
		$vers = $this->getInput(array('nav_index', 'nav_type_id', 'news_index'));
		if (!empty($vers['nav_index'])) {
			Gionee_Service_Ng::updataVersion();
		} elseif (!empty($vers['nav_type_id'])) {
			$rcKey = Gionee_Service_Ng::cleanNgTypeData($vers['nav_type_id']);
			Common::getCache()->delete($rcKey);
		} elseif (!empty($vers['news_index'])) {
			Gionee_Service_Config::setValue('APPC_Front_News_index', Common::getTime());
		}


	}

	public function baidukeywordsAction() {
		$vers     = $this->getInput(array('update'));
		$keywords = Common::getCache()->get("baidu_keywords");
		$hotwords = Common::getCache()->get("baidu_hotwords");

		$hotTitles = array();
		foreach ($hotwords as $v) {
			$hotTitles[] = $v['text'];
		}
		//首页导航信息
		$words  = Gionee_Service_Baidu::getNavIndexWrods();
		$hotNav = array();
		foreach ($words as $v) {
			$hotNav[] = $v['text'];
		}
		if (!empty($vers['update'])) {
			$ret = Gionee_Service_Baidu::updateKeywords();
		}
		/*
		$items = Gionee_Service_Baidu::takeKeywords();
		$t     = array();
		foreach ($items as $k => $v) {
			$t[] = $v['word'];
		}
		*/
		$t     = array();
		$items = Gionee_Service_Baidu::getSmHotwords();
		foreach ($items as $m => $n) {
			$t[] = $n['title'];
		}
		//把后台手动添加的有效数据放入相应的位置
		$apikeys = Gionee_Service_Baidu::apiKeys();
		foreach ($apikeys as $v) {
			$apiValues[] = $v['text'];
		}
		$this->assign('items', $t);
		$this->assign('keywords', $keywords);
		$this->assign('hotwords', $hotTitles);
		$this->assign('navindexwords', $hotNav);
		$this->assign('apikeys', $apiValues);
	}

	public function edit_postAction() {
		$config                      = $this->getInput(array('styles_version', 'gionee_cache', 'activity_1111'));
		$config['sohu_redirect_url'] = $_POST['sohu_redirect_url'];

		foreach ($config as $key => $value) {
			Gionee_Service_Config::setValue($key, $value);
		}
		$this->output(0, '操作成功.');
	}

	public function uploadResAction() {
		$attachPath = Common::getConfig('siteConfig', 'attachPath');
		$savePath   = sprintf('%s/%s/%s', $attachPath, 'res_file', '');
		if (!empty($_FILES['res_file'])) {
			$fileInfo = $_FILES['res_file'];
			$filename = sprintf('%s/%s.zip', $savePath, date('YmdHis'));
			if ($fileInfo['tmp_name']) {
				move_uploaded_file($fileInfo['tmp_name'], $filename);
			}
			$zip = new ZipArchive;
			$zip->open($filename);
			$zip->extractTo($savePath . '/sync');
			$zip->close();
		}
		$files = array_diff(scandir($savePath), array('..', '.'));
		$this->assign('files', $files);
	}

	public function delResFileAction() {

	}

	public function extractResFileAction() {
		$attachPath = Common::getConfig('siteConfig', 'attachPath');
		$savePath   = sprintf('%s/%s/%s', $attachPath, 'res_file', '');
		$name       = $this->getInput('name');
		$filename   = sprintf('%s%s', $savePath, $name);
		$zip        = new ZipArchive;
		$zip->open($filename);
		$zip->extractTo($savePath . '/sync');
		$zip->close();
		echo "更新成功";
		exit;
	}

	/**
	 * 检测URL是否有404现象
	 */
	public function checkUrlAction() {
		$params['status']     = 1;
		$params['start_time'] = array('<=', time());
		$params['end_time']   = array('>=', time());
		$total                = Gionee_Service_Ng::count($params);
		$this->assign('total', $total);
		$pageSize = $this->getInput('pageSize');
		$pageSize = $pageSize ? $pageSize : 30;
		$this->assign('pageSize', $pageSize);
	}

	/**
	 *AJAX 动态获取数据
	 */
	public function ajaxgetCheckResultAction() {
		$page                 = intval($this->getInput('page'));
		$page                 = max(1, $page);
		$pageSize             = intval($this->getInput('pageSize'));
		$pageSize             = max(30, $pageSize);
		$params               = array();
		$params['status']     = 1;
		$params['start_time'] = array('<=', time());
		$params['end_time']   = array('>=', time());
		$dataList             = Gionee_Service_Ng::getList($page, $pageSize, $params);
		$j                    = 0;
		$data                 = array();
		foreach ($dataList[1] as $k => $v) {
			if (empty($v['link'])) {
				$data[$j] = array(
					'url'   => $v['link'],
					'desc'  => 'Bad URL!',
					'title' => $v['title'],
					'id'    => $v['id'],
				);
				$j++;
			} else {
				$urls[] = $v['link'];
				$info[] = array('title' => $v['title'], 'id' => $v['id']);
			}
		}
		$out = $this->exec($urls);
		foreach ($out as $k => $v) {
			$err = '';
			if ($v['code'] == 404) {
				$err = '404 Error!';
			} elseif (empty($v['code'])) {
				$err = 'Bad URL!';
			}
			if ($err) {
				$data[$j] = array(
					'url'   => $v['url'],
					'desc'  => $err,
					'title' => $info[$k]['title'],
					'id'    => $info[$k]['id'],
				);
				$j++;
			}

		}
		exit (json_encode($data));
	}

	public function exec($urls) {
		$curl_setopt = array(
			CURLOPT_RETURNTRANSFER => 1, //结果返回给变量
			CURLOPT_HEADER         => 0, //要HTTP头不
			CURLOPT_NOBODY         => 1, //不要内容
			CURLOPT_TIMEOUT        => 60,//超时时间
		);
		$mh          = curl_multi_init();
		foreach ($urls as $i => $url) {
			$conn[$i] = curl_init($url);
			foreach ($curl_setopt as $key => $val) {
				curl_setopt($conn[$i], $key, $val);
			}
			curl_multi_add_handle($mh, $conn[$i]);
		}
		$active = false;

		do {
			$mrc = curl_multi_exec($mh, $active);
		} while ($mrc == CURLM_CALL_MULTI_PERFORM);

		while ($active and $mrc == CURLM_OK) {
			if (curl_multi_select($mh) != -1) {
				do {
					$mrc = curl_multi_exec($mh, $active);
				} while ($mrc == CURLM_CALL_MULTI_PERFORM);
			}
		}
		$res = array();
		foreach ($urls as $i => $url) {
			$res[$i]['url']  = $url;
			$res[$i]['code'] = curl_getinfo($conn[$i], CURLINFO_HTTP_CODE);
			curl_close($conn[$i]);
			curl_multi_remove_handle($mh, $conn[$i]); //释放资源
		}
		curl_multi_close($mh);
		return $res;
	}


//上线日志记录

	public function addLogAction() {
	}

	public function logPostAction() {
		$date    = $this->getInput('online_date');
		$title   = $this->getInput('title');
		$content = trim($_POST['content']);
		if (empty($date) || empty($title)) {
			$this->output('-1', '日期和内容不能为空');
		}
		$res = Gionee_Service_OnlineLog::add(array('online_date' => $date, 'title' => $title, 'content' => $content, 'admin_id' => $this->userInfo['uid'], 'add_time' => time()));
		if ($res) {
			$this->output('0', '添加成功');
		} else {
			$this->output('-1', '添加失败');
		}
	}


	/**
	 * 日志列表
	 */
	public function logListAction() {
		$page = $this->getInput('page');
		list($total, $dataList) = Gionee_Service_OnlineLog::getList(array(), array('add_time' => "DESC"), $page);
		foreach ($dataList as $k => $v) {
			$userinfo                   = Admin_Service_User::getUser($v['admin_id']);
			$dataList[$k]['admin_name'] = $userinfo['username'];
			$modifier                   = Admin_Service_User::getUser($v['edit_userid']);
			$dataList[$k]['modifier']   = $modifier ? $modifier['username'] : '';
		}
		$this->assign('userinfo', $this->userInfo);
		$this->assign('list', $dataList);
		$this->assign('pager', Common::getPages($total, $page, 20, $this->actions['loglist'] . "/?"));
	}

	public function editLogAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_OnlineLog::get($id);
		$this->assign('info', $info);
		$this->assign('id', $id);
	}

	public function editlogPostAction() {
		$id      = $this->getInput('id');
		$date    = $this->getInput('online_date');
		$title   = $this->getInput('title');
		$content = trim($_POST['content']);
		$uid     = $this->userInfo['uid'];
		$res     = Gionee_Service_OnlineLog::update($id, array('online_date' => $date, 'title' => $title, 'content' => $content, 'edit_userid' => $uid, 'edit_time' => time()));
		if ($res) {
			$this->output('0', '修改成功！');
		} else {
			$this->output('-1', '操作失败！');
		}
	}

	public function logDeleteAction() {
		$id  = $this->getInput('id');
		$res = Gionee_Service_OnlineLog::delete($id);
		if ($res) {
			$this->output('0', '修改成功！');
		} else {
			$this->output('-1', '操作失败！');
		}
	}

	/**
	 * type nav_news  导航新闻
	 * type out_news  聚合新闻
	 */
	public function cronrunAction() {
		$type = $this->getInput('type');
		if ($type == 'nav_news') {
			$out = Gionee_Service_Jhnews::run();
		} else if ($type == 'out_news') {
			$out = Gionee_Service_OutNews::run();
		}
		echo str_replace('\n', '<hr>', $out);
		exit;
	}

	/**
	 * 任务日志
	 */
	public function cronlogAction() {
		$d    = $this->getInput('date');
		$t    = $this->getInput('type');
		$page = $this->getInput('page');
		$page = max($page, 1);
		if (empty($d)) {
			$d = date('Y-m-d');
		}
		$sDate = strtotime("{$d} 00:00:00");
		$eDate = strtotime("{$d} 23:59:59");


		$where = array(
			'created_at' => array(array('>=', $sDate), array('<=', $eDate)),
		);

		if (!empty($t)) {
			$where['type'] = $t;
		}

		$orderBy = array('created_at' => 'desc');
		list($total, $list) = Gionee_Service_CronLog::getList($page, 50, $where, $orderBy);
		$pages = Common::getPages($total, $page, 50, $this->actions['cronLogUrl'] . "?date={$d}&");
		$this->assign('list', $list);
		$this->assign('date', $d);
		$this->assign('types', Gionee_Service_CronLog::$types);
		$this->assign('type', $t);
		$this->assign('pager', $pages);
	}

	/**
	 * 错误日志
	 */
	public function errlogAction() {
		$d    = $this->getInput('date');
		$t    = $this->getInput('type');
		$page = $this->getInput('page');
		$page = max($page, 1);
		if (empty($d)) {
			$d = date('Y-m-d');
		}
		$sDate = strtotime("{$d} 00:00:00");
		$eDate = strtotime("{$d} 23:59:59");


		$where = array(
			'created_at' => array(array('>=', $sDate), array('<=', $eDate)),
		);

		if (!empty($t)) {
			$where['type'] = $t;
		}

		$orderBy = array('created_at' => 'desc');
		list($total, $list) = Gionee_Service_ErrLog::getList($page, 50, $where, $orderBy);
		$pages = Common::getPages($total, $page, 20, $this->actions['errLogUrl'] . "?date={$d}&");
		$this->assign('list', $list);
		$this->assign('date', $d);
		$this->assign('types', Gionee_Service_ErrLog::$types);
		$this->assign('type', $t);
		$this->assign('page', $page);
		$this->assign('pager', $pages);

	}

	public function errLogDelAction() {
		$id  = $this->getInput('id');
		$res = Gionee_Service_ErrLog::delete($id);
		if ($res) {
			$this->output('0', '修改成功！');
		} else {
			$this->output('-1', '操作失败！');
		}
	}

	//收入统计
	public function incomeAction() {
		$page = $this->getInput('page');
		$page = max($page, 1);
		list($total, $dataList) = Gionee_Service_Income::getList($page, 20, array(), array('get_time' => 'DESC'));
		$this->assign('list', $dataList);
		$this->assign('pager', Common::getPages($total, $page, 20, $this->actions['incomeUrl'] . "/?"));
	}

	//添加收入日志
	public function addIncomeAction() {
	}

	public function incomePostAction() {
		$postData = $this->getInput(array('get_time', 'income', 'cps', 'cpc', 'cpt', 'cpa', 'push', 'font'));
		if (!$postData['get_time'] || !$postData['income']) $this->output('-1', '日期或总收入不能为空！');
		$postData['add_time'] = time();
		$postData['add_user'] = $this->userInfo['username'];
		$postData['get_time'] = strtotime($postData['get_time']);
		$total                = bcadd($postData['cps'], bcadd($postData['cpc'], bcadd($postData['cpt'], bcadd($postData['cpa'], $postData['push'], 2), 2), 2), 2);
		if ($postData['income'] != $total) {
			$this->output('-1', '总收入与其它各项收入之和不相等，请检查！');
		}
		$ret = Gionee_Service_Income::add($postData);
		if ($ret) {
			$this->output('0', '添加成功！');
		} else {
			$this->output('-1', '添加失败！');
		}
	}

	public function editIncomeAction() {
		$id   = $this->getInput('id');
		$data = Gionee_Service_Income::get($id);
		$this->assign('data', $data);
	}

	public function editIncomePostAction() {
		$postData = $this->getInput(array('get_time', 'income', 'cps', 'cpc', 'cpt', 'cpa', 'push', 'font', 'id'));
		if (!$postData['get_time'] || !$postData['income']) $this->output('-1', '日期或总收入不能为空！');
		$postData['get_time'] = strtotime($postData['get_time']);
		$total                = bcadd($postData['cps'], bcadd($postData['cpc'], bcadd($postData['cpt'], bcadd($postData['cpa'], $postData['push'], 2), 2), 2), 2);
		if ($postData['income'] != $total) {
			$this->output('-1', '总收入与其它各项收入之和不相等，请检查！');
		}
		$ret = Gionee_Service_Income::update($postData, $postData['id']);
		if ($ret) {
			$this->output('0', '编辑成功');
		} else {
			$this->output('-1', '编辑失败');
		}
	}

	public function incomeDelAction() {
		$id  = $this->getInput('id');
		$ret = Gionee_Service_Income::delete($id);
		if ($ret) {
			$this->output('0', '操作成功');
		} else {
			$this->output('-1', '编辑失败');
		}
	}

	//用户中心基本配置信息
	public function innermsgTplAction(){
		$params['3g_key'] = array('IN',array('recharge_msg_tpl','coupon_msg_tpl'));
		$msg = Gionee_Service_Config::getsBy($params);
		$data =array();
		foreach($msg as $k=>$v){
			$data[$v['3g_key']] = unserialize($v['3g_value']);
		}
		$this->assign('data', $data);
	}
	
	public function editMsgTplAction(){
		$postData = $this->getInput(array('recharge_msg_tpl','coupon_msg_tpl'));
		foreach ($postData as $key =>$val){
			Gionee_Service_Config::setValue($key, serialize($val));
		}
		$this->output('0','操作成功!');
	}
}
	

