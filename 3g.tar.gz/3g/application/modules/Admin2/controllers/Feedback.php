<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 反馈管理
 * @author tiger
 */
class FeedbackController extends Admin_BaseController {
	
	public $actions = array(
		'listUrl' => '/Admin2/Feedback/index',
	);
	
	public $perpage = 20;

	public function indexAction() {
		$page = intval($this->getInput('page'));
		$perpage = $this->perpage;
		$param = $this->getInput(array('topic_id'));
		$search = array();
		if ($param['topic_id']) $search['topic_id'] = $param['topic_id'];
		
		list($total, $topics) = Gionee_Service_Feedback::getList($page, $perpage, $search);
		
		$url = $this->actions['listUrl'].'/?' . http_build_query($search) . '&';
		$this->assign('pager', Common::getPages($total, $page, $perpage, $url));
		$this->assign('topics', $topics);
		$this->assign('param', $param);
	}
}