<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Enter description here ...
 * @author tiger
 *
 */
class SohuController extends Admin_BaseController {
	
	public $actions = array(
		'listUrl' => '/Admin2/Sohu/index',
		'addUrl' => '/Admin2/Sohu/add',
		'addPostUrl' => '/Admin2/Sohu/add_post',
		'editUrl' => '/Admin2/Sohu/edit',
		'editPostUrl' => '/Admin2/Sohu/edit_post',
		'deleteUrl' => '/Admin2/Sohu/delete',
		'uploadUrl' => '/Admin2/Sohu/upload',
		'uploadPostUrl' => '/Admin2/Sohu/upload_post',
	);
	
	public $perpage = 20;
	public $positions = array (
			'1'=>'顶部站点',
			'2'=>'轮播图片',
			'4'=>'文字链1',
			'5'=>'推荐广告',
			'6'=>'文字链2',
			'7'=>'文字链3',
			'8'=>'文字链4',
			'9'=>'底部站点',
	);	
	/**
	 * 
	 * Enter description here ...
	 */
	public function indexAction() {
		$page = intval($this->getInput('page'));
		$position = $this->getInput('position');
		$perpage = $this->perpage;
		$search = array();
		if ($position) $search['position'] = $position;
		list($total, $pics) = Gionee_Service_Sohu::getList($page, $perpage, $search, array('sort'=>'DESC', 'id'=>'DESC'));
		$url = $this->actions['listUrl'] .'/?'. http_build_query($param) . '&';
		 foreach ($pics as $k=>$v){
			if(!empty($v['partner_id'])){
				$parnter = Gionee_Service_Parter::get($v['partner_id']);
				$pics[$k]['parnter'] = $parnter['name'];
			}else{
				$pics[$k]['parnter'] = '内部';
			}
		} 
		$this->assign('positions', $this->positions);
		$this->assign('pics', $pics);
		$this->assign('search', $search);
		$this->assign('pager', Common::getPages($total, $page, $perpage, $url));
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function addAction() {
		$this->assign('cooperators', $this->_getAllPartners());
		$this->assign('attributes', $this->_getAllAttriubtes());
		$this->assign('positions', $this->positions);
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function add_postAction() {
		$info = $this->getPost(array('sort', 'title', 'position', 'link', 'pic', 'start_time', 'end_time', 'status','attribute','partner_id','color'));
		$info = $this->_cookData($info);
		$result = Gionee_Service_Sohu::addAd($info);
		if (!$result) $this->output(-1, '操作失败');
		$this->output(0, '操作成功');
	}
	
	/**
	 *
	 * Enter description here ...
	 */
	public function editAction() {
		$id = $this->getInput('id');
		$info = Gionee_Service_Sohu::getAd(intval($id));
		if(empty($info['attribute'])){
			$info['attribute'] = '普通';
		}
		$this->assign('parnters', $this->_getAllPartners());
		$this->assign('attriubtes', $this->_getAllAttriubtes());
		$this->assign('positions', $this->positions);
		$this->assign('info', $info);
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function edit_postAction() {
		$info = $this->getPost(array('id', 'sort', 'title', 'position', 'link', 'pic', 'start_time', 'end_time', 'status','attribute','partner_id','color'));
		$info = $this->_cookData($info);
		$ret = Gionee_Service_Sohu::updateAd($info, intval($info['id']));
		if (!$ret) $this->output(-1, '操作失败');
		$this->output(0, '操作成功.'); 		
	}

	private function _getAllPartners(){
		$coopterator = Gionee_Service_Parter::getAll(array('id'=>'DESC'));
		array_unshift($coopterator, array('id'=>0,'name'=>'内部','url'=>''));
		return $coopterator;
	}
	
	private  function _getAllAttriubtes(){
		$attriutes = Gionee_Service_Attribute::getAll();
		array_unshift($attriutes, array('id'=>0,'name'=>'普通'));
		return $attriutes;
	}
	/**
	 * 
	 * Enter description here ...
	 */
	private function _cookData($info) {
		if(!$info['link']) $this->output(-1, '广告链接不能为空.'); 
		if (strpos($info['link'], 'http://') === false || !strpos($info['link'], 'https://') === false) {
			$this->output(-1, '链接地址不规范.');
		} 
		if(!$info['start_time']) $this->output(-1, '开始时间不能为空.');
		if(!$info['end_time']) $this->output(-1, '结束时间不能为空.');
		if($info['end_time'] <= $info['start_time']) $this->output(-1, '开始时间不能小于结束时间.');
		$info['start_time'] = strtotime($info['start_time']);
		$info['end_time'] = strtotime($info['end_time']);
		if($info['position'] != 2 && $info['position'] != 5){
			$info['pic'] = '';
		}else{
			if(!$info['pic']) $this->output(-1, '广告图片不能为空.');
		}
		
		return $info;
	}
		
	/**
	 * 
	 * Enter description here ...
	 */
	public function deleteAction() {
		$id = $this->getInput('id');
		$info = Gionee_Service_Sohu::getAd($id);
		if ($info && $info['id'] == 0) $this->output(-1, '无法删除');
		Util_File::del(Common::getConfig('siteConfig', 'attachPath') . $info['img']);
		$result = Gionee_Service_Sohu::deleteAd($id);
		if (!$result) $this->output(-1, '操作失败');
		$this->output(0, '操作成功');
	}

	/**
	 * 
	 * Enter description here ...
	 */
	public function uploadAction() {
		$imgId = $this->getInput('imgId');
		$this->assign('imgId', $imgId);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	/**
	 * 
	 * Enter description here ...
	 */
	public function upload_postAction() {
		$ret = Common::upload('img', 'ad');
		$imgId = $this->getPost('imgId');
		$this->assign('code' , $ret['data']);
		$this->assign('msg' , $ret['msg']);
		$this->assign('data', $ret['data']);
		$this->assign('imgId', $imgId);
		$this->getView()->display('common/upload.phtml');
		exit;
    }
}