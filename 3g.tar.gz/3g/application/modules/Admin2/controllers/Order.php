<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 用户中心交易订单管理类
 */
class OrderController extends Admin_BaseController {

	public $actions = array(
		'indexURL'    => '/Admin2/Order/index',
		'editURL'     => '/Admin2/Order/edit',
		'editPostURL' => '/Admin2/Order/editPost',
		'detailURL'   => '/Admin2/Order/detail'
	);

	public $pageSize = 20;


	public function indexAction() {
		$data   = $this->getInput(array('page', 'type'));
		$page   = max($data['page'], 1);
		$params = array();
		if (in_array($data['type'], array('-1', '1', '2'))) {
			switch ($data['type']) {
				case '-1': {
					$params['order_status'] = -1;
					$params['pay_status']   = 3;
					list($total, $dataList) = $this->_getDoneOrderInfo($page, $this->pageSize, $params, array('id' => 'DESC'));
					break;
				}
				case '2': {
					$params['order_status'] = 2;
					$params['pay_status']   = 1;
					list($total, $dataList) = $this->_getDoneOrderInfo($page, $this->pageSize, $params, array('id' => 'DESC'));
					break;
				}
				default: {
				//$params['id'] = array('NOT IN',array("SELECT id FROM user_order_info WHERE ( (pay_status =1 AND order_status = 2) OR (pay_status=3 AND order_status =-1))"));
				list($total, $dataList) = $this->_getNeededHandleOrders($page, $this->pageSize, $params, array('add_time' => 'DESC'));
				break;
				}
			}
		}
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['indexURL'] . "?"));
	}

	//订单详情
	public function detailAction() {
		$order_id   = $this->getInput('order_id');
		$orderGoods = User_Service_OrderGoods::getsBy(array('order_id' => $order_id), array());
		$orderMsg   = User_Service_Order::get($order_id);
		$config     = Common::getConfig('userConfig');
		$actions    = User_Service_Actions::getsBy(array('order_id' => $order_id), array('add_time' => 'DESC'));
		$this->assign('actions', $actions);
		$this->assign('config', $config);
		$this->assign('order_id', $order_id);
		$this->assign('goods', $orderGoods);
		$this->assign('order', $orderMsg);
	}

	//修改订单状态
	public function authAction() {
		$postData = $this->getInput(array('pay_status', 'order_status', 'shipping_status'));
		$note     = $this->getInput('note');
		$orderId  = $this->getInput('order_id');
		if (!$orderId || !$postData['order_status']) {
			$this->output('-1', '参数有错!');
		}
		$ret = User_Service_Order::update($postData, $orderId);
		if ($postData['order_status'] == '-1' && $postData['pay_status'] == '3') { //订单取消且要退还积分时
			$out = Common_Service_User::changeUserScores($orderId, '11');
		} elseif ($postData['order_status'] == '2' && $postData['pay_status'] == '1') { //订单已经完成
			$out = Common_Service_User::changeUserScores($orderId, '12', '-');
		}
		//写管理员操作日志
		$result = $this->adminOperationLog($orderId, $note);
		if ($ret) {
			$this->output('0', '操作成功');
		} else {
			$this->output("-1", '操作失败！');
		}
	}


	// 写管理员操作日志
	public function adminOperationLog($orderId, $note) {
		if (!$orderId) return false;
		$order  = User_Service_Order::get($orderId);
		$params = array(
			'order_id'        => $orderId,
			'action_user'     => $this->userInfo['username'],
			'order_status'    => $order['order_status'],
			'pay_status'      => $order['pay_status'],
			'shipping_status' => $order['shipping_status'],
			'action_note'     => $note,
			'add_time'        => time()
		);
		return User_Service_Actions::add($params);
	}

	/**
	 * 获得待处理订单信息
	 */

	private function _getNeededHandleOrders($page, $pageSize, $where, $order) {
		list($total, $dataList) = User_Service_Order::unHandleOrders(($page - 1) * $pageSize, $pageSize, $where, $order);
		$list = $this->_handleOrderInfo($dataList);
		return array($total, $list);
	}

	/**
	 * 返回订单信息
	 */
	private function _getDoneOrderInfo($page, $pageSize, $where, $orderBy) {
		list($total, $list) = User_Service_Order::getList($page, $pageSize, $where, $orderBy);
		$dataList = $this->_handleOrderInfo($list);
		return array($total, $dataList);
	}

	/**
	 * 数据处理
	 * @return multitype:Ambigous <string, multitype:boolean NULL > unknown
	 */
	private function _handleOrderInfo($dataList = array()) {
		if (!is_array($dataList)) return false;
		$config = Common::getConfig('userConfig');
		foreach ($dataList as $k => $v) {
			$dataList[$k]['order_status']    = $v['order_status'] == '-1' ? "<span color='red'>" . $config['statusFlag'][$v['order_status']] . "</span>" : $config['statusFlag'][$v['order_status']];
			$dataList[$k]['pay_status']      = $config['pay_status'][$v['pay_status']];
			$dataList[$k]['shipping_status'] = $config['shipping_status'][$v['shipping_status']];
			$actionLog                       = User_Service_Actions::getBy(array('order_id' => $v['id']), array('add_time' => 'DESC'));
			if ($actionLog) {
				$dataList[$k]['last_operator'] = $actionLog['action_user'];
				$dataList[$k]['last_time']     = date('Y-m-d H:i:s', $actionLog['add_time']);
			}
			$userInfo                 = Gionee_Service_User::getUser($v['uid']);
			$dataList[$k]['username'] = $userInfo['real_name'] ? $userInfo['realname'] : $userInfo['username'];
		}
		return $dataList;
	}
}