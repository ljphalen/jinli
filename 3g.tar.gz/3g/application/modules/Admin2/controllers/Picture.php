<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * PictureController
 * @author rainkid
 *
 */
class PictureController extends Admin_BaseController {

	public $actions = array(
		'listUrl'           => '/Admin2/Picture/index',
		'addUrl'            => '/Admin2/Picture/add',
		'addPostUrl'        => '/Admin2/Picture/add_post',
		'editUrl'           => '/Admin2/Picture/edit',
		'editPostUrl'       => '/Admin2/Picture/edit_post',
		'editStatusPostUrl' => '/Admin2/Picture/edit_status_post',
		'deleteUrl'         => '/Admin2/Picture/delete',
		'uploadUrl'         => '/Admin2/Picture/upload',
		'uploadPostUrl'     => '/Admin2/Picture/upload_post',

	);

	public $perpage = 40;
	public $picturetype;

	public function init() {
		parent::init();
		$this->picturetype = array(
			'1' => array(
				'name' => '明星',
				'url'  => 'http://i.ifeng.com/getifengrss?cid=7120&ch=zd_jl_llq&vt=5'
			),
			'2' => array(
				'name' => '美女',
				'url'  => 'http://i.ifeng.com/getifengrss?cid=4858&ch=zd_jl_llq&vt=5'
			),
			'3' => array(
				'name' => '军事',
				'url'  => 'http://i.ifeng.com/getifengrss?cid=565&ch=zd_jl_llq&vt=5'
			),
			'4' => array(
				'name' => '光影故事',
				'url'  => 'http://i.ifeng.com/getifengrss?cid=1830&ch=zd_jl_llq&vt=5'
			),
			'5' => array(
				'name' => '汽车',
				'url'  => 'http://i.ifeng.com/getifengrss?cid=2080&ch=zd_jl_llq&vt=5'
			)
		);
	}

	public function indexAction() {
		$page = intval($this->getInput('page'));

		$type = $this->getInput('type_id');

		if ($type) {
			$param['type_id'] = $type;

			$perpage = $this->perpage;
			list($total, $picture) = Gionee_Service_Picture::getList($page, $perpage, $param);

			$this->assign('picture', $picture);
			$url = $this->actions['listUrl'] . '/?' . http_build_query($param) . '&';
			$this->assign('pager', Common::getPages($total, $page, $perpage, $url));
			$this->assign('type', $type);
			$this->assign('param', $param);
		}
		$this->assign('picturetype', $this->picturetype);

	}

	public function addAction() {
		$this->assign('picturetype', $this->picturetype);
	}

	public function add_postAction() {
		$info = $this->getPost(array('sort', 'img', 'big_img', 'title', 'url', 'content', 'pub_time', 'status', 'istop', 'start_time', 'type_id'));
		if (!$info['type_id']) $this->output(-1, '分类不能为空.');
		if (!$info['title']) $this->output(-1, '标题不能为空.');

		if (!$info['img']) $this->output(-1, '图片不能为空.');
		if (!$info['big_img']) $this->output(-1, '大图不能为空.');
		if (!$info['pub_time']) $this->output(-1, '发布时间不能为空.');
		if (!$info['start_time']) $this->output(-1, '开始时间不能为空.');
		$ret = Gionee_Service_Picture::addPicture($info);
		if (!$ret) $this->output(-1, '操作失败.');
		$this->output(0, '操作成功.');
	}

	public function editAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_Picture::getPicture(intval($id));
		$this->assign('info', $info);
		$this->assign('picturetype', $this->picturetype);
	}

	public function edit_postAction() {
		$info = $this->getPost(array('id', 'type_id', 'img', 'big_img', 'sort', 'title', 'url', 'content', 'pub_time', 'status', 'istop', 'start_time'));
		if (!$info['type_id']) $this->output(-1, '分类不能为空.');
		if (!$info['title']) $this->output(-1, '标题不能为空.');

		if (!$info['img']) $this->output(-1, '图片不能为空.');
		if (!$info['big_img']) $this->output(-1, '大图不能为空.');
		if (!$info['pub_time']) $this->output(-1, '发布时间不能为空.');
		if (!$info['start_time']) $this->output(-1, '开始时间不能为空.');
		$ret = Gionee_Service_Picture::updatePicture($info, $info['id']);
		if (!$ret) $this->output(-1, '操作失败.');
		$this->output(0, '操作成功.');
	}

	/**
	 * 批量修改状态
	 */
	public function edit_status_postAction() {
		$ids = $this->getPost(array('ids', 'oids'));
		if (!$ids['ids']) $this->output(-1, '请选择要显示的新闻.');
		//设置原选中的状态为0
		Gionee_Service_Picture::updateStatusByIds($ids['oids'], 0);

		$ret = Gionee_Service_Picture::updateStatusByIds($ids['ids'], 1);
		if (!$ret) $this->output(-1, '操作失败.');
		$this->output(0, '操作成功.');
	}

	public function deleteAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_Picture::getPicture($id);
		if ($info && $info['id'] == 0) $this->output(-1, '信息不存在无法删除');
		$ret = Gionee_Service_Picture::deletePicture($id);
		if (!$ret) $this->output(-1, '操作失败');
		$this->output(0, '操作成功');
	}

	public function uploadAction() {
		$imgId = $this->getInput('imgId');
		$this->assign('imgId', $imgId);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	public function upload_postAction() {
		$ret   = $this->_upload('img');
		$imgId = $this->getPost('imgId');
		$this->assign('code', $ret['data']);
		$this->assign('msg', $ret['msg']);
		$this->assign('data', $ret['data']);
		$this->assign('imgId', $imgId);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	private function _upload($name) {
		$img = $_FILES[$name];
		if ($img['error'] == 4) {
			exit(json_encode(array('error' => 1, 'message' => '请选择要上传的图片！')));
		}
		$allowType = array('jpg' => '', 'jpeg' => '', 'png' => '', 'gif' => '');
		$savePath  = BASE_PATH . 'data/attachs/picture/' . date('Ym');
		$uploader  = new Util_Upload($allowType);
		if (!$ret = $uploader->upload('img', date('His'), $savePath)) {
			return Common::formatMsg(-1, '上传失败');
		}
		$url = '/picture/' . date('Ym') . '/' . $ret['newName'];
		return Common::formatMsg(0, '', $url);
	}


}
