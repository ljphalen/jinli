<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class LogsController extends Admin_BaseController {

	public $pageSize = 20;
	public $actions = array(
		'scoreUrl'    => '/Admin2/Logs/score',
		'innerMsgUrl' => '/Admin2/Logs/innerMsg',
		'apiLogUrl'   => '/Admin2/Logs/rechargeLog',
	);

	/**
	 * 积分日志
	 */
	public function  scoreAction() {
		$page     = $this->getInput('page');
		$page     = max($page, 1);
		$postData = $this->getInput(array('group_id', 'score_type', 'start_time', 'end_time', 'tel'));
		$params   = array();
		if ($postData['group_id']) {
			$params['group_id'] = $postData['group_id'];
		}
		if ($postData['score_type']) {
			$params['score_type'] = $postData['score_type'];
		}
		if ($postData['start_time']) {
			$params['add_time'] = array('>=', strtotime($postData['start_time']));
		}
		if ($postData['end_time']) {
			$params['add_time'] = array('<=', strtotime($postData['end_time']));
		}
		if ($postData['tel']) {
			$userMsg = Gionee_Service_User::getUserByName($postData['tel']);
			if ($userMsg) {
				$params['uid'] = $userMsg['id'];
			}
		}
		$urlParams = array(
			'group_id'=>$postData['group_id'],
			'score_type'=>$postData['score_type'],
			'add_time'	=>$postData['add_time'],
			'end_time'=>$postData['end_time'],
			'tel'			=>$postData['tel']
		);
		
		list($total, $dataList) = User_Service_ScoreLog::getList($page, $this->pageSize, $params, array('id' => 'DESC'));
		foreach ($dataList as $k => $v) {
			$user                       = Gionee_Service_User::getUser($v['uid']);
			$dataList[$k]['user_phone'] = $user['username'];
		}
		$this->assign('groups', Common::getConfig('userConfig', 'action_type'));
		$this->assign('scoreTypes', $this->_getActionTypes($postData['group_id']));
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['indexUrl']."?".http_build_query($urlParams) ."&"));
		$this->assign('postData', $postData);
	}

	/**
	 * 站内信
	 */
	public function innerMsgAction() {
		$page = $this->getInput('page');
		$page = max($page, 1);
		list($total, $dataList) = User_Service_InnerMsg::getList($page, $this->pageSize, array(), array('id' => 'DESC'));
		foreach ($dataList as $k => $v) {
			$userMsg                  = Gionee_Service_User::getUser($v['uid']);
			$dataList[$k]['username'] = $userMsg['username'];
		}
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['innerMsgUrl'] . "?"));
	}

	/**
	 * ajax 动态得到积分变动的类型
	 * @return boolean
	 */
	public function ajaxGetScoreActionByGroupIdAction() {
		$group_id = $this->getInput('group_id');
		if (!$group_id) return false;
		$this->output('0', '', $this->_getActionTypes($group_id));
	}

	public function rechargeLogAction() {
		$page = $this->getInput('page');
		$page = max($page, 1);
		list($total, $dataList) = User_Service_Recharge::getList($page, $this->pageSize, array(), array('id' => 'DESC'));
		$config = Common::getConfig('userConfig');
		foreach ($dataList as $k => $v) {
			$dataList[$k]['rechage_type']    = $config['pay_status'][$v['status']];
			$dataList[$k]['add_time']        = date('Y-m-d H:i:s', $v['add_time']);
			$description                     = json_decode($v['desc'], true);
			$dataList[$k]['msg']             = $description['orderinfo'] ? $description['orderinfo']['err_msg'] : $description['err_msg'];
			$dataList[$k]['api_type']        = $config['ofpay_api_log'][$v['api_type']];
			$dataList[$k]['recharge_status'] = $config['recharge_status'][$v['status']];
		}
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['apiLogUrl'] . "?"));
	}

	private function _getActionTypes($group_id) {
		$actions = Common::getConfig('userConfig', 'actions');
		if (!$group_id) return $actions;
		$data = array();
		foreach ($actions as $k => $v) {
			if ($group_id == '2') {//产生积分
				if (in_array(substr($k, 0, 1), array('1', '2'))) {
					$data[$k] = $v;
				}
			} elseif ($group_id == '3') {
				if (in_array(substr($k, 0, 1), array('3', '4'))) {
					$data[$k] = $v;
				}
			}
		}
		return $data;
	}
}