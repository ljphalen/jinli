<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Enter description here ...
 * @author rainkid
 *
 */
class StatController extends Admin_BaseController {

	public $actions = array(
		'listUrl'    => '/Admin2/Stat/index',
		'shortUrl'   => '/Admin2/Stat/shorturl',
		'content'    => '/Admin2/Stat/content',
		'column'     => '/Admin2/Stat/column',
		'leading'    => '/Admin2/Stat/leading',
		'cooperate'  => '/Admin2/Stat/cooperate',
		'hotwords'   => '/Admin2/Stat/hotwords',
		'amount'     => '/Admin2/Stat/amount',
		'topicList'  => '/Admin2/Stat/topicList',
		'topic'      => '/Admin2/Stat/topic',
		'uvUrl'      => '/Admin2/Stat/uv',
		'fedmsg'     => '/Admin2/Stat/feedbackDetail',
		'search'     => '/Admin2/Stat/baiduSearch',
		'monkeytime' => '/Admin2/Stat/monkeytime',

	);

	public $perpage = 20;
	public $pgaeCategory = array('nav' => '导航页', 'news' => '新闻页', 'games' => '轻应用');
	public $positions = array(
		'0' => '全部',
		'1' => '顶部站点',
		'2' => '轮播图片',
		'4' => '文字链1',
		'5' => '推荐广告',
		'6' => '文字链2',
		'7' => '文字链3',
		'8' => '文字链4',
		'9' => '底部站点',
	);


	/**
	 *
	 * Enter description here ...
	 */
	public function uvAction() {
		$sDate = $this->getInput('sdate');
		$eDate = $this->getInput('edate');
		$quick = $this->getInput('quick');
		!$sDate && $sDate = date('Y-m-d', strtotime("-100 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("today"));

		//ip
		list($list, $lineData) = Gionee_Service_Stat::getUvLineData($sDate, $eDate);
		//导航UV
		$params   = array(Gionee_Service_Log::TYPE_NEWS_CONTENT_UV => '新闻内容UV');
		$dataList = Gionee_Service_Stat::getUvData($params, $sDate, $eDate);
		if ($dataList) {
			if ($dataList[Gionee_Service_Log::TYPE_NEWS_CONTENT_UV]) {
				array_push($lineData, $dataList[Gionee_Service_Log::TYPE_NEWS_CONTENT_UV]);
			}
		}

		//新闻内容页
		$NavContents = Gionee_Service_Log::getSumByChannel(array('sdate' => strtotime($sDate), 'edate' => strtotime($eDate)), Gionee_Service_Log::TYPE_CONTENT_UV, array('date'), array('date'));
		if ($NavContents) {
			$data = array();
			foreach ($NavContents as $v) {
				$data['name']   = '导航内容UV';
				$data['data'][] = array((intval(strtotime($v['date'])) * 1000), intval($v['total']));
			}
			array_push($lineData, $data);
		}
		//导航内容UV
		$this->assign('list', $list);
		$this->assign('lineData', json_encode($lineData));
		$this->assign('dataList', $dataList);
		$this->assign('contentUv', $NavContents);
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('yesterday', date('Y-m-d', strtotime("-1 day")));
		$this->assign('weekday', date('Y-m-d', strtotime("-8 day")));
		$this->assign('monthday', date('Y-m-d', strtotime("-2 month")));
		$this->assign('threemonth', date('Y-m-d', strtotime('-3 month')));
		$this->assign('quick', $quick);
	}


	/**
	 *
	 * Enter description here ...
	 */
	public function pv2Action() {
		$sDate = $this->getInput('sdate');
		$eDate = $this->getInput('edate');
		!$sDate && $sDate = date('Y-m-d', strtotime("-8 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("today"));
		$keys = Gionee_Service_Log::$pvKeys;
		//pv
		$lineData = Gionee_Service_Log::getStatData(Gionee_Service_Log::TYPE_PV, $keys, date('Ymd', strtotime($sDate)), date('Ymd', strtotime($eDate)));
		$date     = array();
		for ($i = strtotime($sDate); $i <= strtotime($eDate); $i += 86400) {
			$date[] = date('Y-m-d', $i);
		}

		$list = array();
		foreach ($lineData as $k => $v) {
			foreach ($date as $kdv) {
				$list[$k][$kdv] = isset($v[$kdv]) ? intval($v[$kdv]) : 0;
			}
		}

		$this->assign('lineData', $list);
		$this->assign('type', Gionee_Service_Log::TYPE_PV);
		$this->assign('key', implode(',', $keys));
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('date', $date);
	}

	public function uv2Action() {
		$sDate = $this->getInput('sdate');
		$eDate = $this->getInput('edate');
		!$sDate && $sDate = date('Y-m-d', strtotime("-8 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("today"));
		$keys =  Gionee_Service_Log::$uvKeys;
		//uv
		$lineData = Gionee_Service_Log::getStatData(Gionee_Service_Log::TYPE_UV, $keys, date('Ymd', strtotime($sDate)), date('Ymd', strtotime($eDate)));
		$date     = array();
		for ($i = strtotime($sDate); $i <= strtotime($eDate); $i += 86400) {
			$date[] = date('Y-m-d', $i);
		}

		$list = array();
		foreach ($lineData as $k => $v) {
			foreach ($date as $kdv) {
				$list[$k][$kdv] = isset($v[$kdv]) ? intval($v[$kdv]) : 0;
			}
		}

		$this->assign('lineData', $list);
		$this->assign('type', Gionee_Service_Log::TYPE_UV);
		$this->assign('key', implode(',', $keys));
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('date', $date);
	}

	public function uv3Action() {
		$ym = $this->getInput('ym');
		if (empty($ym)) {
			$ym = date('Ym');
		}
		$type = $this->getInput('type');

		$types = array(
			Gionee_Service_Log::TYPE_URL_UV,
			Gionee_Service_Log::TYPE_NEWS_UV,
			Gionee_Service_Log::TYPE_CONTENT_UV,
		);
		if (empty($type)) {
			$type = $types[0];
		}
		$list = Gionee_Service_Log::getTotalByMonth($type, $ym);

		$this->assign('lineData', $list);
		$this->assign('type', $type);
		$this->assign('types', $types);
		$this->assign('ym', $ym);
	}

	public function shorturlAction() {
		$type = $this->getInput('type');
		if (empty($type)) {
			$type = Gionee_Service_Log::TYPE_URL;
		}

		$page   = $this->getInput('page');
		$sDate  = $this->getInput('sdate');
		$eDate  = $this->getInput('edate');
		$export = $this->getInput('export');
		$urlVal = $this->getInput('url_val');
		!$sDate && $sDate = date('Y-m-d', strtotime("-8 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("today"));

		$types = array(Gionee_Service_Log::TYPE_URL, Gionee_Service_Log::TYPE_URL_UV);
		$where = array();
		if (!empty($urlVal)) {
			$where['url'] = array('LIKE', urldecode($urlVal));
		}
		//总URL数
		$total = Gionee_Service_ShortUrl::getTotal($where);

		$pageSize = $this->perpage;
		if ($export) {
			$pageSize = $total;
		}
		$keys = $hashVal = $list = array();
		$urls = Gionee_Service_ShortUrl::getList($page, $pageSize, $where);
		if ($urls) {

			foreach ($urls as $val) {
				$keys[]               = $val['key'];
				$info                 = json_decode($val['mark'], true);
				$hashVal[$val['key']] = $val['url'] . "({$info['id']},{$info['type']})";
			}
			$lineData = Gionee_Service_Log::getUrlList($keys, date('Ymd', strtotime($sDate)), date('Ymd', strtotime($eDate)), $type);
			$date     = array();
			for ($i = strtotime($sDate); $i <= strtotime($eDate); $i += 86400) {
				$date[] = date('Y-m-d', $i);
			}

			foreach ($lineData as $k => $v) {
				foreach ($date as $kdv) {
					$list[$k][$kdv] = isset($v[$kdv]) ? intval($v[$kdv]) : 0;
				}
			}

			if ($export) {
				$this->_exportCloumn($list, $sDate, $eDate, 'shorturl', array('date' => $date, 'url' => $hashVal));
				exit();
			}
		}

		$this->assign('lineData', $list);
		$this->assign('hashVal', $hashVal);
		$this->assign('total', $total);
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['shortUrl'] . "/?sdate={$sDate}&edate={$eDate}&url_val={$urlVal}&type={$type}&"));
		$this->assign('date', $date);
		$this->assign('url_val', $urlVal);
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('types', $types);
		$this->assign('type', $type);
	}


	public function tourlAction() {
		$sDate = $this->getInput('sdate');
		$eDate = $this->getInput('edate');
		!$sDate && $sDate = date('Y-m-d', strtotime("-8 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("today"));

		$tmp  = Gionee_Service_Config::getValue('recwebsite_tourl');
		$urls = json_decode($tmp, true);

		$keys = $hashVal = array();
		foreach ($urls as $key => $url) {
			$t           = crc32($url . 1 . 'TOURL' . Common::$urlPwd);
			$keys[]      = $t;
			$hashVal[$t] = $key . ":({$url})";
		}
		$lineData = Gionee_Service_Log::getUrlList($keys, date('Ymd', strtotime($sDate)), date('Ymd', strtotime($eDate)));
		$date     = array();
		for ($i = strtotime($sDate); $i <= strtotime($eDate); $i += 86400) {
			$date[] = date('Y-m-d', $i);
		}

		$list = array();
		foreach ($lineData as $k => $v) {
			foreach ($date as $kdv) {
				$list[$k][$kdv] = isset($v[$kdv]) ? intval($v[$kdv]) : 0;
			}
		}

		$this->assign('lineData', $list);
		$this->assign('hashVal', $hashVal);
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('date', $date);
	}

	/**
	 * 导航页统计
	 */
	public function ngAction() {
		$data_post = $this->getInput(array('sdate', 'edate', 'column_id', 'type_id', 'channel', 'dataType', 'tab'));
		$sDate     = $data_post['sdate'];
		$eDate     = $data_post['edate'];
		$type_id   = $data_post['type_id'];
		$column_id = $data_post['column_id'];
		!$sDate && $sDate = date('Y-m-d', strtotime("-8 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("today"));
		$other = array();
		if ($data_post['channel'] != 'all') {
			if ($data_post['channel'] == 'com') {
				$other['ver'] = ' ';
			} else {
				$other['ver'] = $data_post['channel'];
			}
		}
		$colType  = Gionee_Service_Log::TYPE_NAV;
		$lineData = Gionee_Service_Log::getNgColumnData($column_id, date('Ymd', strtotime($sDate)), date('Ymd', strtotime($eDate)), $colType, $other);
		$date     = array();
		for ($i = strtotime($sDate); $i <= strtotime($eDate); $i += 86400) {
			$date[] = date('Y-m-d', $i);
		}
		$list = array();
		foreach ($lineData as $k => $v) {
			$info  = Gionee_Service_Ng::get($k);
			$title = $info['title'];
			foreach ($date as $kdv) {
				$list[$k]['title'] = $title;
				$list[$k][$kdv]    = isset($v[$kdv]) ? intval($v[$kdv]) : 0;
			}
		}
		$types    = Gionee_Service_NgType::getAll();
		$columns  = Gionee_Service_NgColumn::getAll();
		$channels = Gionee_Service_Vendor::getAll(); //获得所有渠道号
		array_unshift($channels, array('id' => '-1', 'name' => '全部', 'ch' => 'all'), array('id' => '0', 'name' => '普通', 'ch' => 'com'));
		$this->assign('channels', $channels);
		$this->assign('channel', $data_post['channel']); //渠道号
		$this->assign('param', $data_post);
		$this->assign('column_id', $column_id);
		$this->assign('type_id', $type_id);
		$this->assign('types', $types);
		$this->assign('columns', $columns);
		$this->assign('lineData', $list);
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('date', $date);
	}


	/**
	 * 内容点击统计表
	 */
	public function contentAction() {
		$postData = $this->getInput(array('page_id', 'column_id', 'type_id', 'content', 'url'));
		list($page, $sDate, $eDate) = $this->_getParams();
		$params = array();
		//构建条件查询
		$urlParams = '';
		if (!empty($postData['content'])) { //按URL查询
			$params['title'] = array('LIKE', $postData['content']);
		}
		if (!empty($postData['url'])) {
			$params['link'] = array('LIKE', $postData['url']);
		}
		$urlParams .= "/?sdate={$sDate}&edate={$eDate}&content={$postData['content']}&url={$postData['url']}"; //分页查询时参数
		$page_id = $postData['page_id'] ? $postData['page_id'] : '0';
		if (!empty($page_id)) { //page_id不为空时，type_id和culumn_id 才有意义
			$urlParams .= "&page_id={$postData['page_id']}";
			if (!empty($postData['type_id'])) {
				$params['type_id'] = $postData['type_id']; //分类查询
				$urlParams .= "&type_id={$postData['type_id']}";
			}
			if (!empty($postData['column_id'])) {
				$params['column_id'] = $postData['column_id']; //栏目查询
				$urlParams .= "&column_id={$postData['column_id']}";
			}
		}

		//数据导出
		$export = $this->getInput('export'); //是否导出标识
		if ($export) {
			$this->_export($params, array('sdate' => $sDate, 'edate' => $eDate));
			exit;
		} else {
			list($total, $dataList) = Gionee_Service_Ng::getList($page, $this->perpage, $params, array('status' => 'DESC', 'sort' => 'DESC', 'id' => 'DESC')); //获得所有条件查询的数据
			foreach ($dataList as $k => $v) {
				$subTotal                 = Gionee_Service_Log::getNgTotalNumber(array('key' => $v['id'], 'sdate' => strtotime($sDate), 'edate' => strtotime($eDate), 'type' => Gionee_Service_Log::TYPE_NAV));
				$dataList[$k]['sumTotal'] = $subTotal;
				$typeInfo                 = Gionee_Service_NgType::get($v['type_id']);
				$dataList[$k]['pageType'] = $typeInfo['page_id'] == 1 ? '首页分类' : ($typeInfo['pape_id'] == 2 ? '子页分类' : '暂无');

				$dataList[$k]['typeName']   = $typeInfo['name'];
				$columnInfo                 = Gionee_Service_NgColumn::get($v['column_id']);
				$dataList[$k]['columnName'] = $columnInfo['name'];
			}
			$types   = Gionee_Service_NgType::getAll();
			$columns = Gionee_Service_NgColumn::getAll();
			$this->assign('types', $types);
			$this->assign('columns', $columns);
			$this->assign('list', $dataList);
			$this->assign('param', $postData);
			$this->assign('sdate', $sDate);
			$this->assign('edate', $eDate);
			$this->assign('page_id', $page_id);
			$this->assign('pages', array('0' => '请选择', '1' => '首页分类', '2' => '子页分类'));
			$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['content'] . $urlParams . "&"));
		}
	}

	/**
	 * 栏目统计
	 */
	public function columnAction() {
		$postData = $this->getInput(array('type_id', 'page_type', 'page_id', 'channel', 'export', 'position_id'));
		list($page, $sDate, $eDate) = $this->_getParams();
		$channel     = $postData['channel'] ? $postData['channel'] : 'all';
		$page_id     = $postData['page_id'] ? $postData['page_id'] : '0'; //实际查询时不起作用
		$position_id = $postData['position_id'] ? $postData['position_id'] : '0';
		$export      = $postData['export'];
		$result      = array(); //查询后的最终结果
		$sum         = 0; //统计总点击数
		$pageFlag    = $postData['page_type'] ? $postData['page_type'] : 'nav'; //页面类型：导航页／新闻页
		switch ($pageFlag) {
			case 'nav': { //导航统计
				$p = array();
				$postData['type_id'] ? $p['type_id'] = $postData['type_id'] : '';
				if (in_array($channel, array('com', 'all'))) { //渠道统计条件
					list($total, $columnData) = $this->_getColumnData($p);
					$other = array();
					if ($channel == 'com') {
						$other['ver'] = '';
					}
					list($sum, $result) = $this->_getNgColumnCountInfo($columnData, $sDate, $eDate, $other);
				} else {
					list($sum, $result) = $this->_getNgColumnCountByChannel($channel, $sDate, $eDate, $page, $p);
				}
				break;
			}
			case 'news': { //新闻统计
				list($sum, $result, $total) = $this->_getShouHuCountInfo($position_id, $sDate, $eDate);
				break;
			}
			default:
				break;
		}
		if ($export) { //导出
			$this->_exportCloumn($result, $sDate, $eDate, $pageFlag);
			exit();
		} else {
			$result = array_slice($result, ($page - 1) * $this->perpage, $this->perpage);
		}
		$types       = Gionee_Service_NgType::getAll();
		$allChannels = Gionee_Service_Vendor::getAll();
		array_unshift($allChannels, array('ch' => 'all', 'name' => '全部'), array('ch' => 'com', 'name' => '普通'));
		$this->assign('list', $result);
		$this->assign('pages', array('0' => '请选择', '1' => '首页分类', '2' => '子页分类'));
		$this->assign('positions', $this->positions);
		$this->assign('elements', array('channels' => $allChannels, 'channel' => $channel, 'page_types' => $this->pgaeCategory,
		                                'pageFlag' => $pageFlag, 'param' => $postData, 'sdate' => $sDate, 'edate' => $eDate,
		                                'page_id'  => $page_id, 'types' => $types, 'sum' => $sum, 'position_id' => $position_id));
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['column'] . "?edate={$eDate}&sdate={$sDate}&type_id={$postData['type_id']}&page_type={$pageFlag}&page_id={$page_id}&channel={$channel}&"));
	}

	/**
	 * PC&导流统计
	 */
	public function leadingAction() {
		$attributes = array('普通', '导流', '广告');
		$postData   = $this->getInput(array('attrType', 'channel', 'partner_id', 'export'));
		list($page, $sDate, $eDate) = $this->_getParams();
		$attrType = $postData['attrType'] ? $postData['attrType'] : '普通'; //内容属性
		$params   = $p = array();
		if (in_array($attrType, array($attributes[1], $attributes[2]))) {
			$params['style'] = $attrType;
		} else {
			$params['style'] = array('NOT IN', array($attributes[1], $attributes[2]));
		}
		$partnerName = '';
		//添加合作商家查询条件
		if ($postData['partner_id'] > 0) {
			$partnerInfo = Gionee_Service_Parter::get($postData['partner_id']);
			$partnerName = $params['partner'] = $partnerInfo['name'];
		}
		$sum   = 0; // 满足条件的总点击数
		$total = Gionee_Service_Ng::count($params);
		if (in_array($postData['channel'], array('com', 'all'))) { //如果渠道不为空，则先查LOG表信息，否则先查NG表
			$dataList = Gionee_Service_Ng::getsBy($params, array('id' => 'DESC'));
			$elements = array();
			if ($postData['channel'] == 'com') { //普通渠道时
				$elements['ver'] = '';
			}
			foreach ($dataList as $k => $v) {
				$perMount                = Gionee_Service_Log::getNgTotalNumber(array_merge($elements, array('key' => $v['id'], 'sdate' => strtotime($sDate), 'edate' => strtotime($eDate), 'type' => Gionee_Service_Log::TYPE_NAV)));
				$dataList[$k]['clicked'] = $perMount;
				$sum += $perMount;
			}
			if (!$postData['export']) {
				$dataList = array_slice($dataList, $this->perpage * ($page - 1), $this->perpage);
			}
		} else {
			$p['ver']   = $postData['channel'];
			$p['sdate'] = strtotime($sDate);
			$p['edate'] = strtotime($eDate);
			$types      = array(Gionee_Service_Log::TYPE_NAV, Gionee_Service_Log::TYPE_TOPIC_CONTENT);
			$logData    = Gionee_Service_Log::getSumByChannel($p, $types, array('key'), array('key')); //所有内容统计信息
			$ids        = $click = array();
			foreach ($logData as $k => $v) {
				$tempArr            = explode('&', $v['key']);
				$ids[]              = $tempArr[0];
				$click[$tempArr[0]] = $v['total']; //点击数
			}
			$params['id'] = array('IN', $ids ? array_unique($ids) : array(0));
			$total        = Gionee_Service_Ng::count($params);
			$dataList     = Gionee_Service_Ng::getsBy($params, array('id' => 'DESC'));
			foreach ($dataList as $k => $v) {
				$dataList[$k]['clicked'] = $click[$v['id']];
				$sum += $click[$v['id']];
			}
			if (!$postData['export']) {
				$dataList = array_slice($dataList, $this->perpage * ($page - 1), $this->perpage);
			}
		}
		if ($postData['export']) {
			$this->_exportLeading($dataList, $partnerName, $attrType);
			exit;
		}
		$allChannel = Gionee_Service_Vendor::getAll();
		array_unshift($allChannel, array('name' => '全部', 'ch' => 'all'), array('name' => '普通', 'ch' => 'com'));
		$channelInfo = Gionee_Service_Vendor::getBy($postData['channel']);//渠道商家
		$partners    = Gionee_Service_Parter::getAll(); //获得所有合作商信息
		array_unshift($partners, array('id' => 0, 'name' => '全部'));
		$this->assign('list', $dataList);
		$this->assign('params', array('partners'    => $partners, 'partner_id' => $postData['partner_id'], 'cval' => $postData['channel'],
		                              'channelInfo' => $channelInfo, 'channels' => $allChannel, 'sdate' => $sDate, 'edate' => $eDate,
		                              'attrubutes'  => $attributes, 'attrType' => $attrType, 'sum' => $sum));
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['leading'] . "?sdate={$sDate}&edate={$eDate}&attrType={$postData['attrType']}&channel={$postData['channel']}&partner_id={$postData['partner_id']}&"));
	}


	/**
	 * 对外合作用户导流统计
	 */
	public function cooperateAction() {
		$postData = $this->getInput(array('sdate', 'edate', 'page', 'cooperate_id', 'export'));
		list($page, $sDate, $eDate) = $this->_getParams();
		$cid    = $postData['cooperate_id'] ? $postData['cooperate_id'] : '-1';
		$ventor = '普通';
		if ($cid > 0) {
			$cinfo  = Gionee_Service_Vendor::get($cid);
			$nid    = $cinfo['ch'];
			$ventor = $cinfo['name'];
		} else {
			$nid = '3g_nav';
		}
		$type = Gionee_Service_Log::TYPE_PV;
		//总点击数
		$tClicked = Gionee_Service_Log::getNgTotalNumber(array('key' => $nid, 'sdate' => strtotime($sDate), 'edate' => strtotime($eDate), 'ver' => '', 'type' => $type));
		$params   = array('type' => $type, 'key' => $nid, 'date' => array(array('>=', date('Ymd', strtotime($sDate))), array('<=', date('Ymd', strtotime($eDate)))));
		$pageSize = $this->perpage;
		if ($postData['export']) {
			$pageSize = (strtotime($eDate) - strtotime($sDate)) / (3600 * 24);
		}
		list($total, $dataList) = Gionee_Service_Log::getList($page, $pageSize, $params);
		if ($postData['export']) {
			$this->_exportCloumn($dataList, $sDate, $eDate, 'cooperate', array('vendor' => $cinfo['name']));
			exit;
		}
		$cooperators = Gionee_Service_Vendor::getAll();
		array_push($cooperators, array('id' => '-1', 'name' => '普通', 'ch' => ''));
		$this->assign('cooperator', $cooperators);
		$this->assign('sdate', $sDate);
		$this->assign('edate', $eDate);
		$this->assign('cid', $cid);
		$this->assign('ventor', $ventor);
		$this->assign('list', $dataList);
		$this->assign('amount', $tClicked);
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['cooperate'] . "?sdate={$sDate}&edate={$eDate}&cooperate_id={$cid}&"));
	}

	/**
	 * 导航热词统计
	 */
	public function hotwordsAction() {
		$type   = $this->getInput('type'); //查询类型 0，全部，1，后台添加 2，百度热词
		$type   = $type ? $type : 0;
		$export = $this->getInput('export');
		list($page, $sDate, $eDate) = $this->_getParams();
		$result = array();
		$sum    = $count = 0;

		//后台人工添加的统计
		if (in_array($type, array(0, 1))) {
			$ids          = array();
			$bd_column_id = Gionee_Service_Baidu::getColumnID();
			list($count, $dataList) = Gionee_Service_Ng::getList(1, $this->perpage, array('column_id' => $bd_column_id), array('id' => 'DESC'));
			foreach ($dataList as $v) {
				$ids[] = $v['id'];
			}
			if ($ids) {
				$calcuated = Gionee_Service_Log::getTotalByNidVer(array('sdate' => strtotime($sDate), 'edate' => strtotime($eDate), 'ids' => $ids));
				foreach ($calcuated as $v) {
					$temp[$v['key']] = $v['total'];
					$sum += $v['total'];
				}

				foreach ($dataList as $val) {
					$result[] = array('title' => $val['title'], 'clicked' => $temp[$val['id']]);
				}
			}
		}
		//百度热词的统计
		if (in_array($type, array(0, 2))) {
			$baiduAmount = Gionee_Service_Log::getSumByChannel(
				array('sdate' => strtotime($sDate), 'edate' => strtotime($eDate)), //where条件
				Gionee_Service_Log::TYPE_BAIDU_HOT, //类型
				array('key', 'ver'), array('key'),// group by
				array('total' => 'DESC')
			);
			foreach ($baiduAmount as $v) {
				$result[] = array('title' => $v['ver'], 'clicked' => $v['total']);
				$sum += $v['total'];
			}
		}
		//排序
		foreach ($result as $k => $v) {
			$num[$k] = $v['clicked'];
		}
		array_multisort($num, SORT_DESC, $result);
		$p['date'] = array(array('>=', date('Ymd', strtotime($sDate))), array('<=', date('Ymd', strtotime($eDate))));
		$p['type'] = Gionee_Service_Log::TYPE_BAIDU_HOT;
		$total     = Gionee_Service_Log::count($p);
		if ($export) {
			$this->_exportCloumn($result, $sDate, $eDate, 'hotwords');
			exit();
		}
		$result = array_slice($result, ($page - 1) * $this->perpage, $this->perpage);
		$this->assign('list', $result);
		$this->assign('sum', $sum);
		$this->assign('params', array('sdate' => $sDate, 'edate' => $eDate, 'page' => $page, 'type' => $type));
		$this->assign('types', array('0' => '全部', '1' => '手动', '2' => '百度热词'));
		$this->assign('pager', Common::getPages($total + $count, $page, $this->perpage, $this->actions['hotwords'] . "?sdate={$sDate}&edate={$eDate}&type={$type}&"));
	}


	/**
	 * 百度搜索统计
	 */
	public function baiduSearchAction() {
		$paramsData = $this->getInput(array('sdate', 'edate', 'page'));
		$page       = max(1, $paramsData['page']);
		$sDate      = $paramsData['sdate'];
		$eDate      = $paramsData['edate'];
		!$sDate && $sDate = date('Y-m-d', strtotime("-1 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("now"));
		$export = $this->getInput('export');
		if ($export) {
			list($total, $dataList) = Gionee_Service_Searchwords::getSearchHot(1, 100, $sDate, $eDate, array('content'), array('total' => 'DESC'));
			$this->_exportCloumn($dataList, $sDate, $eDate, 'search');
			exit();
		}
		list($total, $dataList) = Gionee_Service_Searchwords::getSearchHot($page, $this->perpage, $sDate, $eDate, array('content'), array('total' => 'DESC'));
		$this->assign('data', $dataList);
		$this->assign('params', array('sdate' => $sDate, 'edate' => $eDate));
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['search'] . "/?sdate={$sDate}&edate={$eDate}&"));
	}

	/**
	 * 当天总PV统计
	 */
	public function amountAction() {
		$export = $this->getInput('export');
		list($page, $sDate, $eDate) = $this->_getParams();
		$dataList = Gionee_Service_Log::getSumByChannel(array('sdate' => strtotime($sDate), 'edate' => strtotime($eDate)), 'url', array('date'), array('date'));
		$total    = count($dataList);
		$all      = 0; //指定时期内总点击量
		$temp     = $data = array();
		foreach ($dataList as $v) {
			$temp[$v['date']] = $v['total'];
			$all += $v['total'];
		}

		for ($i = strtotime($eDate); $i >= strtotime($sDate); $i -= 86400) {
			$formatDate = date('Ymd', $i);
			$data[]     = array('date' => $formatDate, 'click' => max(0, $temp[$formatDate]));
		}
		$total = count($data);
		if ($export) {
			$this->_exportCloumn($data, $sDate, $eDate, 'amount');
			exit();
		} else {
			$data = array_slice($data, ($page - 1) * $this->perpage, $this->perpage);
		}
		$this->assign('all', $all);
		$this->assign('dataList', $data);
		$this->assign('date', array('sdate' => $sDate, 'edate' => $eDate));
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['amount'] . "?sdate={$sDate}&edate={$eDate}&"));


	}

	/**
	 * 专题列表
	 */

	public function topicListAction() {
		list($page, $sDate, $eDate) = $this->_getParams();
		//推广内容点击
		$data = Gionee_Service_Log::getSumByChannel('', Gionee_Service_Log::TYPE_TOPIC_CONTENT, array('key'), array('key'));
		$sum  = 0; //总点击量
		$list = array();
		foreach ($data as $val) {
			$temp = explode('&', $val['key']);
			$list[$temp[1]] += $val['total'];
			$sum += $val['total'];
		}
		list($total, $dataList) = Gionee_Service_Topic::getElements(array('id', 'title', 'like_num', 'status'), array(), array('id' => "DESC"), array(($page - 1) * $this->perpage, $this->perpage));
		foreach ($dataList as $k => $v) {
			$tmp   = 0;
			$ver   = '';
			$array = array();
			//URL点击统计
			$result = Gionee_Service_Log::getSumByChannel(array('ver' => $v['id']), array(Gionee_Service_Log::TYPE_TOPIC, Gionee_Service_Log::TYPE_TOPIC_LIST, Gionee_Service_Log::TYPE_TOPIC_MAIN), array('type', 'key', 'ver'), array('type'));
			foreach ($result as $val) {
				$array[$val['type']] = $val['total'];
				$sum += $val['total'];
				if (in_array($val['type'], array('topic_main', 'topic_list'))) {
					$tmp += $val['total'];
				}
				$ver = $val['ver'];
			}
			$dataList[$k]['clickInfo'] = $array;
			$dataList[$k]['csum']      = $list[$v['id']] + $tmp;
		}
		//内容点击统计
		$export = $this->getInput('export');
		if ($export) {
			$this->_exportCloumn($dataList, $sDate, $eDate, 'topic');
			exit();
		}
		$this->assign('date', array('sdate' => $sDate, 'edate' => $eDate));
		$this->assign('dataList', $dataList);
		$this->assign('sum', $sum);
		$this->assign('pager', Common::getPages($total, $page, 5, $this->actions['topicList'] . "?sdate={$sDate}&edate={$eDate}&"));
	}

	/**
	 * 专题详细统计信息
	 */

	public function topicAction() {
		$id = $this->getInput('id');
		if (!$id) return false;
		$topicInfo = Gionee_Service_Topic::get($id);
		$topicCate = Gionee_Service_Log::getSumByChannel(array('ver' => $id), array(Gionee_Service_Log::TYPE_TOPIC, Gionee_Service_Log::TYPE_TOPIC_LIST, Gionee_Service_Log::TYPE_TOPIC_MAIN), array('type'), array('type'));
		$typeTotal = array();
		$sum       = 0;
		foreach ($topicCate as $v) {
			$typeTotal[$v['type']] = $v['total'];
			$sum += $v['total'];
		}
		$contentMsg = Gionee_Service_Log::getSumByChannel(array(), Gionee_Service_Log::TYPE_TOPIC_CONTENT, array('key', 'ver'), array('key'));
		$ng         = $topic = array();
		//获得每个专题中内容的详细点击信息
		$channel = array();
		foreach ($contentMsg as $v) {
			$temp = explode('&', $v['key']);
			$topic[$temp[1]] += $v['total']; //针对专题
			$ng[$temp[1]][$temp[0]] += $v['total'];
			$channel[$temp[1]][$temp[0]] = $v['ver'];
		}
		$params = $ngDatas = array();
		$ngKeys = array_keys($ng[$id]);
		if ($ngKeys) {
			$params['id'] = array('IN', $ngKeys);
			$ngDatas      = Gionee_Service_Ng::getsBy($params, array('id' => 'DESC'));
			foreach ($ngDatas as $key => $value) {
				$ngDatas[$key]['click'] = $ng[$id][$value['id']];
				$sum += $ng[$id][$value['id']];
				if ($channel) {
					$cinfo                  = Gionee_Service_Vendor::getBy($channel[$id][$value['id']]);
					$ngDatas[$key]['cname'] = $cinfo['name'] ? $cinfo['name'] : '--';
				} else {
					$ngDatas[$key]['cname'] = '普通';
				}
			}
		}
		//反馈信息
		$this->assign('sum', $sum);
		$this->assign('info', $topicInfo); //专题详细信息
		$this->assign('log', $typeTotal); //类型点击数
		$this->assign('content', $topic[$id]); //内容总点击
		$this->assign('ngData', $ngDatas); //内容详情
	}

	/**
	 * 意见统计
	 */

	public function suggestionAction() {
		list($page, $sDate, $eDate) = $this->_getParams();
		$params                = array();
		$params['create_time'] = array(array('>=', strtotime($sDate)), array("<=", strtotime($eDate)));
		list($total, $data) = Gionee_Service_Feedback::getFeedBackDatas(array('sum(num) as total', 'topic_id', 'option_num', 'create_time'), $params, array('topic_id', 'option_num'), array('topic_id' => 'DESC', 'create_time' => 'DESC'), array($this->perpage * ($page - 1), $this->perpage));
		$ids = array(0);
		foreach ($data as $k => $v) {
			$ids[]                  = $v['topic_id'];
			$data[$k]['detail_url'] = $this->actions['fedmsg'] . '?topic_id=' . $v['topic_id'] . '&option=' . $v['option_num'];
		}
		$topicInfo = array();
		list($sum, $topicList) = Gionee_Service_Topic::getElements(array('id', 'title', 'option'), array('id' => array("IN", array_unique($ids))), array('id' => 'DESC'));
		foreach ($topicList as $val) {
			$topicInfo[$val['id']] = array('name' => $val['title'], 'option' => explode("\n", $val['option']));
		}
		$this->assign('data', $data);
		$this->assign('topic', $topicInfo);
		$this->assign('pager', Common::getPages($total, $page, $this->perpage, $this->actions['suggestion'] . "?sdate={$sDate}&edate={$eDate}&"));
		$this->assign('date', array('sdate' => $sDate, 'edate' => $eDate));
	}

	/**
	 * 意见反馈详细信息
	 */
	public function feedbackDetailAction() {
		$postData = $this->getInput(array('page', 'topic_id', 'option'));
		list($total, $dataList) = Gionee_Service_Feedback::getList($postData['page'], $this->perpage, array('topic_id' => $postData['topic_id'], 'option_num' => $postData['option']), array('create_time' => 'DESC'));
		$topic = Gionee_Service_Topic::get($postData['topic_id']);
		$this->assign('topic', $topic);
		$this->assign('issues', explode("\n", $topic['option']));
		$this->assign('msg', $dataList);
		$this->assign('pager', Common::getPages($total, $postData['page'], $this->perpage, $this->actions['fedmsg'] . "?topic_id={$postData['topic_id']}&option={$postData['option']}&"));
	}

	/**
	 * 内容页数据导出
	 */
	public function _export($params = array(), $date = array()) {
		ini_set('memory_limit', '1024M');
		header('Content-Type: application/vnd.ms-excel;charset=GB2312');
		$filename = 'content-statistics-data ' . date('Ymd') . '.csv';
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment;filename=' . $filename);
		$out      = fopen('php://output', 'w');
		$typeName = $columnName = '';
		if (isset($params['type_id'])) {
			$types    = Gionee_Service_NgType::get($params['type_id']);
			$typeName = $types['name'];
		}
		if ($params['column_id']) {
			$columns    = Gionee_Service_NgColumn::get($params['column_id']);
			$columnName = $columns['name'];
		}
		$sum  = Gionee_Service_Ng::count($params);
		$list = Gionee_Service_Ng::getList(1, $sum, $params);
		fputcsv($out, array(chr(0xEF) . chr(0xBB) . chr(0xBF)));
		fputcsv($out, array('ID', '排序', '状态', '内容', '链接', '开始时间', '结束时间', '页面', '分类', '栏目', '属性', '点击量'));
		foreach ($list[1] as $val) {
			$sta     = $val['status'] == '1' ? '正常' : '已下线';
			$clicked = Gionee_Service_Log::getNgTotalNumber(array('key' => $val['id'], 'sdate' => strtotime($date['sdate']), 'edate' => strtotime($date['edate']), 'ver' => '', 'type' => Gionee_Service_Log::TYPE_NAV)); //点击数
			fputcsv($out, array($val['title'], $val['id'], $sta, $val['link'], date('Y-m-d', $date['start_time']), date('Y-m-d', $val['end_time']), 1, $typeName, $columnName, $val['id'], $val['style'], $clicked));
		}
		fclose($out);
	}

	/**
	 * 栏目统计数据导出CSV
	 */
	private function _exportCloumn($msg, $sdate, $edate, $flag, $other = array()) {
		ini_set('memory_limit', '1024M');
		header('Content-Type: application/vnd.ms-excel;charset=GB2312');
		$filename = '栏目统计' . $sdate . '至' . $edate . '.csv';
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment;filename=' . iconv('utf8', 'gb2312', $filename));
		$out = fopen('php://output', 'w');
		fputcsv($out, array(chr(0xEF) . chr(0xBB) . chr(0xBF)));
		switch ($flag) {
			case 'nav': {
				fputcsv($out, array('日期', '栏目', '所属页面', '点击量'));
				foreach ($msg as $v) {
					fputcsv($out, array($sdate . ' 至 ' . $edate, $v['name'], $this->pgaeCategory[$flag], $v['clicked']));
				}
				break;
			}
			case 'news': {
				fputcsv($out, array('日期', '标题', '点击量'));
				foreach ($msg as $v) {
					fputcsv($out, array($sdate . ' 至 ' . $edate, $v['title'], $v['clicked']));
				}
				break;
			}
			case 'cooperate': {
				fputcsv($out, array('日期', '合作商', '点击量'));
				foreach ($msg as $v) {
					fputcsv($out, array($v['date'], $other['vendor'], $v['val']));
				}
			}

			case 'hotwords': {
				fputcsv($out, array('日期', '关键词', '点击量'));
				foreach ($msg as $v) {
					fputcsv($out, array($sdate . ' 至 ' . $edate, $v['title'], $v['clicked']));
				}
				break;
			}

			case 'amount': {
				fputcsv($out, array('日期', '点击量'));
				foreach ($msg as $v) {
					fputcsv($out, array($v['date'], $v['click']));
				}
				break;
			}

			case 'topic': {
				fputcsv($out, array('专题名', '点赞', 'ＰＶ', '内容点击', 'ｐｖ/内容'));
				foreach ($msg as $v) {
					fputcsv($out, array($v['title'], $v['like_num'], $v['clickInfo']['topic'], $v['csum'], (bcdiv($v['clickInfo']['topic'], $v['csum'], 4) * 100) . "%"));
				}
				break;
			}
			case 'shorturl': {
				$title = array('短链接', 'Hash值');
				$title = array_merge($title, $other['date']);
				array_push($title, '合计');
				fputcsv($out, $title);
				foreach ($msg as $k => $v) {
					$temp = array();
					array_push($temp, $other['url'][$k]);
					array_push($temp, $k);
					$sum = 0;
					foreach ($other['date'] as $date) {
						$temp[] = $v[$date];
						$sum += $v[$date];
					}
					array_push($temp, $sum);
					fputcsv($out, $temp);
				}
			}
				break;
			case 'search':
				fputcsv($out, array('时间区间', '内容', '次数'));
				foreach ($msg as $v) {
					fputcsv($out, array($sdate . ' - ' . $edate, $v['content'], $v['total']));
				}
				break;
			default:
				break;
		}
		fclose($out);
	}

	/**
	 * 渠道商数据导出
	 */
	private function _exportLeading($data, $vendor, $attType) {

		ini_set('memory_limit', '1024M');
		header('Content-Type: application/vnd.ms-excel');
		$filename = 'leading-in-statistics-data ' . date('Ymd') . '.csv';
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment;filename=' . $filename);
		$out = fopen('php://output', 'w');

		fputcsv($out, array('合作商', '内容', 'URL', '点击量', '内容属性', '上线时间', '下线时间'));
		foreach ($data as $k => $v) {
			fputcsv($out, array($vendor, $v['title'], $v['link'], $v['clicked'], $attType, date('Y-m-d H:i:s', $v['start_time']), date('Y-m-d H:i:s', $v['end_time'])));
		}
		fclose($out);
	}

	/**
	 * 获取栏目数据
	 */
	private function _getColumnData($params) {
		$amount     = Gionee_Service_NgColumn::count($params); //总信息数
		$columnData = Gionee_Service_NgColumn::getList(1, $amount, $params);
		return $columnData;
	}

	/**
	 * 获得搜狐新闻的统计信息
	 * @param int $position_id
	 * @param int $page
	 * @param date $sDate
	 * @param date $eDate
	 * @param int $export
	 * @return array
	 */
	private function _getShouHuCountInfo($position_id, $sDate, $eDate) {
		$sum             = 0;
		$parms           = array();
		$parms['status'] = 1;
		if (intval($position_id) > 0) {
			$parms['position'] = $position_id;
		}
		list($total, $news) = Gionee_Service_Sohu::getsBy($parms, array('sort' => 'DESC', 'id' => 'DESC'));
		foreach ($news as $v) {
			$perAmount      = Gionee_Service_Log::getNgTotalNumber(array('key' => $v['id'], 'sdate' => strtotime($sDate), 'edate' => strtotime($eDate), 'type' => Gionee_Service_Log::TYPE_SOHU));
			$temp[$v['id']] = $perAmount;
			$sum += $perAmount;
		}
		$result = array();
		foreach ($news as $k => $v) {
			$result[] = array('title' => $v['title'], 'clicked' => $temp[$v['id']]);
		}
		return array($sum, $result, $total);
	}

	/**
	 * 获得栏目的统计信息
	 * @param array $columnData 需要统计的栏目
	 * @param date $sDate 开始时间
	 * @param date $eDate 结果时间
	 * @param array $other 其它参数
	 * @return array
	 */
	private function  _getNgColumnCountInfo($columnData, $sDate, $eDate, $other) {
		$sum       = 0;
		$detailSum = array();
		foreach ($columnData as $key => $val) { //先得到所有数据的统计信息
			$calculated       = Gionee_Service_Log::getNgColumnData($val['id'], date('Ymd', strtotime($sDate)), date('Ymd', strtotime($eDate)), Gionee_Service_Log::TYPE_NAV, $other);
			$temp[$val['id']] = 0;

			foreach ($calculated as $cal) {
				foreach ($cal as $k => $v) {
					$sum += $v;
					$temp[$val['id']] += $v;
					$detailSum[$val['id']][$k] += $v;
				}
			}
		}
		//var_dump($detailSum);exit;
		/*
	for($i = strtotime($sDate);$i<= strtotime($eDate);$i +=86400){
		$data[] = date('Y-m-d',$i);
	}
	*/
		$result = array();
		foreach ($columnData as $k => $v) {
			$result[$k]['id']       = $v['id'];
			$result[$k]['name']     = $v['name']; //获得栏目名
			$typeData               = Gionee_Service_NgType::get($v['type_id']);
			$result[$k]['typeName'] = $typeData['name'];
			$result[$k]['clicked']  = $temp[$v['id']];
			$result[$k]['details']  = $detailSum[$v['id']] ? $detailSum[$v['id']] : 0;
		}
		//var_dump($result);exit;
		return array($sum, $result);
	}


	/**
	 * 按渠道号统计信息
	 * @param var $channel
	 * @param date $sDate
	 * @param date $eDate
	 * @param int $page
	 * @param return array
	 */
	private function _getNgColumnCountByChannel($channel, $sDate, $eDate, $other = array()) {
		$p['ver']   = $channel;
		$p['sdate'] = strtotime($sDate);
		$p['edate'] = strtotime($eDate);
		$sum        = 0;
		$result     = array();
		$logData    = Gionee_Service_Log::getSumByChannel($p, Gionee_Service_Log::TYPE_NAV, array('key'), array('key')); //所有内容统计信息

		if ($logData) {
			$ids = $click = array();
			$sum = 0;
			foreach ($logData as $k => $v) {
				if (strpos($v['key'], '&')) {
					$tmpArr = explode('&', $v['key']);
					$ids[]  = $tmpArr[0];
					$click[$tmpArr[0]] += $v['total']; //点击数
				} else {
					$ids[] = $v['key'];
					$click[$v['key']] += $v['total'];
				}
			}
			$params['id'] = array('IN', $ids ? array_unique($ids) : array(0));
			$NgData       = Gionee_Service_Ng::getColumnidsByNgId($params);
			foreach ($NgData as $v) {
				$temp[$v['column_id']] = $v['id'];
			}
			$criteria['id'] = array('IN', array_keys($temp));
			if (isset($other['type_id'])) {
				$criteria['type_id'] = $other['type_id'];
			}
			$columnData = Gionee_Service_NgColumn::getsBy($criteria);
			foreach ($columnData as $v) {
				$typeInfo = Gionee_Service_NgType::get($v['type_id']);
				$result[] = array('id' => $v['id'], 'name' => $v['name'], 'clicked' => $click[$temp[$v['id']]], 'typeName' => $typeInfo['name']);
				$sum += $click[$temp[$v['id']]];
			}
		}

		return array($sum, $result);
	}

	/**
	 * 参数获取
	 */
	public function _getParams() {
		$paramsData = $this->getInput(array('sdate', 'edate', 'page'));
		$page       = max(1, $paramsData['page']);
		$sDate      = $paramsData['sdate'];
		$eDate      = $paramsData['edate'];
		!$sDate && $sDate = date('Y-m-d', strtotime("-8 day"));
		!$eDate && $eDate = date('Y-m-d', strtotime("+1 day"));
		return array($page, $sDate, $eDate);
	}

	public function monkeynumAction() {
		$date = $this->getInput('date');
		if (empty($date)) {
			$date = date('Ymd');
		}
		$list = Common::getCache()->hGetAll('MON_KEY_NUM:' . $date);
		arsort($list);
		$tmp = array();
		foreach ($list as $name => $num) {
			$t1 = Common::getCache()->hGetAll('MON_KEY_TIME:' . $date . ':' . $name);
			krsort($t1);
			$a1 = array_slice($t1, 0, 5);
			$s1 = array();
			foreach ($a1 as $ak => $av) {
				$s1[] = "[{$ak}=>{$av}]";
			}
			$tmp[$name] = array(
				'num'  => $num,
				'time' => implode(' ', $s1),
			);
		}
		$this->assign('date', $date);
		$this->assign('list', $tmp);
	}

	public function monkeytimeAction() {
		$date = $this->getInput('date');
		$name = $this->getInput('name');
		$list = Common::getCache()->hGetAll('MON_KEY_TIME:' . $date . ':' . $name);
		krsort($list);
		$this->assign('list', $list);
		$this->assign('date', $date);
		$this->assign('name', $name);
	}

}
