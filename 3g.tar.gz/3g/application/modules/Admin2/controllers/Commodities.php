<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class CommoditiesController extends  Admin_BaseController {
	
	/**
	 * 用户中心----积分兑换商品模块
	 * @var unknown
	 */
	public 	$actions = array(
		'indexUrl'		=>'/Admin2/Commodities/index',
		'addUrl'		=>'/Admin2/Commodities/add',
		'addPostUrl'	=>'/Admin2/commodities/addPost',
		'editUrl'		=>'/Admin2/Commodities/edit',
 		'editPostUrl'	=>'/Admin2/Commodities/editPost',
 		'deleteUrl'		=>'/Admin2/Commodities/delete',
 		'uploadUrl'		=>'/Admin2/Commodities/upload',
		'uploadPostUrl'=>'/Admin2/Commodities/upload_post',
 		'summaryUrl'	=>'/Admin2/Commodities/summary',
		'orderUrl'		=>'/Admin2/Commodities/order',
		'importUrl'		=>'/Admin2/Commodities/import',
		'exportUrl'		=>'/Admin2/Commodities/export',
	);
 	
 	public $pageSize = 20;
 	
 	public $types = array(
 			'1'=>'虚拟商品',
 			'2'=>'实物商品',
 	);
 	
 	public function indexAction(){
 		$page = $this->getInput('page');
 		list($total,$data) = User_Service_Commodities::getList($page, $this->pageSize,array(),array('id'=>'DESC'));
 		foreach($data as $k=>$v){
 			$category  = User_Service_Category::get($v['cat_id']);
 			$data[$k]['cat_name'] = $category['name'];
 		}
 		$this->assign('data', $data);
 		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['indexUrl']."/?"));
 		$this->assign('goodsType', $this->types);
 	}
 	
 	public function addAction(){
 		$catList = User_Service_Category::getsBy(array('status'=>1,'group_id'=>3),array('sort'=>'DESC','id'=>'DESC'));
 		$this->assign('category', $catList);
 		$this->assign('goodsType', $this->types);
 	}
 	
 	public function addPostAction(){
 		$postData = $this->getInput(array('cat_id', 'name','link','price','start_time','end_time','number' ,'is_special','goods_type','scores','sort','image','status','card_id'));
 		if(!$postData['cat_id']){
 			$this->output('-1','请先选择商品分类！');
 		}
 		$postData['description']  = htmlspecialchars($_POST['description']);
 		$postData['add_time'] =time();
 		$postData['add_user'] = $this->userInfo['username'];
 		$res = User_Service_Commodities::add($postData);
 		if($res){
 			$this->output('0','添加成功');
 		}else{
 			$this->output('-1','添加失败');
 		}
 	}
 	
 	public function editAction(){
 		$id = $this->getInput('id');
 		$data = User_Service_Commodities::get($id);
 		$catList = User_Service_Category::getsBy(array('status'=>1,'group_id'=>3),array('sort'=>'DESC','id'=>'DESC'));
 		$virtualTypes = User_Service_CardInfo::getCetegory(); //得到虚拟商品分类
 		$cardMsg = User_Service_CardInfo::get($data['card_id']);
 		$sCards = User_Service_CardInfo::getsBy(array('type_id'=>$cardMsg['type_id']));
 		$this->assign('scards', $sCards);
 		$this->assign('virtualTypes', $virtualTypes);
 		$this->assign('cat', $catList);
 		$this->assign('data', $data);
 		$this->assign('goodsType', $this->types);
 	}
 	public function editPostAction(){
 		$postData = $this->getInput(array('id','cat_id', 'name','link','price','start_time','end_time','number' ,'is_special','goods_type','scores','sort','image','status','card_id'));
 		$postData['description']  = htmlspecialchars($_POST['description']);
 		$postData['edit_time'] = time();
 		$postData['edit_user'] = $this->userInfo['username'];
 		$res = User_Service_Commodities::update($postData, $postData['id']);
 		if($res){
 			$this->output('0','编辑成功！');
 		}else{
 			$this->output('-1','编辑失败！');
 		}
 	}
 	
 	public function deleteAction(){
 		$id = $this->getInput('id');
 		$res = User_Service_Commodities::delete($id);
 		if($res){
 			$this->output('0','编辑成功！');
 		}else{
 			$this->output('-1','编辑失败！');
 		}
 	}

 	// ajax 获取可以设置用户等级权限的商品信息
 	public function ajaxGetDataAction(){
 		$cat_id = $this->getInput('type');
 		if(!$cat_id) {
 			echo json_encode( array('key'=>'-1','msg'=>'请选择正确的商品类别！'));
 			exit;
 		}
 		$params['status'] 		= 1;
 		//$params['is_special'] 	=1;
 		$params['start_time'] 	= array('<=',time());
 		$params['end_time']	= array('>=',time());
 		$params['cat_id'] = $cat_id;
 		$dataList = User_Service_Commodities::getsBy($params,array('sort'=>'DESC','id'=>"DESC"));
 		if($dataList){
 			$result = array('key'=>'1','msg'=>$dataList);
 		}else{
 			$result = array('key'=>'-1','msg'=>'没有合适的商品或其它错误，请检查！');
 		}
 		echo json_encode($result);
 	}
 	
 	//ajax得到礼品卡分类信息
 	public function AjaxGetCardMsgAction(){
 		$type_id = $this->getInput('type_id');
 		if($type_id){
 			$data = User_Service_CardInfo::getsBy(array('type_id'=>$type_id));
 		}else{
 			$data = User_Service_CardInfo::getCetegory();
 		}
 		$this->output('0','', ($data));
 	}
 	//订单管理
 	public function orderAction(){
 		$page  = $this->getInput('page');
 		list($total,$dataList) = User_Service_Order::getList($page, $this->pageSize,array(),array('id'=>'DESC'));
 		foreach ($dataList as $k=>$v){
 		}
 		$this->assign('data', $dataList);
 		$status = Common::getConfig('userConfig','statusFlag');
 		$this->assign('status', $status);
 		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['orderUrl']."/?"));
 		
 	}
 	//数据导入
 	public function importAction(){
 		if(!empty($_FILES['data'])){
 			$file = $_FILES['data']['tmp_name'];
 			$res = $this->_importData($file);
 			$this->output('0','操作成功！');
 		}
 	}
 	
 	//数据导出
 	public function exportAction(){
 		$res = $this->_exportData();
 		exit();
 	}
 	//上传图片
 	public function uploadAction() {
 		$imgId = $this->getInput('imgId');
 		$this->assign('imgId', $imgId);
 		$this->getView()->display('common/upload.phtml');
 		exit;
 	}
 	/**
 	 *
 	 * Enter description here ...
 	 */
 	public function upload_postAction() {
 		$ret   = Common::upload('img', 'commondity');
 		$imgId = $this->getPost('imgId');
 		$this->assign('imgId', $imgId);
 		$this->assign('data', $ret['data']);
 		$this->assign('code', $ret['code']);
 		$this->getView()->display('common/upload.phtml');
 		exit;
 	}
 	
 	public function _importData($file){
 		$fields = array('id','identifier', 'type_id', 'type_name','card_id','card_name');
 		$num = count($fields);
 		$row = 1;//初始值
 		if (($handle = fopen($file, "r")) !== false) {
 			while (($data = fgetcsv($handle, 1000, ",")) !== false) {
 				if($row >1){
 					$contents = array();
 					for($i = 0;$i< $num;$i++){
 						$contents[$fields[$i]] = $data[$i];
 					}
 					$contents['type_name'] =  iconv('GBK', 'UTF8', $contents['type_name']);
 					$contents['card_name'] =  iconv('GBK', 'UTF8', $contents['card_name']);
 					if(!empty($contents['id']) && !empty($contents['card_id']) && !empty($contents['type_id'])){ //更新
 						$meta = User_Service_CardInfo::get($contents['id']);
 						if($meta){
 							$out = User_Service_CardInfo::update($contents['id'],$contents);
 						}else{
 							$out = User_Service_CardInfo::add($contents);//添加
 						}
 					}else{
 						unset($contents['id']);
 						$out = User_Service_CardInfo::add($contents);//添加
 					}
 				}
 				$row ++;
 			}
 		}
 		fclose($handle);
 	}
 	
 	
 	private  function _exportData(){
 		$filename = '礼品卡信息' . date('YmdHis') . '.csv';
 		$list     = User_Service_CardInfo::getAll();
 		$headers = array('id','identifier', 'type_id', 'type_name','card_id','card_name');
 		header('Content-Type: text/csv');
 		header('Content-Disposition: attachment;filename=' . $filename);
 		$fp = fopen('php://output', 'w');
 		
 		fputcsv($fp, $headers);
 		foreach ($list as $fields) {
 			$row            = array(
 					$fields['id'],
 					$fields['identifier'],
 					$fields['type_id'],
 					$fields['type_name'] = iconv('UTF8', 'GBK', $fields['type_name']),
 					$fields['card_id'],
 					$fields['card_name'] = iconv('UTF8', 'GBK', $fields['card_name']),
 			);
 			fputcsv($fp, $row);
 		}
 		fclose($fp);
 		exit;
 	}
}