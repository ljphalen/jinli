<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 
 * Enter description here ...
 * @author rainkid
 *
 */
class IndexController extends Admin_BaseController {
	
	public $actions = array(
		'editpasswd' => '/Admin2/User/edit',
		'logout' => '/Admin2/Login/logout',
		'default' => '/Admin2/Index/default',
		'getdesc' => '/Admin2/Index/getdesc',
		'search' => '/Admin2/Index/search',
		'passwdUrl' => '/Admin2/User/passwd',
	);

	/**
	 * 
	 * Enter description here ...
	 */
	public function indexAction() {
		list($usermenu, $mainview, $usersite, $userlevels) = $this->getUserMenu();
		$this->assign('jsonmenu', json_encode($usermenu));
		$this->assign('mainmenu', $usermenu);
		$this->assign('mainview', json_encode(array_values($mainview)));
		$this->assign('username', $this->userInfo['username']);
		$this->assign('siteThemeList',parent::$siteThemeArr);
		$indexView = empty($this->currentTheme) || $this->currentTheme == 'default' ? 'index' : 'index_'.$this->currentTheme;
	
		$this->getView()->display('index/'.$indexView.'.phtml');
		
		return false;
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function defaultAction() {
		$this->assign('uid', $this->userInfo['uid']);
		$this->assign('username', $this->userInfo['username']);
	}
	
	public function themeAction() {
		$theme = $this->getInput('theme');
		if(!empty($theme) && in_array($theme,parent::$siteThemeArr)) {
			Util_Cookie::set('_theme_',$theme,false,time()+31536000);			
		}
		$this->redirect('/Admin2/Index/index');
		return false;
	}
	
}
