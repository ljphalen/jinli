<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class UsummaryController extends Admin_BaseController {
	
	public $pageSize = 20;
	public $actions = array(
				'scoreUrl'		=>'/Admin2/Usummary/score',
				'scoreDetailUrl'=>'/Admin2/Usummary/scoreDetail',
				'tasksUrl'		=>'/Admin2/Usummary/tasks',
	);
	
	public function indexAction(){
		
		
	}
	
	
	/**
	 * 积分统计
	 */
	public function scoreAction(){
		$page = $this->getInput('page');
		$page = max(1,$page);
		$params  = array();
		$params['score_type'] = array('IN',array('101','102','103','201','202','203','204')); //赚取积分的动作类型
		$params['group_id'] =array('IN',array('1','2'));
		list($total,$dataList) = User_Service_ScoreLog::getDayEarnScoresInfo($page, $this->pageSize, $params, array('date'), array('date'=>'DESC'));
		$scoresMsg = User_Service_Gather::getSumScoresInfo(); //总积分统计
		$this->assign('scoreMsg', $scoresMsg);
		$this->assign('data', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['scoreUrl'].'?'));
	}
	
	public function scoreDetailAction(){
		$postData = $this->getInput(array('page','date'));
		$page = max(1,$postData['page']);
		if(!$postData['date']) exit('参数有错！');
		$params  = array();
		$params['score_type'] = array('IN',array('101','102','103','201','202','203','204')); //赚取积分的动作类型
		$params['group_id'] =array('IN',array('1','2'));
		$params['date'] = $postData['date'];
		list($total,$list) = User_Service_ScoreLog::getList($page,$this->pageSize,$params,array('id'=>'DESC'));
		foreach ($list as $k=>$v){
			$user = Gionee_Service_User::getUser($v['uid']);
			$list[$k]['username'] = $user['username'];
		}
		$this->assign('list', $list);
		$this->assign('groupType', Common::getConfig('userConfig','action_type'));
		$this->assign('scoreTypes', Common::getConfig('userConfig','actions'));
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['scoreDetailUrl']."?date={$postData['date']}&"));
	}
	
	
	/**
	 * 任务统计
	 */
	
	public function tasksAction(){
		$page = $this->getInput('page');
		$page = max(1,$page);
		$params = array();
		$params['score_type'] = array('IN',array('101','102','103','201','202'));
		$params['group_id']		= array("IN",array('1','2'));
		list($total,$dataList) = User_Service_ScoreLog::getDoneTasksList($page, $this->pageSize,$params,array('date'),array('date'=>'DESC'));
		$allDoneMsg   = User_Service_ScoreLog::getTotalDoneTasksInfo($params);
		$this->assign('all', $allDoneMsg);
		$this->assign('dataList', $dataList);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['tasksUrl']."?"));
	}
}