<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 聚合新闻配置统计分类
 * @author rainkid
 */
class JhtjtypeController extends Admin_BaseController{
	
	public $actions = array(
		'listUrl' => '/Admin/Jhtjtype/index',
		'addUrl' => '/Admin/Jhtjtype/add',
		'addPostUrl' => '/Admin/Jhtjtype/add_post',
		'editUrl' => '/Admin/Jhtjtype/edit',
		'editPostUrl' => '/Admin/Jhtjtype/edit_post',
		'deleteUrl' => '/Admin/Jhtjtype/delete',
	);
	public $perpage = 20;

	public function indexAction() {
		$page = intval($this->getInput('page'));
		$perpage = $this->perpage;
		
		list($total, $tjs) = Gionee_Service_JhtjType::getList($page, $perpage);
		$this->assign('tjs', $tjs);
		$this->assign('pager', Common::getPages($total, $page, $perpage, $this->actions['listUrl'].'/?'));
	}

	public function addAction(){
	}

	public function add_postAction(){
		$info = $this->getPost(array('name', 'sort'));
		if (!$info['name']) $this->output(-1, '名称不能为空.');
		
		$ret = Gionee_Service_JhtjType::addTjtype($info);
		if (!$ret) $this->output(-1, '操作失败.');
		$this->output(0, '操作成功.');
	}

	public function editAction(){
		$id = $this->getInput('id');
		$info = Gionee_Service_JhtjType::getTjtype(intval($id));
		$this->assign('info', $info);
	}

	public function edit_postAction(){
		$info = $this->getPost(array('id','name', 'sort'));
		if (!$info['name']) $this->output(-1, '名称不能为空.');
		$ret = Gionee_Service_JhtjType::updateTjtype($info, $info['id']);
		if (!$ret) $this->output(-1, '操作失败.');
		$this->output(0, '操作成功.');
	}

	public function deleteAction() {
		$id = $this->getInput('id');
		$ret = Gionee_Service_JhtjType::deleteTjtype($id);
		if (!$ret) $this->output(-1, '操作失败');
		$this->output(0, '操作成功');
	}	
	

	private function _cookParent($parents, $channels) {
		$tmp = Common::resetKey($parents, 'id');
		foreach ($channels as $key=>$value) {
			$tmp[$value['parent_id']]['items'][] = $value;
		}
		return $tmp;
	}
}
