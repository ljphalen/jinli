<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 书签配置
 * @author tiger
 */
class BookmarkController extends Admin_BaseController {

	public $actions = array(
		'listUrl'       => '/Admin/Bookmark/index',
		'editUrl'       => '/Admin/Bookmark/edit',
		'editPostUrl'   => '/Admin/Bookmark/edit_post',
		'deleteUrl'     => '/Admin/Bookmark/delete',
		'uploadUrl'     => '/Admin/Bookmark/upload',
		'uploadPostUrl' => '/Admin/Bookmark/upload_post',
	);

	public $perpage = 20;

	public function indexAction() {
		$page    = intval($this->getInput('page'));
		$perpage = $this->perpage;
		$ver     = $this->getInput('ver');
		$where = array();
		if (!empty($ver)) {
			$where = array('ver' => array('&', $ver));
		}

		list($total, $bookmarks) = Gionee_Service_Bookmark::getList($page, $perpage, $where, array('sort' => 'ASC', 'id' => 'ASC'));
		$url = $this->actions['listUrl'] . '/?ver=' . $ver . '&';

		$this->assign('pager', Common::getPages($total, $page, $perpage, $url));
		$this->assign('bookmarks', $bookmarks);
		$this->assign('ver', $ver);
	}

	public function editAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_Bookmark::get(intval($id));
		$this->assign('info', $info);
	}

	public function edit_postAction() {
		$info = $this->getPost(array('id', 'name', 'icon', 'url', 'sort', 'backgroud', 'is_delete', 'ver', 'op_type', 'filter_ver'));
		$info = $this->_cookData($info);

		$info['ver'] = array_sum($info['filter_ver']);
		if (empty($info['id'])) {
			$ret = Gionee_Service_Bookmark::add($info);
		} else {
			$ret = Gionee_Service_Bookmark::update($info, intval($info['id']));
		}

		if (!$ret) {
			$this->output(-1, '操作失败');
		}
		$this->updataVersion($info['ver']);
		$this->output(0, '操作成功.');
	}

	private function _cookData($info) {
		if (empty($info['name']) || mb_strlen($info['name']) > 30) {
			$this->output(-1, '名称非法');
		}

		if (empty($info['icon'])) {
			$this->output(-1, '图标不能为空');
		}

		if (empty($info['url'])) {
			$this->output(-1, '地址不能为空');
		}

		if ($info['sort'] === '') {
			$this->output(-1, '排序不能为空.');
		}

		if (!$info['backgroud']) {
			$this->output(-1, '背景颜色不能为空.');
		}
		return $info;
	}

	public function deleteAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_Bookmark::get($id);
		if ($info && $info['id'] == 0) {
			$this->output(-1, '无法删除');
		}
		Util_File::del(Common::getConfig('siteConfig', 'attachPath') . $info['icon']);
		$result = Gionee_Service_Bookmark::delete($id);
		if (!$result) {
			$this->output(-1, '操作失败');
		}
		$this->updataVersion($info['ver']);
		$this->output(0, '操作成功');
	}

	public function uploadAction() {
		$imgId = $this->getInput('imgId');
		$this->assign('imgId', $imgId);
		$this->assign('size', 100);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	public function upload_postAction() {
		$ret   = Common::upload('img', 'App', 100);
		$imgId = $this->getPost('imgId');
		$this->assign('code', $ret['data']);
		$this->assign('msg', $ret['msg']);
		$this->assign('data', $ret['data']);
		$this->assign('imgId', $imgId);
		$this->assign('size', 100);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	/**
	 * update_version
	 */
	private function updataVersion($ver) {
		Gionee_Service_Config::setValue('bookmark_version_' . $ver, Common::getTime());
	}
}