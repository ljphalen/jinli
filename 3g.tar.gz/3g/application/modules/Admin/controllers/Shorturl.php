<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 短链接管理类
 * @author panxb
 *
 */
class ShorturlController extends Admin_BaseController {

	public $actions = array(
		'addUrl'       => '/admin/ShortUrl/add',
		'addPost'      => '/admin/shortUrl/addPost',
		'shortUrlList' => '/admin/shortUrl/list',
		'delete'       => '/admin/Shorturl/deletes'
	);

	public $perpage = 20;

	public function addAction() {
	}

	/**
	 * 添加短链接
	 */
	public function addPostAction() {
		$url   = $this->getInput('url');
		$res   = '';
		$t     = substr(md5($url . time() . 'OTHER' . Common::$urlPwd), 0, 6);
		$info  = json_encode(array('id' => time(), 'type' => 'OTHER', '_url' => $url));
		$datas = array(
			'key'        => $t,
			'mark'       => $info,
			'url'        => $url,
			'created_at' => time(),
		);
		$res   = Gionee_Service_ShortUrl::add($datas);
		if ($res) {
			exit(json_encode(array('key' => 1, 'msg' => '添加成功！')));
		} else {
			exit(json_encode(array('key' => '0', 'msg' => '添加失败！')));
		}
	}

	/**
	 * 手动添加短链接列表
	 *
	 */
	public function listAction() {
		$postData       = $this->getInput('page', 'pageSize');
		$page           = $postData['page'] ? $postData['page'] : 1;
		$pageSize       = $postData['pageSize'] ? $postData['pageSize'] : $this->perpage;
		$params         = array();
		$params['mark'] = array('LIKE', 'OTHER');
		$dataList       = Gionee_Service_ShortUrl::getList($page, $pageSize, $params, array('id' => 'DESC'));
		$this->assign('list', $dataList);
		$this->assign('page', $page);
		$this->assign('pageSize', $pageSize);
		$total = Gionee_Service_ShortUrl::getTotal($params);
		$this->assign('pager', Common::getPages($total, $page, $pageSize, $this->actions['shortUrlList'] . "/?"));
	}

	public function deletesAction() {
		$id = $this->getInput('id');
		if (!$id) {
			exit(json_encode(array('key' => '0', 'msg' => 'ID不能为空')));
		}
		$res = Gionee_Service_ShortUrl::del($id);
		if ($res) {
			echo json_encode(array('key' => '1', 'msg' => '操作成功'));
		} else {
			echo json_decode(array('key' => '0', 'msg' => '操作失败'));
		}
	}
}