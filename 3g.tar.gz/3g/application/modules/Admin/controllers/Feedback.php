<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
/**
 * 反馈管理
 * @author tiger
 */
class FeedbackController extends Admin_BaseController {
	
	public $actions = array(
		'listUrl' => '/Admin/Feedback/index',
	);
	
	public $perpage = 20;

	public function indexAction() {
		$page = intval($this->getInput('page'));
		$perpage = $this->perpage;
		$param = $this->getInput(array('topic_id'));
		$search = array();
		if ($param['topic_id']) $search['topic_id'] = $param['topic_id'];
		
		list($total, $reacts) = Gionee_Service_Feedback::getList($page, $perpage, $search);
		
		$ids = array(0);		
		foreach($reacts as $k=>$v) {
			$ids[] = $v['topic_id'];
		}
		$topicInfo = array();
		list($sum, $topicList) = Gionee_Service_Topic::getElements(array('id', 'title', 'option'), array('id' => array("IN", array_unique($ids))), array('id' => 'DESC'));
		foreach ($topicList as $val) {
			$toption = explode("\n",$val['option']);
			array_push($toption,'其他');
			$topicInfo[$val['id']] = array('name' => $val['title'], 'option' => $toption);
		}
		
		$url = $this->actions['listUrl'].'/?' . http_build_query($search) . '&';
		$this->assign('pager', Common::getPages($total, $page, $perpage, $url));
		$this->assign('reacts', $reacts);
		$this->assign('param', $param);
		$this->assign('topic',$topicInfo);
	}
}