<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 打开欢迎图片
 * @author tiger
 */
class WelcomeController extends Admin_BaseController {

	public $actions = array(
		'listUrl'       => '/Admin/Welcome/index',
		'addUrl'        => '/Admin/Welcome/add',
		'addPostUrl'    => '/Admin/Welcome/add_post',
		'editUrl'       => '/Admin/Welcome/edit',
		'editPostUrl'   => '/Admin/Welcome/edit_post',
		'deleteUrl'     => '/Admin/Welcome/delete',
		'uploadUrl'     => '/Admin/Welcome/upload',
		'uploadPostUrl' => '/Admin/Welcome/upload_post',
	);

	public function indexAction() {
		$list = Gionee_Service_Welcome::getAll();
		$this->assign('list', $list);
	}

	public function addAction() {
	}

	public function add_postAction() {
		$info   = $this->getPost(array('name', 'img', 'sort', 'url'));
		$info   = $this->_cookData($info);
		$result = Gionee_Service_Welcome::add($info);
		if (!$result) $this->output(-1, '操作失败');
		$this->updataVersion();
		$this->output(0, '操作成功');
	}

	public function editAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_Welcome::get(intval($id));
		$this->assign('info', $info);
	}

	public function edit_postAction() {
		$info = $this->getPost(array('id', 'name', 'img', 'sort', 'url'));
		$info = $this->_cookData($info);
		$ret  = Gionee_Service_Welcome::update($info, intval($info['id']));
		if (!$ret) $this->output(-1, '操作失败');
		$this->updataVersion();
		$this->output(0, '操作成功.');
	}

	private function _cookData($info) {
		if (!$info['name']) $this->output(-1, '页面名称不能为空.');
		if (!$info['img']) $this->output(-1, '图片不能为空.');
		if (!$info['url']) $this->output(-1, '链接不能为空.');
		return $info;
	}

	public function deleteAction() {
		$id   = $this->getInput('id');
		$info = Gionee_Service_Welcome::get($id);
		if ($info && $info['id'] == 0) $this->output(-1, '无法删除');
		$result = Gionee_Service_Welcome::delete($id);
		if (!$result) $this->output(-1, '操作失败');
		$this->updataVersion();
		$this->output(0, '操作成功');
	}

	public function uploadAction() {
		$imgId = $this->getInput('imgId');
		$this->assign('imgId', $imgId);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	public function upload_postAction() {
		$ret   = Common::upload('img', 'App');
		$imgId = $this->getPost('imgId');
		$this->assign('code', $ret['data']);
		$this->assign('msg', $ret['msg']);
		$this->assign('data', $ret['data']);
		$this->assign('imgId', $imgId);
		$this->getView()->display('common/upload.phtml');
		exit;
	}

	private function updataVersion() {
		Gionee_Service_Config::setValue('welcome_version', Common::getTime());
	}
}