<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class UCenterController extends Admin_BaseController {
	
	
	public function indexAction(){
		
	}
	
	public function configAction(){
		
	}
	
	//积分列表
	public function  scoreAction(){
		
		//检测登陆
	}
	
}