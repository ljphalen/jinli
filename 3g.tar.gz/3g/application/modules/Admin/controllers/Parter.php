<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 合作商类
 */

class ParterController extends Admin_BaseController
{
	public $pageSize = 20;
	
	public $actions = array(
		'deleteUrl'=>'/Admin/Parter/delete',
		'addUrl'   =>'/Admin/Parter/add',
		'editUrl'  =>'/Admin/Parter/edit',
		'addPostUrl'=>'/Admin/Parter/postData',
		'content'  =>'/Admin/Parter/list'
	);
	
	public function addAction(){
		
	}
	
	public function postDataAction(){
		$postData = $this->getInput(array('name','urls','id'));
		if(trim($postData['name'])==''||strip_tags($postData['urls'])==''){
			$this->output('-1','内容不能为空');
			exit;
		}
		$params = array('name'=>$postData['name'],'url'=>json_encode($postData['urls']));
		if(empty($postData['id'])){
			$res = Gionee_Service_Parter::add($params);
		}else{
			$res = Gionee_Service_Parter::update($params, $postData['id']);
		}
		 if($res){ $this->output('0','操作成功');}
		else{ $this->output('-1','操作失败');} 

	}
	
	public function listAction(){
		$page = $this->getInput('page');
		$dataList = Gionee_Service_Parter::getList($page,$this->pageSize);
		$this->assign('list', $dataList[1]);
		$this->assign('pager', Common::getPages($dataList[0], $page, $this->pageSize, $this->actions['content']."&"));
	}
	
	
	public function deleteAction(){
		$id = $this->getInput('id');
		$res = Gionee_Service_Parter::delete($id);
		if($res){
			$this->output('0','操作成功');
		}else{
			$this->output('-1','操作失败');
		}
	}
	
	public function editAction(){
		$id = $this->getInput('id');
		if(!$id)return false;
		$data = Gionee_Service_Parter::get($id);
		$this->assign('v', $data);
	}
}