<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class RegisterController extends  Admin_BaseController{
	
	public $pageSize = 20;
	
	public $actions = array(
		'indexUrl'					=>'/Admin/Register/index'
	);
	public function indexAction(){
		$page = $this->getInput('page');
		$page = max($page,1);
		list($total,$data) = Gionee_Service_User::getList($page,$this->pageSize,array(),array('id'=>'DESC'));
		foreach ($data as $k=>$v){
			$userScores = User_Service_Gather::getBy(array("uid"=>$v['id']));
			$data[$k]['total_score'] = $userScores['total_score'];
			$data[$k]['remained_score'] = $userScores['remained_score'];
			$data[$k]['frozed_score'] = $userScores['frozed_score'];
			
			$params = array();
			$params['id'] = array('IN',array($v['province_id'],$v['city_id']));
			$areaInfo = Gionee_Service_Area::getCityNameByIds($params);
			$data[$k]['province'] = $areaInfo['province']['name'];
			$data[$k]['city']			 = $areaInfo['city']['name'];
		}
		$groupConfig = Common::getConfig('userConfig','level_group_name');
		$levelConfig 	 = Common::getConfig('userConfig','rank');
		$this->assign('data', $data);
		$this->assign('group', $groupConfig);
		$this->assign('level', $levelConfig);
		$this->assign('pager', Common::getPages($total, $page, $this->pageSize, $this->actions['indexUrl']."?"));
	}
}