<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 活动专用页
 * @author panxb
 *
 */
class ActivityController extends Front_BaseController {

	public $actions = array(
		'getQuotaUrl' => '/Front/Activity/ajaxGetPermission',
		'cindexUrl'   => '/Front/Activity/cindex',
		'clistURL'    => '/Front/Activity/clist',
	);
	/**
	 * 畅聊接口
	 */
	public function cindexAction() {
		$t_bi   = $this->getSource();
		$user   = $this->_checkLogin($this->actions['clistURL'], false);
		$caller = isset($user['msg'][1]) ? $user['msg'][1] : 0;
		$this->_checkUser($caller);

		Gionee_Service_Log::pvLog('voip_pv_list');//PV统计
		Gionee_Service_Log::uvLog('voip_uv_list', $t_bi);//PV统计
		$tel = $this->getInput('tel');
		//list($total,$dataList) = Gionee_Service_VoIPLog::getList(1,20,array('caller_phone'=>$caller,'show'=>1),array('called_time'=>'DESC'));
		//获得用户信息
		$area = Gionee_Service_VoIP::getAreaCode($caller);
		$this->assign('tel', $tel);
		$this->assign('area', $area);
		$this->assign('mobile', $caller);
		$this->assign('login', !empty($caller) ? 1 : 0);
	}

	private function _getRecordList($caller) {
		$dataList = array();
		if ($caller) {
			$rkey     = 'KEY:VOIP_CLIST:' . $caller;
			$dataList = Common::getCache()->get($rkey);
			if (empty($dataList)) {
				$dataList = Gionee_Service_VoIPLog::getCommutniateList(1, 20, array('caller_phone' => $caller, 'show' => 1), array('called_phone'), array('called_time' => 'DESC'));
				Common::getCache()->set($rkey, $dataList, 24 * 3600);
			}
		}
		return $dataList;
	}

	private function _getServiceInfo() {
		//有信客服
		$rsKey = 'KEY:VOIP:SERVICE';
		$cs    = Common::getCache()->get($rsKey);
		if (empty($cs)) {
			$service = Gionee_Service_Config::getValue('yx_customer_service');
			$service = json_decode($service, true);
			foreach ($service as $k => $v) {
				$cs[] = json_decode($v, true);
			}
			Common::getCache()->set($rsKey, $cs, 60);
		}
		return $cs;
	}

	//获取免费通话资格
	public function ajaxGetPermissionAction() {
		//先测检登陆状态
		$user = $this->_checkLogin($this->actions['cindexUrl'], true);
		//检测是否已领取
		$pid = $this->getInput('pid');
		if (!is_numeric($pid)) {
			$this->output('-1', '参数有错！');
		}
		$obtained = Gionee_Service_VoIPUser::isObtained(array('user_phone' => $user['msg'][1], 'pid' => $pid));
		if ($obtained) {
			$this->output('-1', '您已获得本次通话资格，不能重复获取');
		}

		//是否在有效期内
		$expired = Gionee_Service_VoIP::getBy(array('start_time' => array('<=', time()), 'end_time' => array('>=', time())), array());
		if (!$expired) {
			$this->output('-2', '本期活动已结束，请下次再来！');
		}
		//添加信息
		$time = time();
		$res  = Gionee_Service_VoIPUser::add(array('user_phone' => $user['msg'][1], 'pid' => $pid, 'get_time' => $time, 'date' => date('Ymd', $time)));
		if ($res) {
			$this->output(0, '获取成功', array('redirect' => $this->actions['clistURL']));
		} else {
			$this->output('-3', '获取失败');
		}
	}

	/**
	 *拨打电话
	 */
	public function callAction() {

		$t_bi = $this->getSource();
		Gionee_Service_Log::pvLog('voip_pv_call1');//PV统计
		Gionee_Service_Log::uvLog('voip_uv_call1', $t_bi);//PV统计
		$data   = $this->_checkLogin($this->actions['clistURL'], false);
		$called = $this->getInput('callee');
		if (empty($data['msg'][1])) {
			$this->output(-1, '');
		}
		$caller = $data['msg'][1];
		if ($caller == $called) {
			$this->output(-1, '不能打给自己');
		}
		$firstStr = substr($called, 0, 1);
		$type     = $firstStr == '1' ? 'phone' : 'tel';
		if (!Common::checkIllPhone($called, $type)) {
			$this->output(-1, '呼叫号码有误！');
		}
		$callTime = Gionee_Service_VoIPLog::getTotalTimeByMonth($caller);
		$t        = $this->_calcLeftTime($callTime);
		if ($t == 0) {
			$this->output(-1, '本月拨打额度已用完！');
		}
		Gionee_Service_Log::pvLog('voip_pv_call');//PV统计
		Gionee_Service_Log::uvLog('voip_uv_call', $t_bi);//PV统计
		$now  = time();
		$rkey = 'KEY:VOIP_CLIST:' . $caller;
		Common::getCache()->delete($rkey);//如果用户拔打过电话,就把通话记录列表的缓存清空

		$area         = Gionee_Service_VoIP::getAreaCode($called);
		$callerClient = Gionee_Service_VoIPClient::getClientNumber($caller, true);
		$calledClient = Gionee_Service_VoIPClient::getClientNumber($called, true);

		if (empty($calledClient)) {
			$this->output(-1, '呼叫号码错误！');
		}
		$telObj = new Vendor_Tel();
		$out    = $telObj->callBack($callerClient, $called);
		if ($out) {
			$ret = array(
				'address'  => $area,
				'callTime' => $this->_formatDate($now),
				'msg'      => $out,
			);
			$this->output(0, '', $ret);
		}

		$this->output(-1, '', '接口异常');
	}

	private function _calcLeftTime($callTime) {
		$conf = Gionee_Service_Config::getValue('voip_config');
		$cfg  = json_decode($conf, true);
		$diff = max($cfg['month_call_time'] - $callTime, 0);
		$ret  = floor($diff / 60) * 60;//值必须为60的倍数
		return $ret;
	}

	private function _checkUser($caller) {
		$now = time();
		if ($caller) {
			$row = Gionee_Service_VoIPUser::getBy(array('user_phone' => $caller));
			if (empty($row['id'])) {
				$param = array(
					'user_phone' => $caller,
					'pid'        => 1,
					'get_time'   => $now,
					'date'       => date('Ymd', $now)
				);
				Gionee_Service_VoIPUser::add($param);
			}
		}

	}

	/**
	 *列表页
	 */
	public function clistAction() {
		//检测用户登陆状态
		$msg  = $this->_checkLogin($this->actions['cindexUrl'], true);
		$t_bi = $this->getSource();
		Gionee_Service_Log::pvLog('voip_pv');//PV统计
		Gionee_Service_Log::uvLog('voip_uv', $t_bi);//UV统计
		//	$total    = 0;//已领取活动资格的人数
		$userFlag = 1;//默认用户有领取资格
		$userMsg  = $msg['msg'];
		$cs       = $this->_getServiceInfo();
		$dataList = $this->_getRecordList($userMsg[1]);
		$data = array();
		foreach ($dataList as $k => $v) {
			$data[$k]['total']    = $v['total'];
			$data[$k]['callee']   = $v['called_phone'];
			$data[$k]['callTime'] = $this->_formatDate($v['called_time']);
			$data[$k]['address']  = $v['area'] ? $v['area'] : '未知';
		}
		$this->assign('flag', $userFlag);
		$this->assign('userMsg', $userMsg);
		$this->assign('data', $data);
		$this->assign('cs', $cs);
	}

	//规则页
	public function tipsAction(){
		//友情提示
		$tipKey = '3g:VOIP:TIPS';
		$tips   = Common::getCache()->get($tipKey);
		if (empty($tips)) {
			$tips = Gionee_Service_Config::getValue('3g_voip_tips');
			Common::getCache()->set($tipKey, $tips, 60);
		}
		$this->assign('tips', $tips);
	}
	
	///退出登陆
	public function logoutAction() {
		$res = Gionee_Service_User::logout();
		if ($res) {
			$outUrl = 'http://t-id.gionee.com/member/logout?redirect_uri=';
			if (ENV == 'product') {
				$outUrl = 'http://id.gionee.com/member/logout?redirect_uri=';
			}
			$this->redirect($outUrl . Common::getCurHost() . '/nav');
		}
	}

	//清空数据
	public function clearAction() {
		$data   = $this->_checkLogin($this->actions['clistURL'], true);
		$caller = $data['msg'][1];
		$res    = Gionee_Service_VoIPLog::updateBy(array('show' => '0'), array('caller_phone' => $caller, 'show' => '1'));
		if ($res) {
			$rkey = 'KEY:VOIP_CLIST:' . $caller;
			Common::getCache()->delete($rkey);
			$this->output(0, '操作成功！', array('redirect' => $this->actions['clistURL']));
		} else {
			$this->output('-1', '操作失败！');
		}
	}

	//检测通话时间是否有效
	private function _checkValid($phone) {
		$least = Gionee_Service_VoIPUser::getBy(array('user_phone' => $phone), array('get_time' => 'DESC'));
		if (empty($least)) {
			return array('key' => '-1', 'msg' => '没有活动权限！');
		}
		$content = Gionee_Service_VoIP::getBy(array('id' => $least['pid'], 'sta' => 1), array());
		if (!$content) {
			return array('key' => '-1', 'msg' => '该期活动不存在或已结束！');
		}
		if ($content['valid_time'] < time()) {
			return array('key' => '-1', 'msg' => '您的通话权限已过有效期！');
		}
		return array('key' => '1', 'msg' => '');
	}


	//获取通话详细信息记录
	public function getDetailMsgAction() {
		$ret = Gionee_Service_VoIP::collectionFTP();
		var_dump($ret);
		exit;
	}


	//日期格式化
	private function _formatDate($time) {
		return date('n月j日H:i', $time);
	}

	//检测用户登陆情况
	private function _checkLogin($callback_url, $flag = true) {
		$webroot = Common::getCurHost();
		$user    = Gionee_Service_User::ckLogin();
		$ret     = array('key' => '1', 'msg' => $user);
		if (!$user && $flag) {
			$callback = $webroot . '/user/login/login?f=2';
			$url      = Api_Gionee_Oauth::requestToken($callback);
			Util_Cookie::set('GIONEE_LOGIN_REFER', $callback_url, true, Common::getTime() + (5 * 3600), '/');
			$ret = array('key' => '0', 'msg' => $url);
			$this->redirect($url);
		}

		$obtained = Gionee_Service_VoIPUser::isObtained(array('user_phone' => $user['msg'][1]));
		if (!$obtained && !empty($user['msg'][1])) {
			$time = time();
			Gionee_Service_VoIPUser::add(array('user_phone' => $user['msg'][1], 'get_time' => $time, 'date' => date('Ymd', $time)));
		}

		return $ret;
	}
}