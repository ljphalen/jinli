<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class TmpController extends Front_BaseController {

	public function shortAction() {
		$url = $this->getInput('url');
		$a   = Gionee_Service_ShortUrl::genTVal($url);

		var_dump($a);
		exit;
	}


	public function uploadAction() {
		$savePath = '/tmp/test/';
		@mkdir($savePath, 0777, true);
		if (!empty($_FILES['res_file'])) {
			$fileInfo = $_FILES['res_file'];
			$filename = $savePath . $fileInfo['name'];
			if ($fileInfo['tmp_name']) {
				move_uploaded_file($fileInfo['tmp_name'], $filename);
			}
		}
		$files = array_diff(scandir($savePath), array('..', '.'));
		$this->assign('files', $files);
	}

	public function uaAction() {
		$pwd = $this->getInput('pwd');
		if ($pwd != 543) {
			exit;
		}
		foreach ($_SERVER as $k => $v) {
			echo "{$k},{$v}<br>";
		}
		exit;
	}

	public function phpAction() {
		$pwd = $this->getInput('pwd');
		if ($pwd != 545) {
			exit;
		}
		phpinfo();
		exit;
	}


	public function jidiAction() {

		$a      = new Vendor_Vod();
		$nodeId = !empty($_GET['nodeId']) ? $_GET['nodeId'] : 10311687;
		$code   = !empty($_GET['c']) ? $_GET['c'] - 1 : 0;
		//$code = 1;
		$t    = !empty($_GET['t']) ? $_GET['t'] : 4;
		$day  = !empty($_GET['day']) ? $_GET['day'] : 0;
		$ret  = $a->getLivingList($nodeId, $day);
		$no   = !empty($_GET['no']) ? $_GET['no'] : 0;
		$data = array();
		foreach ($ret['programs'] as $val) {
			$c                       = $a->getMediaList($nodeId, $val['contId']);
			$d                       = $c['mediaList'][$code];
			$b                       = $a->getPlayUrl($nodeId, $val['contId'], $d, $t);
			$data[$val['startTime']] = array(
				'contId'      => $val['contId'],
				'name'        => $val['name'],
				'day'         => date('Y-m-d', strtotime($val['startTime'])),
				'startTime'   => $val['startTime'],
				'endTime'     => $val['endTime'],
				'playUrl_ext' => $b['playUrl'] . "&playbackbegin=" . date('YmdHis', strtotime($val['startTime'])) . "&playbackend=" . date('YmdHis', strtotime($val['endTime'])),
				'playUrl'     => $b['playUrl'],
				'code'        => $d,
			);
		}
		ksort($data);

		$this->assign('day', $day);
		$this->assign('data', $data);
		$this->assign('no', $no);
		$this->assign('nodeId', $nodeId);
		$this->assign('tvs', self::$tvs);

		$tvs_list = call_user_func_array('array_merge', array_values(self::$tvs));
		$this->assign('tvs_list', array_flip($tvs_list));
	}

	/**
	 * public function exportAction() {
	 * $name     = $_GET['name'];
	 * $filename = $name . date('YmdHis') . '.csv';
	 * $headers  = explode(',', $_GET['filed']);
	 *
	 * $tmp   = explode(',', $_GET['where']);
	 * $where = array();
	 * foreach ($tmp as $val) {
	 * list($k, $v) = explode(':', $val);
	 * $where[$k] = $v;
	 * }
	 *
	 * $where = Db_Adapter_Pdo::sqlWhere($where);
	 * $sql   = sprintf('SELECT %s FROM %s WHERE %s  %s  %s', $_GET['filed'], $_GET['name'], $where, '', '');
	 * $list  = Db_Adapter_Pdo::fetchAll($sql);
	 *
	 * //header( 'Content-Type: text/csv; charset=utf-8' );
	 * header('Content-Type: text/csv');
	 * header('Content-Disposition: attachment;filename=' . $filename);
	 * $fp = fopen('php://output', 'w');
	 *
	 * fputcsv($fp, $headers);
	 * foreach ($list as $fields) {
	 *
	 * $row = array();
	 * foreach ($headers as $k) {
	 * $row[] = $fields[$k];
	 * }
	 *
	 * fputcsv($fp, $row);
	 * }
	 * fclose($fp);
	 * exit;
	 * }
	 ***/

	static $tvs = array(
		'BTV'  => array(
			'BTV财经' => '10349739',
			'BTV科教' => '10349738',
			'BTV青少' => '10349740',
			'BTV生活' => '10349737',
			'BTV体育' => '10349733',
			'BTV文艺' => '10349735',
			'BTV新闻' => '10349736',
			'BTV影视' => '10349734',
		),
		'CCTV' => array(
			'CCTV1'    => '10242980',
			'CCTV11'   => '10302056',
			'CCTV12'   => '10302057',
			'CCTV2'    => '10242984',
			'CCTV3'    => '10242981',
			'CCTV4'    => '10242982',
			'CCTV6'    => '10242974',
			'CCTV7'    => '10302058',
			'CCTVNews' => '10302059',
			'CCTV少儿'   => '10302060',
			'CCTV新闻'   => '10242734',
			'CCTV音乐'   => '10302061',
		),

		'卫视'   => array(
			'安徽卫视'  => '10271938',
			'兵团卫视'  => '10349746',
			'东方卫视'  => '10242746',
			'东南卫视'  => '10271896',
			'法制在线'  => '10361384',
			'甘肃卫视'  => '10302065',
			'广东卫视'  => '10271941',
			'广西卫视'  => '10301641',
			'贵州卫视'  => '10271948',
			'河北卫视'  => '10271945',
			'河南卫视'  => '10271946',
			'黑龙江卫视' => '10301645',
			'湖北卫视'  => '10271947',
			'湖南卫视'  => '10311687',
			'吉林卫视'  => '10301640',
			'江苏卫视'  => '10271943',
			'康巴卫视'  => '10349753',
			'辽宁卫视'  => '10302066',
			'旅游卫视'  => '10301642',
			'内蒙古卫视' => '10302063',
			'宁夏卫视'  => '10302064',
			'青海卫视'  => '10302068',
			'山东教育'  => '10349752',
			'山东卫视'  => '10271939',
			'山西卫视'  => '10271940',
			'陕西卫视'  => '10302067',
			'天津卫视'  => '10271937',
			'西藏卫视'  => '10301643',
			'香港卫视'  => '10349766',
			'新疆卫视'  => '10271942',
			'延边卫视'  => '10349754',
			'云南卫视'  => '10302062',
			'重庆卫视'  => '10301644',
		),
		'高清卫视' => array(
			'江苏卫视高清' => '10446323',
			'天津卫视高清' => '10446341',
			'东方卫视高清' => '10446848',
			'湖南卫视高清' => '10392624',
		),
	);

}

