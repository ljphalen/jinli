<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 导航
 */
class NavController extends Front_BaseController {

	public $actions = array(
		'indexUrl' => '/nav/index',
		'tjUrl'    => '/index/tj',
		'newsUrl'  => '/index/news',
		'listUrl'  => '/nav/list',
	);
	public function indexAction() {
		//统计导航pv
		Gionee_Service_Log::pvLog('3g_nav');
		//统计导航UV
		$t_bi = $this->getSource();
		Gionee_Service_Log::uvLog('3g_nav',$t_bi);

		$pageData = Gionee_Service_Ng::getIndexData();
		$this->assign('pageData', $pageData['content']);

		$words = Gionee_Service_Baidu::getNavIndexWrods();
		//$this->assign('placeHolder', array_shift($words));
		$this->assign('baidu_hotword', $words);
		//百度渠道号
		$baidu_num = Gionee_Service_Baidu::getFromNo();
		$this->assign('baidu_num', $baidu_num);

	}

	/**
	 * 导航二级分类页面
	 */
	public function cateAction() {
		//导航二级页面（首页page_id=1，子页面 page_id=2）
		$navHeader = Gionee_Service_NgType::getListByPageId(2);

		$this->assign('navHeader', $navHeader);
	}


	/**
	 * list
	 */
	public function listAction() {
		$this->redirect($this->actions['indexUrl']);
		exit;
	}
	
	//收入统计信息
	public function  incomeAction(){
		$dataList = Gionee_Service_Income::getLastMothIncome();
		$this->assign('dataList', $dataList);	
	}
}