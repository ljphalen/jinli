<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 专题首页
 */
class TopicController extends Front_BaseController {

	public $actions = array(
		'indexUrl'    => '/Topic/index',
		'listUrl'     => '/Topic/list',
		'feedbackUrl' => '/Topic/feedback',
	);
	public $perpage = 10;

	public function indexAction() {
		$id = $this->getInput('id');
		if (!$id) {
			$this->forward('list');
			return false;
		}
		$topFuncColDisplay = Gionee_Service_Config::getValue('topic_top_func_status');
		if(empty($topFuncColDisplay)) $topFuncColDisplay = 0;
		$info    = Gionee_Service_Topic::get($id);
		$content = json_decode($info['content']);
		$content = Gionee_Service_Topic::getTopicView($content);
		$option  = explode("\n", $info['option']);
		array_push($option,'其他');
		$colors  = Gionee_Service_Topic::$colors;
		$this->assign('option', $option);
		$this->assign('info', $info);
		$webroot    = Common::getCurHost();
		$newRootUrl = Common::tjurl($webroot . '/index/tj', $id, 'TOPIC_MAIN', $webroot . '/nav');
		$listUrl    = Common::tjurl($webroot . '/index/tj', $id, 'TOPIC_LIST', $webroot . '/topic/list?id=' . $id);
		$this->assign('newRoot', $newRootUrl);
		$this->assign('webroot', $webroot);
		$this->assign('listUrl', $listUrl);
		$this->assign('content', $content);
		$this->assign('colors', $colors);
		$this->assign('topFuncColDisplay',$topFuncColDisplay);
	}

	/**
	 * 专题列表
	 */
	public function listAction() {
		$id      = $this->getInput('id');
		$params  = array('status' => 1);
		$orderBy = array('id' => 'DESC');
		$topics  = Gionee_Service_Topic::getsBy($params, $orderBy);
		$webroot = Common::getCurHost();
		foreach ($topics as $k => $v) {
			$topics[$k]['url'] = Common::tjurl($webroot . '/index/tj', $v['id'], 'TOPIC', $webroot . '/topic/index?id=' . $v['id']);
		}
		$topFuncColDisplay = Gionee_Service_Config::getValue('topic_top_func_status');
		$this->assign('topFuncColDisplay',$topFuncColDisplay);
		$this->assign('topics', $topics);
		$this->assign('id', $id);
	}

	/**
	 * 喜欢加一
	 */
	public function likeAction() {
		$id = $this->getInput('id');
		if ($id) {
			$info = Gionee_Service_Topic::get($id);
			if ($info) {
				$result = Gionee_Service_Topic::addLike($id);
				if ($result) {
					$this->output(0, '操作成功');
				}
			}
		}
		$this->output(-1, '操作失败');
	}

	/**
	 * 用户反馈
	 */
	public function feedbackAction() {
		$info                = $this->getPost(array('topic_id', 'option_num', 'answer', 'contact'));
		$info['user_flag']   = $this->getInput('t_bi');
		$info['create_time'] = time();
		$info['ip']          = $_SERVER['REMOTE_ADDR'];
		$info['option_num']  = array_sum($info['option_num']);
		list($total, $detail) = Gionee_Service_Feedback::getsBy(array('topic_id' => $info['topic_id'], 'option_num' => $info['option_num']));
		if (!$detail) {
			$result = Gionee_Service_Feedback::add($info);
		} else {
			$topic  = Gionee_Service_Topic::get($info['topic_id']);
			$opkeys = array_keys(explode("\n", $topic['option']));
			//最后一个是选择其他，它自己输入内容
			if (pow(2,count($opkeys)-1) & $info['option_num']) {//如果是用户填写反馈时，直接添加
				$result = Gionee_Service_Feedback::add($info);
			} else {
				$result = Gionee_Service_Feedback::updateApp(array('create_time' => time(), 'num' => $detail[0]['num'] + 1), $detail[0]['id']);
			}
		}
		if ($result) {
			$this->output(0, '操作成功');
		} else {
			$this->output(-1, '操作失败');
		}
	}


	//有信电话
	public function yxAction() {
		$callback = Common::getCurHost();
		$url      = Api_Gionee_Oauth::requestToken($callback . '/nav');
		$this->assign('url', $url);
	}

	//有信专题二
	public function youxinAction() {

	}

}