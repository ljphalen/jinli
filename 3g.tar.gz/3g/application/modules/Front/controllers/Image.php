<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 美图在线
 */
class ImageController extends Front_BaseController {

	public $actions = array(
		'indexUrl'  => '/picture/index',
		'morelUrl'  => '/picture/more',
		'detailUrl' => '/picture/detail'
	);

	public $perpage = 8;

	/**
	 * 首页
	 */
	public function indexAction() {
		$page = 1;
		list($total, $lpictures) = Gionee_Service_Picture::getCanUseList(1, 4, array('status' => 1));
		list(, $rpictures) = Gionee_Service_Picture::getCanUseList(2, 4, array('status' => 1));
		$this->assign('lpictures', $lpictures);
		$this->assign('rpictures', $rpictures);
		$this->assign('pageTitle', '美图在线');
		$this->assign('nav', '2-2');
		$hasnext = (ceil((int)$total / $this->perpage) - ($page)) > 0 ? 'true' : 'false';
		$this->assign('hasnext', $hasnext);
	}

	/**
	 * 加载更多
	 */
	public function moreAction() {
		$page = intval($this->getInput('page'));
		if ($page < 2) $page = 2;

		list($total, $pictures) = Gionee_Service_Picture::getCanUseList($page, $this->perpage, array('status' => 1));
		$pics    = array();
		$webroot = Common::getCurHost();
		foreach ($pictures as $key => $value) {
			$pics[$key]['id']    = $value['id'];
			$pics[$key]['title'] = $value['title'];
			$pics[$key]['img']   = strpos($value['img'], 'http://') === false ? $webroot . '/attachs' . $value['img'] : $value['img'];
			$pics[$key]['url']   = $webroot . $this->actions['detailUrl'] . '?id=' . $value['id'];
		}
		$hasnext = (ceil((int)$total / $this->perpage) - ($page)) > 0 ? true : false;
		$this->output(0, '', array('list' => $pics, 'hasnext' => $hasnext, 'curpage' => $page));
	}

	/**
	 * 图片详情
	 */
	public function detailAction() {
		$id = intval($this->getInput('id'));

		$picture = Gionee_Service_Picture::getPicture($id);

		$webroot = Common::getCurHost();
		if (!$id || !$picture || $picture['id'] != $id) $this->redirect($webroot . $this->actions['indexUrl']);
		$this->assign('picture', $picture);
	}
}
