<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class IndexController extends Front_BaseController {

	// add
	public $actions = array(
		'aboutUrl' => '/index/about',
		'indexUrl' => '/index/index',
	);

	public function indexAction() {
		//第三方页面
		if (stristr($_SERVER['HTTP_HOST'], 'mk.')) {
			$this->forward("front", "vendor", "index");
			return false;
		}

		$f = $this->getInput('f');
		$r = $this->isRedirect($f);
		if ($r === 1) { //没有GiONEE标识
			$this->forward("front", "nav", "index");
			return false;
		} else if ($r === 2) { //有机型
			$this->forward("front", "news", "index");
			return false;
		}
		//统计首页点击量
		$t_bi = $this->getSource();
		Gionee_Service_Log::pvLog('3g_index');
		Gionee_Service_Log::uvLog('3g_index', $t_bi);

		//轮播广告
		$ads = Gionee_Service_Ad::getCanUseAds(1, 4, array('ad_type' => 1));
		$this->assign('ads', $ads);

		//系列
		list(, $series) = Gionee_Service_Series::getAllSeries();
		$this->assign('series', $series);
		$this->assign('pageTitle', '产品服务页');
		$this->assign('nav', 'index');
	}

	public function tjAction() {
		$t_bi = $this->getSource();
		$id   = intval($this->getInput('id'));
		$ch   = $this->getInput('ch');
		$t    = $words = '';
		if ($id) { //兼容老的模式
			$type = $this->getInput('type');
			$url  = html_entity_decode(urldecode($this->getInput('_url')));
		} else {
			$t = $this->getInput('t');
			list($id, $type, $url, $words) = Gionee_Service_ShortUrl::check($t);
			Gionee_Service_Log::toUVByCacheKey(Gionee_Service_Log::TYPE_URL_UV, $t, $t_bi);
		}
		if (!$id || !$type) {
			return false;
		}
		switch ($type) {
			case "SOHU": //搜狐新闻统计
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_SOHU, $id);
				//新闻页UV统计
				Gionee_Service_Log::toUVByCacheKey(Gionee_Service_Log::TYPE_NEWS_UV, $id, $t_bi);
				break;
			case 'BAIDU_HOT': //百度热词统计
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_BAIDU_HOT, $t . ":" . $words);
				break;
			case 'TOPIC': //专题活动页统计
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_TOPIC, $t . ":" . $id);
				break;
			case 'TOPIC_LIST': //专题页中列表点击统计
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_TOPIC_LIST, $t . ":" . $id);
				break;
			case 'TOPIC_MAIN': //专题页中返回首页点击统计
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_TOPIC_MAIN, $t . ":" . $id);
				break;
			case 'TOPIC_CONTENT': //专题页中内容点击统计
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_TOPIC_CONTENT, $id . ':' . $ch);
				break;
			case "NAV":
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_NAV, $id . ':' . $ch);
				//用户UV统计
				Gionee_Service_Log::toUVByCacheKey(Gionee_Service_Log::TYPE_CONTENT_UV, $id . ':' . $ch, $t_bi);
				break;
			case "SITE":
				Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_SITE_INDEX, $t . ":" . $id);
				break;
			case "APP":
				Gionee_Service_App::updateTJ($id);
				break;
			case "NAV_SEARCH":
			case "NEWS_SEARCH" :
				$word    = $this->getInput("word");
				$q       = $this->getInput("q");
				$keyword = $this->getInput("keyword");
				if (strpos($url, "?") === false) {
					$url .= "?";
				} else {
					$url .= "&";
				}
				if ($word) $url .= "word=" . $word;
				if ($q) $url .= "q=" . $q;
				if ($keyword) $url .= "keyword=" . $keyword;

				break;
			case "NEWSAD":
			default:
				break;
		}

		$this->redirect($url);
	}


	/**
	 * 百度搜索内容记录
	 */
	public function searchAction() {
		$from  = $this->getInput('from');
		$words = $this->getInput('word');
		$key   = 'SEARCH:' . date('YmdH', time() - 3600);
		$field = base64_encode($words);
		$value = Common::getCache()->hGet($key, $field);
		if ($value) {
			Common::getCache()->hIncrBy($key, $field);
		} else {
			Common::getCache()->hSet($key, $field, 1, 24 * 3600);
		}
		$this->redirect('http://m.baidu.com/s?from=' . $from . '&word=' . urlencode($words));
	}


}
