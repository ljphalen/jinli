<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class OfflineController extends Front_BaseController {
	public function indexAction() {

	}
}
