<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 用户反馈
 */
class FeedbackController extends Front_BaseController {

	public $actions = array(
		'indexUrl' => '/feedback/index',
		'postUrl'  => '/feedback/post',
	);

	public $perpage = 20;

	public function indexAction() {
		$ch = $this->getInput('ch');
		if ($ch) {
			$this->assign('ch', $ch);
		}
		$this->assign('contact', $this->userInfo ? $this->userInfo['username'] : '');
		$this->assign('refurl', $_SERVER['HTTP_REFERER']);
	}

	public function postAction() {
		$info = $this->getPost(array('contact', 'react', 'ch','refurl'));
		if (!$info['react']) $this->output(-1, '反馈内容不能为空.');
		if (Util_String::strlen($info['react']) > 500) $this->output(-1, '反馈内容不能大于500字.');
		if($info['refurl']){
			$url = $info['refurl'];
		}else{
			$webroot = Common::getCurHost();
			if ($info['ch']) {		//渠道号
				$url = $webroot . '/nav/?ch=' . $info['ch'];
			} else {
				$url = $webroot.'/nav';
			}
		}
		$result = Gionee_Service_React::addReact($info);
		if (!$result) $this->output(-1, '操作失败');

		$this->output(0, '您的宝贵意见反馈成功', array('type' => 'redirect', 'url' => $url));
	}
	 
	/**
	 * 新版用户意见反馈
	 */
	public function newAction(){
		$types = Gionee_Service_FeedbackItem::getsBy(array('parent_id'=>0,'status'=>1),array('sort'=>'DESC','id'=>'ASC'));
		$data = array();
		if($types){
			foreach($types as $k=>$v){
				$data[$v['id']]  = Gionee_Service_FeedbackItem::getsBy(array('parent_id'=>$v['id'],'status'=>1),array('sort'=>"DESC",'id'=>'ASC'));
			}
		}
		$this->assign('types', $types);
		$this->assign('data', $data);
	}
	
	/**
	 * 提交反馈信息
	 */
	public function ajaxPostAction(){
		$params = $this->getInput(array('menu_id','checked_list','content','tel','ch','refurl'));
		if(Util_String::strlen($params['content']) > 500) $this->output('-1','反馈内容不能大于500字');
		$params['content'] =  preg_replace("/<([a-za-z]+)[^>]*>/","<\1>",$params['content']);
		if($params['refurl']){
				$url = $params['refurl'];
			}else{
				$webroot = Common::getCurHost();
				if ($params['ch']) {		//渠道号
					$url = $webroot . '/nav/?ch=' . $params['ch'];
				} else {
					$url = $webroot.'/nav';
				}
			}
			$ret = Gionee_Service_React::addReact($params);
			if(!$ret){
				$this->output('-1','信息提交失败！');
			}
			$this->output(0, '您的宝贵意见反馈成功', array('type' => 'redirect', 'url' => $url));
	}
}