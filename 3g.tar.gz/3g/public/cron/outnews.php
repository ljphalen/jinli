<?php
include 'common.php';
/**
 *获取新闻
 */
set_time_limit(0);

//彩票数据
Gionee_Service_Ng::genLotteryData();

//导航新闻内容
$out = Gionee_Service_Jhnews::run();
echo $out;
Gionee_Service_CronLog::add(array('type' => 'nav_news', 'msg' => $out));

//聚合阅读新闻抓取
$out = Gionee_Service_OutNews::run();
echo $out;
Gionee_Service_CronLog::add(array('type' => 'out_news', 'msg' => $out));

//金立购新闻抓取
$out = Gionee_Service_Jhnews::runGrabGionee();
echo $out;
Gionee_Service_CronLog::add(array('type' => 'out_', 'msg' => $out));
