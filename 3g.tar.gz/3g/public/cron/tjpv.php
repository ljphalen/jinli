<?php
include 'common.php';
/**
 *全站pv
 */
$cache = Common::getCache();
$pv  = intval($cache->get('3g_pv'));

if (Gionee_Service_Stat::incrementPv($pv, 0)) {
	$cache->set('3g_pv', 0);
}


//update uv
$uv  = intval($cache->get('3g_uv'));
if (Gionee_Service_Stat::incrementUv($uv)) {
	$cache->delete('3g_uv');
}

//统计段链接次数
foreach(Gionee_Service_Log::$types as $v) {
	$sTime = microtime();
	$msg = date('Y-m-d H:i:s')."start:{$v}\n";
	Gionee_Service_Log::sync2DB($v);
	$eTime = microtime();
	$diff =  sprintf('%.3f', ($eTime - $sTime));
	$msg = date('Y-m-d H:i:s')."end:{$v}:({$diff})\n";
	Gionee_Service_CronLog::add(array('type'=>'sync_log', 'msg'=>$msg));
}

echo CRON_SUCCESS;
