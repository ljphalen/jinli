<?php
include 'common.php';
/**
 *获取聚合新闻新闻图片
 */
set_time_limit(0);
$out = Gionee_Service_OutNews::runDownImg();
echo $out;


