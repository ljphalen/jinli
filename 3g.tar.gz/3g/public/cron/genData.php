<?php
include 'common.php';
$out = '';
$rc  = Common::getCache();

$tmpKey    = 'TMP_CACHE:INDEX';

$indexData = Gionee_Service_Ng::getIndexData(true);
$out .= ' index_data to cache ';
$datamd5 = md5(json_encode($indexData));
$verify  = $rc->get($tmpKey);
if ($verify != $datamd5) {
	$out .= ' index_data change appc ';
	$rc->set($tmpKey, $datamd5);
	Gionee_Service_Config::setValue('APPC_Front_Nav_index', Common::getTime());
}

Gionee_Service_Ng::upNavFrontIndexAPPC($indexData['img']);

//广告缓存检测
$ads         = Gionee_Service_Ng::getAds();
$cacheVer    = crc32(json_encode($ads));
$vKey        = Gionee_Service_Ng::KEY_NG_AD; //版本号相关的缓存内容
$oldCacheVer = $rc->get($vKey);
if ($oldCacheVer != $cacheVer) {
	$rc->set($vKey, $cacheVer, Common::T_ONE_DAY);
	$out .= "ad cache change {$cacheVer} \n";
}

//网址大全数据
Gionee_Service_SiteContent::getSitesData();
$out .= 'sitemap cache data';

echo $out;
Gionee_Service_CronLog::add(array('type' => 'gen_data', 'msg' => $out));

