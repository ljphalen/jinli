<?php
return array(
	1 => BASE_PATH . 'data/reader/read_mode.html',
	2 => BASE_PATH . 'data/reader/readermobile.js',
	3 => BASE_PATH . 'data/reader/readernight.js'
);
