<?php
if (!defined('BASE_PATH')) exit ('Access Denied!');
return array(
	'secretKey'   => '92fe5927095eaac53cd1aa3408da8135',
	'mainMenu'    => 'configs/mainMenu.php',
	'attachPath'  => BASE_PATH . '../attachs/3g/attachs/',
	'dataPath'    => BASE_PATH . 'data/',
	'logPath'     => BASE_PATH . 'data/logs/',
);