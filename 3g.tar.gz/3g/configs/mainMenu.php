<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
//菜单配置
$config['Admin_System'] = array(
	'name'  => '系统',
	'items' => array(
		array(
			'name'  => '用户',
			'items' => array(
				'Admin_User',
				'Admin_Group',
				'Admin_User_passwd'
			),
		),
		'Admin_Config',
		'Admin_UploadRes',
		'Admin_CleanVer',
		'Admin_BaiduKeywords',
		array(
			'name'  => '运行监控',
			'items' => array(
				'Admin_Config_errlog',
				'Admin_Config_cronlog',
				'Admin_Config_cronrun_1',
				'Admin_Config_cronrun_2',
			),
		),
		'Admin_CheckUrl',
		'Admin_Online_Log',
		'Admin_Income',
	)
);

$config['Admin_Product'] = array(
	'name'  => '运营',
	'items' => array(
		'Admin_Sites',
		'Admin_Ad',
		array(
			'name'  => '产品管理',
			'items' => array(
				'Admin_Series',
				'Admin_Models',
				'Admin_Product',
				'Admin_Productattribute',
			)
		),
		array(
			'name'  => '专题管理',
			'items' => array(
				'Admin_Subject',
				'Admin_Gousubject',
				'Admin_Gamesubject',
				'Admin_Imcsubject',
				'Admin_Caipiao',
			)
		),
		array(
			'name'  => '资源管理',
			'items' => array(
				'Admin_Resource',
				'Admin_Resourceassign',
			)
		),
		array(
			'name'  => '签到管理',
			'items' => array(
				'Admin_Prize',
			)
		),
		array(
			'name'  => '会员管理',
			'items' => array(
				'Admin_Gioneeuser',
			)
		),
		'Admin_Area',
		'Admin_Address',
		'Admin_Questions',
		'Admin_React',
		'Admin_Picture',

		'Admin_E7',
		array(
			'name'  => '导航相关内容',
			'items' => array(
				'Admin_Parter',
				'Admin_Attribute',
			)
		),
	)
);
$config['Admin_Nav']     = array(
	'name'  => '导航',
	'items' => array(
		array(
			'name'  => '导航管理',
			'items' => array(
				'Admin_Ngtype',
				'Admin_Ngtype2',
				'Admin_Ng',
				'Admin_Ngimport',
				'Admin_Ng_picimport',
				'Admin_Vendor',
				'Admin_Machine',
			)
		),
		array(
			'name'  => '老版应用',
			'items' => array(
				'Admin_Apptype',
				'Admin_App',
			)
		),
		array(
			'name'  => '新版应用',
			'items' => array(
				'Admin_Webapptype',
				'Admin_Webthemetype',
				'Admin_Webapp',
				'Admin_Appconfig',
				'Admin_Webapp_picimport',
				'Admin_Webapp_picimport2',
			)
		),
		array(
			'name'  => '专题管理',
			'items' => array(
				'Admin_Topic',
				'Admin_Feedback',
				'Admin_Createurl'
			)
		),
		array(
			'name'  => '老版导航',
			'items' => array(
				'Admin_Navbottom',
			)
		),

		array(
			'name'  => 'Elife管理',
			'items' => array(
				'Admin_Elifeserver',
			)
		),
		array(
			'name'  => '短链接管理',
			'items' => array(
				'Admin_Shorturl',
				'Admin_Shortlist'
			)
		)
	)
);

$config['Admin_UCenter'] = array(
	'name'  => '用户中心',
	'items' => array(
		'Admin_Config_UserConfig',
		array(
			'name'  => '用户管理',
			'items' => array(
				'Admin_Register',
			)
		),
		array(
			'name'  => '等级权限',
			'items' => array(
				'Admin_Uprivilege_base',
				'Admin_Uprivilege'
			)
		),
		array(
			'name'  => '畅聊管理',
			'items' => array(
				'Admin_Voip_config',
				'Admin_Voip',
				'Admin_Voip_census'
			)
		),
		array(
			'name'  => '广告管理',
			'items' => array(
				'Admin_Position',
				'Admin_Ads'
			)
		),

		array(
			'name'  => '商品管理',
			'items' => array(
				'Admin_Category',
				'Admin_Commodities',
				'Admin_Produces',
			),
		),

		array(
			'name'  => '交易管理',
			'items' => array(
				'Admin_Order',
				'Admin_Order_Done',
				'Admin_Order_Cancel'
			)
		),

		array(
			'name'  => '日志信息',
			'items' => array(
				'Admin_Logs',
				'Admin_Logs_InnerMsg',
				'Admin_Logs_Api'
			)
		),

		array(
			'name'  => '统计数据',
			'items' => array(
				'Admin_Usummary',
				//'Admin_Usummary_score',
				//'Admin_Usummary_money',
				//'Admin_Usummary_order'
			)
		),
	)
);

$config['Admin_news'] = array(
	'name'  => '新闻',
	'items' => array(
		'Admin_Jhnews',
		array(
			'name'  => '新闻配置平台',
			'items' => array(
				'Admin_Jhtype',
				'Admin_Outnews',
			)
		),
		'Admin_Sohu',
		'Admin_Sohutj',
	)
);

$config['Admin_Look'] = array(
	'name'  => '浏览器',
	'items' => array(
		'Admin_Page',
		array(
			'name'  => '初始配置',
			'items' => array(
				'Admin_Bookmark',
				'Admin_Browserurl',
				'Admin_Browserurl_2',
				'Admin_Browserurl_3',
			)
		),
		array(
			'name'  => '分机型控制',
			'items' => array(
				'Admin_Browser_conf',
				'Admin_Browser_brand',
				'Admin_Browser_series',
				'Admin_Browser_model',
			)
		),

		'Admin_Blackurl',
		'Admin_Welcome',
		'Admin_Splash',
		array(
			'name'  => 'APP数据管理',
			'items' => array(
				'Admin_Local',
				'Admin_Locallist',
			)
		),
		array(
			'name'  => '推荐站点',
			'items' => array(
				'Admin_Recwebsite',
				'Admin_Recwebsite_group',
				'Admin_Recwebsite_tourl',
			)
		),
	)
);
$config['Admin_Ju']   = array(
	'name'  => '聚合页',
	'items' => array(
		'Admin_Column',
		'Admin_Outnews'
	)
);
$config['Admin_Stat'] = array(
	'name'  => '统计',
	'items' => array(
		array(
			'name'  => 'PV/UV统计',
			'items' => array(
				'Admin_Stat_pv2',
				'Admin_Stat_uv',
				'Admin_Stat_uv2',
				'Admin_Stat_cooperate'
			)
		),
		array(
			'name'  => '汇总信息',
			'items' => array(
				'Admin_Stat_amount',
			)
		),

		array(
			'name'  => '导航相关统计',
			'items' => array(
				'Admin_Stat_shorturl',
				'Admin_Stat_ng',
				'Admin_Stat_content',
				'Admin_Stat_column',
				'Admin_Stat_leading',
			)
		),
		array(
			'name'  => '专题统计',
			'items' => array(
				'Admin_Stat_topiclist',
				'Admin_Stat',
			)
		),
		array(
			'name'  => '其它统计',
			'items' => array(
				'Admin_Stat_hotwords',
				'Admin_Stat_tourl',
				'Admin_Stat_monkeynum',
			)
		),
	),
);


$entry = Yaf_Registry::get('config')->adminroot;
$view  = array(
	'Admin_User'              => array('管理员列表', $entry . '/Admin/User/index'),
	'Admin_Group'             => array('用户组管理', $entry . '/Admin/Group/index'),
	'Admin_User_passwd'       => array('修改密码', $entry . '/Admin/User/passwd'),
	'Admin_Product'           => array('产品列表', $entry . '/Admin/Product/index'),
	'Admin_Series'            => array('系列管理', $entry . '/Admin/Series/index'),
	'Admin_Sites'             => array('网址大全', $entry . '/Admin/Sites/index'),
	'Admin_Ad'                => array('广告管理', $entry . '/Admin/Ad/index'),
	'Admin_Config'            => array('系统设置', $entry . '/Admin/Config/index'),
	'Admin_Config_cronrun_1'  => array('导航新闻', $entry . '/Admin/Config/cronrun?type=nav_news'),
	'Admin_Config_cronrun_2'  => array('聚合新闻', $entry . '/Admin/Config/cronrun?type=out_news'),
	'Admin_Config_cronlog'    => array('任务日志', $entry . '/Admin/Config/cronlog'),
	'Admin_Config_errlog'     => array('错误日志', $entry . '/Admin/Config/errlog'),


	'Admin_Income'            => array('收入统计', $entry . '/Admin/Config/income'),
	'Admin_Config_UserConfig' 	 =>array('模板配置',$entry.'/Admin/Config/innermsgTpl'),
	'Admin_Register'          => array('用户列表', $entry . '/Admin/Register/index'),
	'Admin_UCenter_Config'    => array('基本配置', $entry . '/Admin/UCenter/config'),
	'Admin_Position'          => array('广告位管理', $entry . '/Admin/Position/index'),
	'Admin_Ads'               => array('广告管理', $entry . '/Admin/Ads/index'),
	'Admin_Uprivilege_base'   => array('基本配置管理', $entry . '/Admin/Uprivilege/base'),
	'Admin_Uprivilege'        => array('等级权限管理', $entry . '/Admin/Uprivilege/level'),
	'Admin_Category'          => array('分类管理', $entry . '/Admin/Category/index'),
	'Admin_Produces'          => array('生产类商品', $entry . '/Admin/Produces/index'),
	'Admin_Commodities'       => array('消费类商品', $entry . '/Admin/Commodities/index'),

	'Admin_Order'             => array('待处理订单', $entry . '/Admin/Order/index'),
	'Admin_Order_Done'        => array('已完成订单', $entry . '/Admin/Order/index?type=1'),
	'Admin_Order_Cancel'      => array('已取消订单', $entry . '/Admin/Order/index?type=-1'),

	'Admin_Logs'              => array('积分日志', $entry . '/Admin/Logs/score'),
	'Admin_Logs_InnerMsg'     => array('站内信', $entry . '/Admin/Logs/innerMsg'),
	'Admin_Logs_Api'          => array('充值API接口日志', $entry . '/Admin/Logs/rechargeLog'),

	//'Admin_Usummary'				=>array('PV/UV统计',$entry.'/Admin/Usummary/index'),
	'Admin_Usummary'          => array('积分/任务统计', $entry . '/Admin/Usummary/score'),
	'Admin_Usummary_money'    => array('资金统计', $entry . '/Admin/Usummary/money'),
	'Admin_Usummary_order'    => array('订单统计', $entry . '/Admin/Usummary/order'),

	'Admin_Stat_pv2'          => array('PV统计', $entry . '/Admin/Stat/pv2'),
	'Admin_Stat_uv'           => array('UV统计', $entry . '/Admin/Stat/uv'),
	'Admin_Stat_uv2'          => array('UV统计2', $entry . '/Admin/Stat/uv2'),
	'Admin_Stat_shorturl'     => array('短链统计', $entry . '/Admin/Stat/shorturl'),
	'Admin_Stat_ng'           => array('导航统计', $entry . '/Admin/Stat/ng?tab=1'),
	'Admin_Stat_content'      => array('内容统计', $entry . '/Admin/Stat/content'),
	'Admin_Stat_column'       => array('栏目统计', $entry . '/Admin/Stat/column'),
	'Admin_Stat_leading'      => array('CP&导流统计', $entry . '/Admin/Stat/leading'),
	'Admin_Stat_cooperate'    => array('对外合作页PV统计', $entry . '/Admin/Stat/cooperate'),
	'Admin_Stat_hotwords'     => array('热词&搜索统计', $entry . '/Admin/Stat/hotwords'),
	'Admin_Stat_amount'       => array('当日总点击量', $entry . '/Admin/Stat/amount'),
	'Admin_Stat'              => array('专题意见统计', $entry . '/Admin/Stat/suggestion'),
	'Admin_Stat_topiclist'    => array('专题列表', $entry . '/Admin/Stat/topicList'),
	'Admin_Online_Log'        => array('上线日志', $entry . '/Admin/Config/addlog'),
	'Admin_Page'              => array('三屏配置', $entry . '/Admin/Page/index'),
	'Admin_Bookmark'          => array('书签配置', $entry . '/Admin/Bookmark/index'),
	'Admin_Browserurl'        => array('搜索配置', $entry . '/Admin/Browserurl/index?type=1'),
	'Admin_Browserurl_2'      => array('推荐网址', $entry . '/Admin/Browserurl/index?type=2'),
	'Admin_Browserurl_3'      => array('网址库', $entry . '/Admin/Browserurl/index?type=3'),

	'Admin_Browser_brand'     => array('品牌管理', $entry . '/Admin/Browserurl/brandlist'),
	'Admin_Browser_series'    => array('系列管理', $entry . '/Admin/Browserurl/serieslist'),
	'Admin_Browser_model'     => array('机型管理', $entry . '/Admin/Browserurl/modellist'),
	'Admin_Browser_conf'      => array('设置', $entry . '/Admin/Browserurl/conf'),

	'Admin_Blackurl'          => array('黑白名单', $entry . '/Admin/Blackurl/index'),
	'Admin_Welcome'           => array('欢迎图片', $entry . '/Admin/Welcome/index'),
	'Admin_Splash'            => array('闪屏管理', $entry . '/Admin/Splash/index'),
	'Admin_Local'             => array('添加数据', $entry . '/Admin/Local/add'),
	'Admin_Locallist'         => array('数据列表', $entry . '/Admin/Local/list'),
	'Admin_Series'            => array('系列管理', $entry . '/Admin/Series/index'),
	'Admin_Models'            => array('机型管理', $entry . '/Admin/Models/index'),
	'Admin_Gioneeuser'        => array('会员管理', $entry . '/Admin/Gioneeuser/index'),
	'Admin_Resource'          => array('资源管理', $entry . '/Admin/Resource/index'),
	'Admin_Resourceassign'    => array('分配资源管理', $entry . '/Admin/Resourceassign/index'),
	'Admin_Area'              => array('省市管理', $entry . '/Admin/Area/index'),
	'Admin_Address'           => array('网点管理', $entry . '/Admin/Address/index'),
	'Admin_Questions'         => array('常见问题管理', $entry . '/Admin/Questions/index'),
	'Admin_React'             => array('用户问题反馈', $entry . '/Admin/React/index'),
	'Admin_Picture'           => array('图片管理', $entry . '/Admin/Picture/index'),
	'Admin_Subject'           => array('专题管理', $entry . '/Admin/Subject/index'),
	'Admin_Gousubject'        => array('金立购专题', $entry . '/Admin/Gousubject/index'),
	'Admin_Gamesubject'       => array('游戏专题', $entry . '/Admin/Gamesubject/index'),
	'Admin_Imcsubject'        => array('IMC专题', $entry . '/Admin/Imcsubject/index'),
	'Admin_Caipiao'           => array('彩票合作活动专题', $entry . '/Admin/Subject/Caipiao'),
	'Admin_Voip_config'       => array('基本配置', $entry . '/Admin/Voip/config'),
	'Admin_Voip'              => array('基本信息', $entry . '/Admin/Voip/index'),
	'Admin_Voip_census'       => array('统计信息', $entry . '/Admin/Voip/census'),
	'Admin_Parter'            => array('合作商管理', $entry . '/Admin/Parter/list'),
	'Admin_Attribute'         => array('导航属性管理', $entry . '/Admin/Attribute/index'),
	'Admin_Jhnews'            => array('新闻管理', $entry . '/Admin/Jhnews/index'),
	'Admin_Jhtype'            => array('分类管理', $entry . '/Admin/Jhtype/index'),
	'Admin_Sohu'              => array('搜狐广告管理', $entry . '/Admin/Sohu/index'),
	'Admin_Sohutj'            => array('搜狐广告统计', $entry . '/Admin/Sohutj/index'),
	'Admin_Navbottom'         => array('导航底部管理', $entry . '/Admin/Navbottom/index'),
	'Admin_Ngtype'            => array('首页分类管理', $entry . '/Admin/Ngtype/index?page_id=1'),
	'Admin_Ngtype2'           => array('子页分类管理', $entry . '/Admin/Ngtype/index?page_id=2'),
	'Admin_Ng'                => array('导航管理', $entry . '/Admin/Ng/index'),
	'Admin_Ngimport'          => array('导航导入', $entry . '/Admin/Ng/import'),
	'Admin_Ng_picimport'      => array('导航图标导入', $entry . '/Admin/Ng/picimport'),
	'Admin_Vendor'            => array('渠道号管理', $entry . '/Admin/Vendor/index'),
	'Admin_Machine'           => array('功能机管理', $entry . '/Admin/Machine/index'),
	'Admin_Apptype'           => array('应用分类管理', $entry . '/Admin/Apptype/index'),
	'Admin_App'               => array('应用管理', $entry . '/Admin/App/index'),
	'Admin_Webapptype'        => array('应用分类管理', $entry . '/Admin/Webapptype/index'),
	'Admin_Webthemetype'      => array('专题分类管理', $entry . '/Admin/Webthemetype/index'),
	'Admin_Webapp'            => array('应用管理', $entry . '/Admin/Webapp/index'),
	'Admin_Webapp_picimport'  => array('图标导入', $entry . '/Admin/Webapp/picimport?type=icon'),
	'Admin_Webapp_picimport2' => array('图标2导入', $entry . '/Admin/Webapp/picimport?type=icon2'),
	'Admin_Appconfig'         => array('应用配置', $entry . '/Admin/Appconfig/index'),
	'Admin_Productattribute'  => array('属性管理', $entry . '/Admin/Productattribute/index'),
	'Admin_Topic'             => array('专题管理', $entry . '/Admin/Topic/index'),
	'Admin_Feedback'          => array('反馈管理', $entry . '/Admin/Feedback/index'),
	'Admin_Createurl'         => array('生成内容链接', $entry . '/Admin/Topic/createurl'),
	'Admin_Elifeserver'       => array('产品管理', $entry . '/Admin/Elifeserver/index'),
	'Admin_Shorturl'          => array('手动添加短链接', $entry . '/Admin/Shorturl/add'),
	'Admin_Shortlist'         => array('短链接列表', $entry . '/Admin/Shorturl/list'),
	'Admin_Column'            => array('栏目管理', $entry . '/Admin/Column/index'),
	'Admin_Outnews'           => array('新闻管理', $entry . '/Admin/Outnews/index'),
	'Admin_Gamepad_setting'   => array('问卷设置', $entry . '/Admin/Gamepad/setting'),
	'Admin_Gamepad_list'      => array('问卷用户列表', $entry . '/Admin/Gamepad/list'),
	'Admin_Gamepad_stats'     => array('问卷统计报表', $entry . '/Admin/Gamepad/stats'),
	'Admin_E7'                => array('E7用户报表', $entry . '/Admin/E7/index'),
	'Admin_UploadRes'         => array('前端文件管理', $entry . '/Admin/Config/uploadRes'),
	'Admin_CleanVer'          => array('缓存清除', $entry . '/Admin/Config/cleanver'),
	'Admin_BaiduKeywords'     => array('百度热词', $entry . '/Admin/Config/baidukeywords'),
	'Admin_CheckUrl'          => array('URL检测', $entry . '/Admin/Config/checkUrl'),
	'Admin_Recwebsite'        => array('推荐网址', $entry . '/Admin/Recwebsite/listsite?type=url'),
	'Admin_Recwebsite_group'  => array('推荐站点', $entry . '/Admin/Recwebsite/listsite?type=site'),
	'Admin_Recwebsite_tourl'  => array('固定网址', $entry . '/Admin/Recwebsite/tourl'),
	'Admin_Stat_tourl'        => array('书签统计', $entry . '/Admin/Stat/tourl'),
	'Admin_Stat_monkeynum'    => array('接口性能', $entry . '/Admin/Stat/monkeynum'),

);

return array($config, $view);