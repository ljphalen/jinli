<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
$config = array(
	'test'    => array(
		'default' => array(
			'adapter'      => 'PDO_MYSQL',
			'host'         => '127.0.0.1',
			'username'     => 'root',
			'password'     => 'root',
			'dbname'       => '3g',
			'displayError' => 1
		)
	),
	'product' => array(
		'default' => array(
			'adapter'      => 'PDO_MYSQL',
			'host'         => 'gioneedb.mysql.aliyun.com',
			'username'     => 'prod3gadmindbw',
			'password'     => 'sdyhj123',
			'dbname'       => 'prod3gadmindb',
			'displayError' => 0
		)
	),
	'develop' => array(
		'default' => array(
			'adapter'      => 'PDO_MYSQL',
			'host'         => '127.0.0.1',
			'username'     => 'root',
			'password'     => 'root',
			'dbname'       => '3g',
			'displayError' => 1
		)
	)
);
return defined('ENV') ? $config[ENV] : $config['product'];