<?php

return array(

	//用户等级
	'rank'             => array(
		'1' => array(
			'1'  => array('level' => 1, 'name' => '实习生', 'range' => '0-49'),
			'2'  => array('level' => 2, 'name' => '试用期', 'range' => '50-149'),
			'3'  => array('level' => 3, 'name' => '职场新人', 'range' => '150-349'),
			'4'  => array('level' => 4, 'name' => '助理', 'range' => '350-749'),
			'5'  => array('level' => 5, 'name' => '见习主管', 'range' => '750-1349'),
			'6'  => array('level' => 6, 'name' => '主管', 'range' => '1350-2249'),
			'7'  => array('level' => 7, 'name' => '初级经理', 'range' => '2250-3349'),
			'8'  => array('level' => 8, 'name' => '中级经理', 'range' => '3350-5624'),
			'9'  => array('level' => 9, 'name' => '高级经理', 'range' => '5625-8662'),
			'10' => array('level' => 10, 'name' => '部门总监', 'range' => '8663-13218'),
			'11' => array('level' => 11, 'name' => '区域总监', 'range' => '13219-20053'),
		),
		'2' => array(
			'1'  => array('level' => 1, 'name' => '列兵', 'range' => '0-49'),
			'2'  => array('level' => 2, 'name' => '军士', 'range' => '50-149'),
			'3'  => array('level' => 3, 'name' => '准尉', 'range' => '150-349'),
			'4'  => array('level' => 4, 'name' => '少尉', 'range' => '350-749'),
			'5'  => array('level' => 5, 'name' => '中尉', 'range' => '750-1349'),
			'6'  => array('level' => 6, 'name' => '上尉', 'range' => '1350-2249'),
			'7'  => array('level' => 7, 'name' => '少校', 'range' => '2250-3359'),
			'8'  => array('level' => 8, 'name' => '中校', 'range' => '3360-5624'),
			'9'  => array('level' => 9, 'name' => '上校', 'range' => '5625-8662'),
			'10' => array('level' => 10, 'name' => '少将', 'range' => '8663-13218'),
			'11' => array('level' => 11, 'name' => '中将', 'range' => '13219-20053'),
			'12' => array('level' => 12, 'name' => '上将', 'range' => '20054-32896'),
			'13' => array('level' => 13, 'name' => '元帅', 'range' => '32897-50968'),
			'14' => array('level' => 14, 'name' => '大元帅', 'range' => '50968-@'),
		)
	),

	//等级分组
	'level_group_name' => array(
		'1' => '职场称谓',
		'2' => '军衔称谓',
	),
	//活动分类
	'action_type'      => array(
		'1' => array('key' => 'signin', 'val' => '打卡'),
		'2' => array('key' => 'product', 'val' => '生产类商品'),
		'3' => array('key' => 'cosume', 'val' => '消费类商品'),
	),

	//签到基本配置
	'signin'           => array(
		'name' => '打卡', 'scores' => '5', 'continueDays' => '7', 'rewards' => '20', 'status' => '1'
	),

	//用户操作事件
	'event'            => array(
		'1' => array('tag' => 'signin', 'name' => '签到', 'status' => 1, 'rule' => 'innerMsg,scoreLog'),
		'2' => array('tag' => 'ads', 'name' => '看图', 'status' => 1, 'rule' => 'innerMsg, scoreLog'),
		'3' => array('tag' => 'fare', 'name' => '兑换话费', 'status' => 1, 'rule' => 'innerMsg,scoreLog,msg'),
		'4' => array('tag' => 'incr', 'name' => '增加积分', 'status' => 1, 'rule' => 'innerMsg,scoreLog'),
		'5' => array('tag' => 'desc', 'name' => '减少积分', 'status' => 0, 'rule' => 'innerMsg,scoreLog'),
	),

	//订单状态
	'statusFlag'       => array(
		'-1' => '取消',
		'0'  => '待处理',
		'1'  => '已完成',
		'2'  => '处理中',
	),
	//支付状态
	'pay_status'       => array(
		'-1' => '支付失败',
		'0'  => '待支付',
		'1'  => '已支付',
		'2'  => '支付中',
		'3'  => '退还积分'
	),
	//发货状态（目前并无用到，主要针对后者可能的实物商品）
	'shipping_status'  => array(
		'0'  => '待处理',
		'1'  => "已完成",
		'2'  => '配送中',
		'3'  => '已发货',
		'-1' => '取消配送',
	),
	//积分变动标识
	/**
	 * 设置规则为1 开头为用户动作赚取的积分动作  2 开头为 对用户赠送的积分动作 3 开头的key 为用户消费积分的动作行为
	 */
	'actions'          => array(
		'101' => '签到',
		'102' => '看图',
		'103' => '下载游戏',
		'201' => '连续签到奖励',
		'202' => '单天连续操作奖励',
		'203' => '中奖发放',
		'204' => '升级奖励',
		'205' => '返还冻结积分',
		'301' => '兑换话费',
		'302' => '兑换流量',
		'303' => '抽奖消耗',
		'304' => '兑换礼品',
		'305' =>'兑换购物券',
		'401' => '扣除冻结积分'
	),

	//广告位标识符
	'pos_identifiers'  => array(
		'index'   => array('identifier' => 'SYPA', 'tag' => '首页广告位'),
		'cosume'  => array('identifier' => 'JFXH', 'tag' => '积分兑换页广告位'),
		'produce' => array('identifier' => 'JFCS', 'tag' => '产生积分的广告位'),
		'pwords'  => array("identifier" => 'CSWZ', 'tag' => '产生积分的文字广告位'),
	),

	//充值状态
	'recharge_status'  => array(
		'-1' => '充值失败',
		'0'  => '充值中',
		'1'  => '充值成功'
	),

	'ofpay_api_log'    => array(
		'1' 	=> 	'手机话费充值',
		'2'	=>	'购物券',
		'3'    =>	'手机流量包',
		'4'	=>	'推广'
	),
);