<?php
return array(
	'test'    => array(
		'host'       => '127.0.0.1',
		'port'       => '6379',
		'key-prefix' => '3g'
	),
	'product' => array(
		'host'       => '10.200.230.122',
		'port'       => '6779',
		'key-prefix' => '3g'
	),
	'develop' => array(
		'host'       => '127.0.0.1',
		'port'       => '6379',
		'key-prefix' => '3g'
	)
);
