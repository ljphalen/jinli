<?php

if (!defined('BASE_PATH')) exit('Access Denied!');

//用户中心公用类
class Common_Service_User {
	
	//积分日志类
	public static function scorelog($options){
		self::score($options);
	}
	//站内信
	public static function innerMsg($options){
		
	}
	/**
	 * 用户等级称谓
	 * @param int $level 用户当前等级
	 * @param int $levelType 用户当前升级类别
	 * @return string 称谓
	 */
	public static function getUserLevelByLevel($level,$levelGroup = 1){
		if(!is_numeric($level)) return false;
		$levelConfig = self::getConfigByType('userConfig', 'rank',$levelGroup);
		 return  $levelConfig[$level];
	}
	
	/**
	 * 
	 * @param int $score 用户所获得的积分数
	 * @param int  $curLevel 用户等级
	 * @param number $levelType 升级类别
	 * 用户积分变化后，要检测是否等级提升
	 */
	public static function updateUserLevelByScore($uid,$score,$curLevel,$levelGroup=1){
		$levelConfig = self::getConfigByType('userConfig','rank',$levelGroup);
		$scoreRange = explode('-', $levelConfig[$curLevel]['range']);
		if($score>=$scoreRange[1]){ //如果总积分大于当前等级最大积分数，就升一级
			  $res = Gionee_Service_User::updateUser(array('user_level'=>$curLevel+1), $uid);
		}
	}
	/**
	 * 
	 * @param unknown $filename 配置文件名
	 * @param unknown $type		  类型
	 * @param unknown $levelType 分组（如果有的话）
	 * @return number
	 */
	public  static function  getConfigByType($filename,$type,$levelType=0){
		$config =  Common::getConfig($filename,$type);
		$levelData = $config[$levelType]?$config[$levelType]:$config;
		return $levelData;
	}

	/**
	 * 获取城市信息
	 */
	public  static function getAreaDataByParentId($parent_id = 0){
		$key = "USER:AREA:LIST:".$parent_id;
		$dataList = Common::getCache()->get($key);
		if(empty($dataList)){
			$dataList = Gionee_Service_Area::getListByParentId($parent_id);
			Common::getCache()->set($key,$dataList,24*3600);
		}
		return $dataList;
	}
	//用户赚取积分相关操作
	/**
	 * 
	 * @param int  $uid 		用户ID
	 * @param int  $goup_id		分组信息（1:签到，2：生产积分类商品）
	 * @param number $cat_id
	 * @param number $goods_id
	 * @param number $action_type
	 * @param int $scores 返回获得的积分数
	 * @param int $score_type 积分类型
	 */
	public  static function scoreVarify($params=array('uid'=>0,'group_id'=>1,'cat_id'=>0,'goods_id'=>'0','user_level'=>'1','level_group'=>'1','act_id'=>'1','score'=>'0','score_type'=>101))
	{
		$totalIncreScores = 0;//单次总赚取的积分数
		$scoreMsg = User_Service_Gather::getBy(array('uid'=>$params['uid']));
		if(empty($scoreMsg)){
			return array('key'=>'-2','msg'=>'用户信息有误!');
		}
		//用户等级检测
		$scores = array();
		$ret = $earnLog = $verifyLog = false;
		$data = self::_checkUserRewardGoods($params);
		$totalIncreScores = $data['sum'];
		$scores['total_score'] =$scoreMsg['total_score'] + $data['sum'];
		$scores['remained_score'] = $scoreMsg['remained_score']+$data['sum'];
		$ret = User_Service_Gather::update($scores,$scoreMsg['id']); //更新用户汇总信息表
		if($ret){
			$earnLog = self::_addEarnScoresLogInfo($params,$data['verifyScore']); 
		   $verifyLog =  self::_addUserScoreVierfyLog($params,$data,$scoreMsg['remained_score']);//写积分变动日志
		}
		//如果用户积分满足升级条件，就给其升级
		self::updateUserLevelByScore($params['uid'], $scores['total_score'], $params['user_level'],$params['level_group']);
		if($ret  && $earnLog && $verifyLog){
			return $totalIncreScores;
		}
		return 0;
	}
	
	//检测是否是用户权限商品，并返回相应等级所能得到的积分数
	private static function _checkUserRewardGoods($params = array()){
		if(!is_array($params)) return false;
		$rewards =0;//连续操作N天时送的奖励
		$rewards2 =  0; //单天操作达到N个数量时送的奖励
		$varifyNum  = $params['score'];//默认会传入赚取的积分数
		//首先查看是否是等级商品以及是否设置该分类物品完成任务时的奖励信息
		$privilegeInfo = self::getCateAndGoodsLevelInfo($params['group_id'],$params['cat_id'],$params['goods_id'],$params['user_level'],$params['level_group']);
		if(!empty($privilegeInfo)){
			$varifyNum = $privilegeInfo['scores'];//等级积分
			$operated= User_Service_Rewards::getRwardGoodsInfo(array('uid'=>$params['uid'],'group_id'=>$params['group_id'],'cat_id'=>$params['cat_id'],'goods_id'=>$params['goods_id']));
			if($operated){
				if(date('Ymd',$operated['last_time']) ==date('Ymd',strtotime('-1 day'))){ //是否是连续操作
					if(($operated['continus_days'] + 1) ==$privilegeInfo['days']){ //连续操作达指定天投数时的赠送积分
						$rewards = $privilegeInfo['rewards'];
						$operated['continus_days'] = 0; //归零
					}else{
						$operated['continus_days'] +=1;
					}
				}else{
					$operated['continus_days'] = 1;//间断时，重新开始
				}
				//针对单日次数的奖励检测
				if(date('Ymd',$operated['get_rewards_time']) != date('Ymd',time()) && $operated['get_day_rewards'] == '1'){ //隔天应把单天已领取标识归0
					 $operated['get_day_rewards']=='0';
				}
				if($privilegeInfo['times'] > 0  && $operated['get_day_rewards']=='0'){
					$countParams = array(
							'uid'=>$params['uid'],
							'group_id'=>$params['group_id'],
							'cat_id'=>$params['cat_id'],
							'add_time'=>array(array('>=',mktime(0,0,0)),array('<=',mktime(23,59,59)))
					);
					$count = User_Service_Earn::count($countParams);
					if($count +1 >= $privilegeInfo['times']){
						$rewards2 = $privilegeInfo['rewards2'];
						$operated['get_day_rewards']  = 1; //标为已领取
						$operated['get_rewards_time'] = time();
					}
				}
				$operated['last_time'] = time();
				User_Service_Rewards::edit($operated,$operated['id']);//更新记录
			}else{
				//若是首次，就添加
				$addParams = array(
						'uid'								=>$params['uid'],
						'group_id'					=>$params['group_id'],
						'cat_id'						=>$params['cat_id'],
						'goods_id'					=>$params['goods_id'],
						'last_time'					=>time(),
						'continus_days'			=>1,
				);
				if($privilegeInfo['days']  == 1){
					$rewards = $privilegeInfo['rewards'];
				}
				if($privilegeInfo['times'] == 1){
					$rewards2 = $privilegeInfo['rewards2'];
					$addParams['get_rewards_time'] = time();
					$addParams['get_day_rewards']  = 1;
				}
				User_Service_Rewards::add($addParams);
			}
		}
	return array('verifyScore'=>$varifyNum,'rewards'=>$rewards,'rewards2'=>$rewards2,'sum'=>($varifyNum+$rewards+$rewards2));
	}
	//
	/**
	 * 积分日志
	 * @param array $userMsg 用户信息
	 * @param array $params  要改变的积分信息
	 * ＠param  int 						 积分类型
	 */
	public static function score($params =array()){
		if(!is_array($params)) return false;
		$keys = array_keys($params[0]);
		 return User_Service_ScoreLog::add($keys,$params);
	}
	
	//得到用户积分
	public static function  getUserScore($uid){
			return  User_Service_Gather::getBy(array('uid'=>$uid));
	}
	
	//得到用户等级称谓
	public static function getUserLevelInfo($uid,$level,$levelGroup){
		$rs = Common::getCache();
		$levelKey = "USER:LEVEL:".$uid;
		$levelMsg = $rs->get($levelKey);
		if(empty($levelMsg)){
			$levelMsg = self::getUserLevelByLevel($level, $levelGroup);
			$rs->set($levelKey,$levelMsg,60);
		}
		//下一个等级的信息
		$nextLevel = self::getUserLevelByLevel($level+1,$levelGroup);
		return array('curLevelMsg'=>$levelMsg,'nextLevelMsg'=>$nextLevel);
	}
	//是否有未读的站内信
	public static function isexistsUnreadMessage($uid){
		return  User_Service_InnerMsg::existsUnRead(array('is_read'=>0,'uid'=>$uid));
	}
	//检测用户登陆情况
	public static  function checkLogin($callback_url) {
		$webroot = Common::getCurHost();
		$user    = Gionee_Service_User::ckLogin();
		if (!$user) {
			$callback = $webroot . '/user/login/login';
			$url = Api_Gionee_Oauth::requestToken($callback);
			Util_Cookie::set('GIONEE_LOGIN_REFER', $callback_url, true, Common::getTime() + (5 * 3600), '/');
			return array('key'=>'0','msg'=>$url);
		}
		$scoreMsg = User_Service_Gather::getBy(array('uid'=>$user[2]));
		if(empty($scoreMsg)){
			User_Service_Gather::add(array('uid'=>$user[2]));
		}
		return array('key'=>'1','msg'=>$user);
	}
	
	/**
	 * 返还冻结积分数
	 * @param int  $uid		用户ID
	 * @param int  $orderId	 订单ID
	 * @param int $score_type 积分变动的原因
	 * @param string $flag 		加减积分的标识
	 */
	public static  function changeUserScores($orderId=0,$score_type=0,$flag = '+'){
		if(empty($orderId) || empty($score_type)) return false;
		$orderMsg = User_Service_Order::get($orderId);
		if(!$orderMsg) return false;
		$uid = $orderMsg['uid'];
		$affectedScores = $orderMsg['total_cost_scores']; //受影响的积分数
		$userScores = User_Service_Gather::getBy(array('uid'=>$uid));
		$reminedScores = $userScores['remained_score'];
		if($flag =='+'){
			$userScores['remained_score'] += $affectedScores;
		}
		$userScores['frozed_score'] -= $affectedScores;
		$userScores['affected_score'] = $affectedScores;
		$res = User_Service_Gather::updateBy($userScores,array('uid'=>$uid)); //更新用户积分表
		if($res && $flag =='+'){
			$data[] = array(
					'uid'=>$uid,
					'group_id'=>3,
					'before_score'=>$reminedScores,
					'after_score'=>$userScores['remained_score'],
					'score_type'=>$score_type,
					'affected_score' =>$affectedScores,
					'add_time'=>time()
			) ;
			return Common_Service_User::score($data); //写日志
		}
		return true;
	}
	
	//发送站内信
	public static function sendInnerMsg($data,$type=''){
		$tmpMsg = Gionee_Service_Config::getValue($type);
		$arrMsg = explode('|', $tmpMsg);
		$realMsg =  $data['status'] == 1?$arrMsg[0]:$arrMsg[1];
		$msg = '';
		switch ($type){
			case 'recharge_msg_tpl':
				if(!empty($tmpMsg)){
					$msg = str_replace(array('#PhoneNumber#','#Money#'), array($data['recharge_mobile'],$data['recharge_money']), $realMsg);
				}
				break;
			case 'coupon_msg_tpl':{
				if(!empty($tmpMsg)){
					$msg = str_replace(array("#Money#","#Name#","#Number#","#Password#","#Expire#"), array($data['cardMsg']['card_value'],$data['cardMsg']['type_name'],$data['card']['cardno'],$data['card']['cardpws'],$data['card']['expiretime']), $realMsg);
				}
				break;
			}
			default:
				break;
		}
		if(!empty($tmpMsg)){
			$params = array(
					'uid'=>$data['uid'],
					'type'=>$data['classify'],
					'content'=>$msg,
					'status'=>$data['status'],
					'is_read'=>0,
					'add_time'=>time(),
			);
			return User_Service_InnerMsg::add($params);
		}
	}
	
	
	/**
	 * 用户赚取积分的日志
	 * ＠params $params 基本信息
	 * ＠params $scores  变化的积分数
	 */
	private static function _addEarnScoresLogInfo($params=array(),$scores=0){
		if(empty($params)) return false;
		$options = array(
				'uid'=>$params['uid'],
				'group_id'=>$params['group_id'],
				'cat_id'=>$params['cat_id'],
				'goods_id'=>$params['goods_id'],
				'add_time'=>time(),
				'score'=>$scores
		);
		return  User_Service_Earn::add($options); //添加到赚取积分的商品日志表中
	}
	
	/**
	 * 记录用户积分日志（如果是规则物品，则需要考虑满足条件后的奖励信息）
	 * @param $params array 			用户及物品的基本信息
	 * @param $scores array 				等级商品的奖励积分信息
	 * @param $reScores  int				用户剩余可用积分数
	 * ＠ return BOOL	
	 *
	 */
	
	private static function _addUserScoreVierfyLog($params = array(),$scores =array(),$reScores = 0){
		if(empty($params) || empty($scores)) return false;
		$p = array();
		$beforeScore = $reScores;
		$afterScore = $reScores+$scores['verifyScore'];
		$element = array(
				'uid'=>$params['uid'],
				'group_id'=>$params['group_id'],
				'score_type'=>$params['score_type'],
				'before_score'=>$beforeScore,
				'after_score'=>$afterScore,
				'affected_score'=>$scores['verifyScore'],
				'add_time'=>time(),
				'date'		=>date('Ymd',time())
		);
		array_push($p, $element);
		$beforeScore = $afterScore;
		if($scores['rewards']){
			$afterScore += $scores['rewards'];
			$element1 = array(
					'uid'=>$params['uid'],
					'group_id'=>$params['group_id'],
					'score_type'=>201,
					'before_score'=>$beforeScore,
					'after_score'=>$afterScore,
					'affected_score'=>$scores['rewards'],
					'add_time'=>time(),
					'date'		=>date('Ymd',time())
			);
			array_push($p, $element1);
		}
		$beforeScore = $afterScore;
		if($scores['rewards2']){
			$afterScore += $scores['rewards2'];
			$element2 =  array(
					'uid'=>$params['uid'],
					'group_id'=>$params['group_id'],
					'score_type'=>202,
					'before_score'=>$beforeScore,
					'after_score'=>$afterScore,
					'affected_score'=>$scores['rewards2'],
					'add_time'=>time(),
					'date'		=>date('Ymd',time())
			);
			array_push($p,$element2);
		}
		 return self::score($p);
	}
	
	/**
	 * 获取等级商品及等级分类信息
	 * 默认对单个商品查看，再查看该商品分类是否有设置等级信息
	 * @param $group_id  int 物品类别
	 * @param $cat_id 	int 		分类IID
	 * @param $goods_id int 	物品ID
	 * @param $user_level		用户等级
	 * @param $level_group	等级类别
	 */
	public  static  function getCateAndGoodsLevelInfo($group_id = '',$cat_id  =0,$goods_id= 0,$user_level=1,$level_group=1){
		$params = array();
		$params['group_id']  = $group_id;
		$params['cat_id'] = $cat_id;
		$params['goods_id'] = $goods_id;
		$params['user_level'] = $user_level;
		$params['level_group'] = $level_group;
		$res =  User_Service_Uprivilege::getBy($params);
		if(empty($res)){
			unset($params['goods_id']);
			$res = User_Service_Uprivilege::getBy($params);
		}
		return $res;
	}
	
	
	//获得用户积分信息
	public static function getUserScoresMsg($uid){
		$key = "USER:SCORES:".$uid;
		$userScores = Common::getCache()->get($key);
		if(empty($userScores)){
			$userScores = User_Service_Gather::getBy(array('uid'=>$uid));
			Common::getCache()->set($key,$userScores,30);
		}
		return  $userScores;
	}
	
	//通过页面类别获得广告
	public static function getAdsByPageType($ptype){
		if(!$ptype) return false;
		$config = Common::getConfig('userConfig','pos_identifiers');
		$identifer = $config[$ptype]['identifier'];
		$posInfo = Gionee_Service_Position::getBy(array('identifier'=>$identifer));
		if(!$posInfo)	return false;
		$key = '3G:USER:ADS:'.$ptype;
		$ads = Common::getCache()->get($key);
		if(empty($ads)){
			$params = array();
			$params['position_id'] = $posInfo['id'];
			$params['status'] = 1;
			$params['start_time'] = array('<=',Common::getTime());
			$params['end_time'] = array('>=',Common::getTime());
			$ads = Gionee_Service_Ads::getsBy($params,array('sort'=>'DESC','id'=>'DESC'));
			Common::getCache()->set($key,$ads,60);
		}
		return $ads;
	}
}
	