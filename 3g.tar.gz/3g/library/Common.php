<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Enter description here ...
 * @author rainkid
 *
 */
class Common {
	static $urlPwd = '39djg0c7b';

	const T_ONE_DAY = 86400;
	const T_TEN_MIN = 600;

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $serviceName
	 */
	static public function getService($serviceName) {
		return Common_Service_Factory::getService($serviceName);
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $daoName
	 */
	static public function getDao($daoName) {
		return Common_Dao_Factory::getDao($daoName);
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $fileName
	 * @param unknown_type $key
	 */
	static public function getConfig($fileName, $key = '') {
		static $config = array();

		$name = md5($fileName);

		if (!isset($config[$name]) || !$config[$name]) {
			$file = realpath(BASE_PATH . 'configs/' . $fileName . '.php');
			if (is_file($file)) $config[$name] = include $file;
		}
		if ($key) {
			return isset($config[$name][$key]) ? $config[$name][$key] : '';
		} else {
			return isset($config[$name]) ? $config[$name] : '';
		}
	}

	/**
	 * 字符串加密解密
	 * @param string $string 需要处理的字符串
	 * @param string $action {ENCODE:加密,DECODE:解密}
	 * @return string
	 */
	static public function encrypt($string, $action = 'ENCODE') {
		if (!in_array($action, array('ENCODE', 'DECODE'))) $action = 'ENCODE';
		$encrypt = new Util_Encrypt(self::getConfig('siteConfig', 'secretKey'));
		if ($action == 'ENCODE') { //加密
			return $encrypt->desEncrypt($string);
		} else { //解密
			return $encrypt->desDecrypt($string);
		}
	}

	/**
	 * 金额格式化
	 * @param  $num
	 * @return string
	 */
	static public function money($num) {
		if (function_exists("money_format")) {
			return money_format('%.2n', $num);
		} else {
			return number_format($num, 2, '.', '');
		}
	}

	/**
	 * 获得token  表单的验证
	 * @return string
	 */
	static public function getToken($userInfo) {
		if (!isset($_COOKIE['_securityCode']) || '' == $_COOKIE['_securityCode']) {
			/*用户登录的会话ID*/
			$key = substr(md5(serialize($userInfo) . ':' . time() . ':' . $_SERVER['HTTP_USER_AGENT']), mt_rand(1, 8), 8);
			setcookie('_securityCode', $key, null, '/'); //
			$_COOKIE['_securityCode'] = $key; //IEbug
		}
		return $_COOKIE['_securityCode'];
	}

	/**
	 * 验证token
	 * @param string $token
	 * @return mixed
	 */
	static public function checkToken($token) {
		if (!$_COOKIE['_securityCode']) return self::formatMsg(-1, '非法请求'); //没有token的非法请求
		if (!$token || ($token !== $_COOKIE['_securityCode'])) return self::formatMsg(-1, '非法请求'); //token错误非法请求
		return true;
	}

	/**
	 * 分页方法
	 * @param int $count
	 * @param int $page
	 * @param int $perPage
	 * @param string $url
	 * @param string $ajaxCallBack
	 * @return string
	 */
	static public function getPages($count, $page, $perPage, $url, $ajaxCallBack = '') {
		return Util_Page::page($count, $page, $perPage, $url, '=', $ajaxCallBack = '');
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $code
	 * @param unknown_type $msg
	 * @param unknown_type $data
	 */
	static public function formatMsg($code, $msg = '', $data = array()) {
		return array(
			'code' => $code,
			'msg'  => $msg,
			'data' => $data
		);
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $length
	 */
	static public function randStr($length) {
		$randstr = "";
		for ($i = 0; $i < (int)$length; $i++) {
			$randnum = mt_rand(0, 61);
			if ($randnum < 10) {
				$randstr .= chr($randnum + 48);
			} else if ($randnum < 36) {
				$randstr .= chr($randnum + 55);
			} else {
				$randstr .= chr($randnum + 61);
			}
		}
		return $randstr;
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $msg
	 */
	static public function isError($msg) {
		if (!is_array($msg)) return false;
		$temp = array_keys($msg);
		return $temp == array('code', 'msg', 'data') ? true : false;
	}

	static public function getSession() {
		return Yaf_Session::getInstance();
	}

	/**
	 *
	 */
	static public function getCache() {
		$config = Common::getConfig('redisConfig', ENV);
		return Cache_Factory::getCache($config);
	}

	/**
	 * queue对象
	 */
	static public function getQueue() {
		$config = Common::getConfig('redisConfig', ENV);
		return Queue_Factory::getQueue($config);
	}

	/**
	 *
	 * @param string $name
	 * @param string $dir
	 * @return string
	 */
	static public function upload($name, $dir, $size = 0) {
		$img        = $_FILES[$name];
		$attachPath = Common::getConfig('siteConfig', 'attachPath');
		if ($img['error']) {
			return Common::formatMsg(-1, '上传图片失败:' . $img['error']);
		}
		$params = array(
			'allowFileType' => array('jpg', 'jpeg', 'png')
		);
		if (!empty($size)) {
			$params['maxSize'] = $size;
		}
		$savePath = sprintf('%s/%s/%s', $attachPath, $dir, date('Ym'));
		if (!file_exists($savePath)) {
			$old = umask(0);
			mkdir($savePath, 0777, true);
			umask($old);
		}
		$uploader = new Util_Upload($params);
		$ret      = $uploader->upload($name, uniqid(), $savePath);
		if ($ret < 0) {
			return Common::formatMsg(-1, '上传失败:' . $ret);
		}
		$url = sprintf('/%s/%s/%s', $dir, date('Ym'), $ret['newName']);
		return Common::formatMsg(0, '', $url);
	}

	/**
	 *
	 * Enter description here ...
	 */
	static public function getTime() {
		return time();
	}

	/**
	 *
	 * @param array $source
	 * @param string $name
	 */
	static public function resetKey($source, $name) {
		if (!is_array($source)) return array();
		$tmp = array();
		foreach ($source as $key => $value) {
			if (isset($value[$name])) $tmp[$value[$name]] = $value;
		}
		return $tmp;
	}

	/**
	 * 点击统计
	 * @param string $mobile
	 * @param string $content
	 */
	static public function tjurl($url, $id, $type, $redirect, $t_bi = '') {
		$redirect = trim($redirect);
		$url      = trim($url);
		//$t        = crc32($redirect . $id . $type . Common::$urlPwd);
		$t    = Gionee_Service_ShortUrl::genTVal($id . $redirect . $type . Common::$urlPwd);
		$key  = 'ToUrl:' . $t;
		$rc   = Common::getCache();
		$info = $rc->get($key);
		if (empty($info)) {
			$info = array('id' => $id, 'type' => $type, '_url' => $redirect);
			$mark = json_encode($info);
			Gionee_Service_ShortUrl::make($t, $redirect, $mark);
			$rc->set($key, $mark);
		}
		$newUrl = sprintf('%s?t=%s&t_bi=%s', $url, $t, $t_bi);
		return $newUrl;
	}

	/**
	 *
	 * @param string $link
	 * @param string $t_bi
	 * @return string
	 */
	static public function BI($link, $t_bi) {
		$link = trim(html_entity_decode($link));
		if (strpos($link, "3g.gionee.com") === true) {
			if (strpos($link, '?') !== false) {
				$link = $link . "&t_bi=" . $t_bi;
			} else {
				$link = $link . "?t_bi=" . $t_bi;
			}
		}
		return $link;
	}

	/**
	 * error log
	 * @param string $error
	 * @param string $file
	 */
	static public function log($error, $file) {
		error_log(date('Y-m-d H:i:s') . ' ' . json_encode($error) . "\n", 3, Common::getConfig('siteConfig', 'logPath') . $file);
	}

	/**
	 * 下载图片
	 * @param unknown_type $imgurl
	 * @param unknown_type $dir
	 * @param unknown_type $withWebp
	 * @return boolean|string
	 */
	static public function downloadImg($imgurl, $dir, $withWebp = true) {
		if (strpos($imgurl, "gionee.com") !== false) return array(false, false);
		if (!file_exists($dir)) mkdir($dir, 0777, true);
		//get remote file info
		$headerInfo = get_headers($imgurl, 1);
		$size       = $headerInfo['Content-Length'];
		if (!$size) return array(false, false);
		$type     = $headerInfo['Content-Type'];
		$ext      = end(explode("/", $type));
		$filename = md5($imgurl) . "." . $ext;

		$localFile = $dir . "/" . $filename;

		//if is exists
		$thumb = $localFile . "_320x240." . $ext;
		if (file_exists($localFile)) return array($filename, $filename . "_320x240." . $ext);

		//download
		ob_start();
		readfile($imgurl);
		$imgData = ob_get_contents();
		ob_end_clean();
		$fd = fopen($localFile, 'a');
		fwrite($fd, $imgData);
		fclose($fd);

		if (!file_exists($localFile)) return array(false, false);

		Util_Image::makeThumb($localFile, $thumb, 320, 240, true);

		if ($withWebp) @image2webp($thumb, $thumb . ".webp");
		return array($filename, $filename . "_320x240." . $ext);
	}


	/**
	 * 域名替换
	 */
	static public function getCurHost() {
		$webroot = Yaf_Application::app()->getConfig()->webroot;
		if (isset($_SERVER['HTTP_HOST'])) {
			$webroot = 'http://' . $_SERVER['HTTP_HOST'];
		}
		return $webroot;
	}

	/**
	 * 获得主域名
	 */
	public static function getMainHost() {
		$webroot = Yaf_Application::app()->getConfig()->webroot;
		if (empty($webroot)) {
			$webroot = 'http://3g.gionee.com';
		}
		return $webroot;
	}

	/**
	 * 检测名字是否非法 最少2个汉字 最多5个
	 *
	 * @author william.hu
	 * @param string $val
	 */
	public static function checkIllName($val) {
		$ret = false;
		$len = mb_strlen($val);
		if ($len <= 50 && $len >= 1) {
			//if (!empty($val) && preg_match('/^[\x{4e00}-\x{9fa5}]{2,5}$/u', $val)) {
			$ret = true;
		}
		return $ret;
	}

	/**
	 * 检测电话是否非法
	 *
	 * @author william.hu
	 * @param string $val
	 */
	public static function checkIllPhone($val, $type = 'phone') {
		$ret     = false;
		$pattern = array(
			'phone' => '/^[1][34578][0-9]{9}$/',
			'tel'   => '/^(010|02\d{1}|0[3-9]\d{2})\d{7,9}$/'
		);
		if (in_array($type, array_keys($pattern))) {
			if (!empty($val) && preg_match($pattern[$type], $val)) {
				$ret = true;
			}
		}
		return $ret;
	}


	public static function getAppc($cn) {
		$appcKey = "APPC:{$cn}";
		return Common::getCache()->get($appcKey);
	}

	public static function setAppc($cn, $data) {
		$appcKey = "APPC:{$cn}";
		return Common::getCache()->set($appcKey, $data, Common::T_ONE_DAY);
	}

	static public function cookData($data, $fileds) {
		$tmp = array();
		foreach ($fileds as $key) {
			if (isset($data[$key])) {
				$tmp[$key] = $data[$key];
			}
		}
		return $tmp;
	}
}