<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_Order extends  Common_Dao_Base {
	protected $_name = 'user_order_info';
	protected $_primary = 'id';
	
	
	public function unHandleOrders($page,$pageSize,$where,$order){
		$where = Db_Adapter_Pdo::sqlWhere($where);
		$orderBy = Db_Adapter_Pdo::sqlSort($order);
		$sql = sprintf("SELECT * FROM %s WHERE id NOT IN  (SELECT id FROM %s where (order_status = -1 AND pay_status = 3) OR (order_status = 2 AND pay_status =1) )  %s LIMIT %s ,  %s",$this->getTableName(),$this->getTableName(),$orderBy,$page,$pageSize);
		return Db_Adapter_Pdo::fetchAll($sql);
	}
	
	public function getUnHandleCount(){
		$sql = sprintf("SELECT count(*) FROM %s WHERE id NOT IN  (SELECT id FROM %s where (order_status = -1 AND pay_status = 3) OR (order_status = 2 AND pay_status =1) ) ",$this->getTableName(),$this->getTableName());
		return  Db_Adapter_Pdo::fetchCloum($sql,0);
	}
}