<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_Gather extends Common_Dao_Base
{
	protected $_name = 'user_gather_info';
	protected $_primary = 'id';
	
	
	public function getSumScoresInfo() {
		$sql = "SELECT SUM(total_score) as total_scores,SUM(remained_score) as total_remained_scores ,COUNT(*) as total_users  from user_gather_info  where total_score >0 ";
		return Db_Adapter_Pdo::fetch($sql);
	}
}