<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class  User_Dao_Rewards extends Common_Dao_Base
{
	protected $_primary = "id";
	protected  $_name = 'user_reward_list';
}