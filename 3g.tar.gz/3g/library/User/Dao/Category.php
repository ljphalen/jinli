<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_Category extends Common_Dao_Base
{
	protected $_name = "user_goods_category";
	protected $_primary = "id";
}