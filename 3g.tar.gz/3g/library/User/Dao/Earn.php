<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_Earn extends Common_Dao_Base
{
	protected  $_name = 'user_earn_score_log';
	protected  $_primary ='id';
	
	
	public function getAllActivateUserIds($params =array()){
		$group = Db_Adapter_Pdo::sqlGroup($params);
		$sql = sprintf("SELECT uid FROM %s %s",$this->getTableName(),$group);
		return Db_Adapter_Pdo::fetchAll($sql);
	}
}