<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_Commodities extends Common_Dao_Base
{
	protected $_name = 'user_goods_cosume';
	protected $_primary = 'id';
}