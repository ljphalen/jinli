<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_OrderGoods extends  Common_Dao_Base
{
		protected $_name = "user_order_goods";
		protected $_primary = "id";
}