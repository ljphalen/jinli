<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Dao_User extends Common_Dao_Base
{
	protected  $_name = "user_info";
	protected  $_primary = "id";
}