<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

//订单管理

class User_Service_Order {

	public static function add($params) {
		if (empty($params)) return false;
		$data = self::_checkData($params);
		$res  = self::_getDao()->insert($data);
		return $res ? self::_getDao()->getLastInsertId() : 0;
	}


	public static function getList($page, $limit, $where = array(), $orderBy = array()) {
		if (!is_array($where)) return flase;
		$start = (max(intval($page), 1) - 1) * $limit;
		return array(self::count($where), self::_getDao()->getList($start, $limit, $where, $orderBy));
	}

	public static function count($params) {
		if (!is_array($params)) return false;
		return self::_getDao()->count($params);
	}

	public static function get($id) {
		if (!is_numeric($id)) return false;
		return self::_getDao()->get($id);
	}

	public static function getBy($params = array()) {
		if (!is_array($params)) return false;
		return self::_getDao()->getBy($params);
	}

	public static function getsBy($params = array(), $order = array()) {
		if (!is_array($params)) return false;
		return self::_getDao()->getsBy($params, $order);
	}

	public static function update($params, $id) {
		$data = self::_checkData($params);
		return self::_getDao()->update($data, $id);
	}

	public static function delete($id) {
		return self::_getDao()->delete($id);
	}

	//生成唯一订单号
	public static function createOrderId($uid) {
		return date('YmdHis', time()) . $uid . mt_rand(10000, 99999);
	}

	/**
	 *    生成订单
	 * @param array $goods 商品的信息
	 * @param array $options 用户兑换商品其它信息
	 * @param int $uid 用户ID
	 * @return boolean
	 */
	public static function generateOrder($uid, $goods, $options) {
		if (!is_array($options) || !is_array($goods) || !$uid) return array('key' => '-1', 'msg' => '参数有错!');
		$temp                      = array();
		$number                    = $options['goods_number'] ? $options['goods_number'] : 1;
		$temp['uid']               = $uid;
		$temp['order_sn']          = self::createOrderId($uid);//生成唯一订单号
		$temp['order_status']      = 0;
		$temp['pay_status']        = 1;
		$temp['shipping_status']   = 0;
		$temp['order_amount']      = $goods['price'] * $number;
		$temp['total_cost_scores'] = $goods['scores'] * $number;
		$temp['pay_time']          = time();
		if ($goods['goods_type'] == 1) { //如果是兑换话费或流量包时
			$temp['recharge_mobile'] = $options['tel'];
			$temp['rec_status']      = 0;
			$temp['ordercrach']      = $options['inprice'];
		}
		$temp['address_id'] = $options['address_id'] ? $options['address_id'] : 0;
		$temp['add_time']   = time();
		$temp['user_ip']    = Util_Http::getClientIp();
		$res                = self::add($temp);
		if ($res) {
			//如果订单成功,则写信息到订单商品表中(当前没有购物车的概念,默认一次提交只是一种商品)
			$params     = array(
				'order_id'         => $res,
				'goods_id'         => $goods['id'],
				'goods_name'       => $goods['name'],
				'goods_type'       => $goods['goods_type'],
				'goods_price'      => $goods['price'],
				'goods_number'     => $number,
				'goods_scores'     => $goods['scores'],
				'is_special'       => $goods['is_special'],
				'real_cost_scores' => $goods['scores'],
			);
			$add        = User_Service_OrderGoods::add($params);
			$updateData = array('number' => ($goods['number'] - $number));
			$reduceNum  = User_Service_Commodities::update($updateData, $goods['id']);//减少库存
			if ($add && $reduceNum) {
				return array('key' => '1', 'msg' => '操作成功', 'data' => array('order_sn' => $temp['order_sn']));
			} else {
				return array('key' => '0', 'msg' => '添加失败');
			}
		} else {
			return array('key' => '0', 'msg' => '添加失败');
		}
	}

	//未处理订单信息
	public static function unHandleOrders($page, $pageSize, $where, $orderBy) {
		if (!is_array($where)) return false;
		$count = self::_getDao()->getUnHandleCount();
		$data  = self::_getDao()->unHandleOrders($page, $pageSize, $where, $orderBy);
		return array($count, $data);
	}

	private static function _checkData($params) {
		$array = array();
		if (isset($params['uid'])) $array['uid'] = $params['uid'];
		if (isset($params['order_sn'])) $array['order_sn'] = $params['order_sn'];
		if (isset($params['order_status'])) $array['order_status'] = $params['order_status'];
		if (isset($params['pay_status'])) $array['pay_status'] = $params['pay_status'];
		if (isset($params['order_sn'])) $array['order_sn'] = $params['order_sn'];
		if (isset($params['shipping_status'])) $array['shipping_status'] = $params['shipping_status'];
		if (isset($params['order_amount'])) $array['order_amount'] = $params['order_amount'];
		if (isset($params['total_cost_scores'])) $array['total_cost_scores'] = $params['total_cost_scores'];
		if (isset($params['address_id'])) $array['address_id'] = $params['address_id'];
		if (isset($params['pay_time'])) $array['pay_time'] = $params['pay_time'];
		if (isset($params['recharge_mobile'])) $array['recharge_mobile'] = $params['recharge_mobile'];
		if (isset($params['add_time'])) $array['add_time'] = $params['add_time'];
		if (isset($params['user_ip'])) $array['user_ip'] = $params['user_ip'];
		if (isset($params['ordercrach'])) $array['ordercrach'] = $params['ordercrach'];
		if (isset($params['rec_status'])) $array['rec_status'] = $params['rec_status'];
		if (isset($params['rec_order_id'])) $array['rec_order_id'] = $params['rec_order_id'];
		if (isset($params['rec_order_time'])) $array['rec_order_time'] = $params['rec_order_time'];
		if (isset($params['desc'])) $array['desc'] = $params['desc'];
		return $array;
	}

	private static function _getDao() {
		return Common::getDao("User_Dao_Order");
	}
}