<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Service_Earn {
	
	public static function getBy($params = array(),$sort=array()){
		if(!is_array($params)) return false;
		return self::_getDao()->getBy($params,$sort);
	}
	
	public static function add($params = array()){
		if(!is_array($params)) return false;
		return self::_getDao()->insert($params);
	}
	public static function count($params = array()){
		if(!is_array($params)) return false;
		return self::_getDao()->count($params);
	}
	
	/**
	 *得到当天获到积分的商品所有ID
	 * @param unknown $params
	 */
	public static function getDayEarnedGoodsIds($params = array()){
		if(!is_array($params)) return false;
		$dataList =  self::_getDao()->getsBy($params);
		$ids = array();
		foreach ($dataList as $k=>$v){
			$ids[$k] = $v['goods_id']; 
		}
		return $ids;
	}
	
	//得到所有获取过积分的用户ID
	public static function getAllActivateUserIds($params = array()){
		return self::_getDao()->getAllActivateUserIds($params);
	}
	private static function _getDao(){
		return Common::getDao("User_Dao_Earn");
	}
}