<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

//用户积分表相关
class User_Service_ScoreLog  {
	
	public static function add($keys = array(),$params= array()){
		if(!is_array($params)) return false;
		return self::_getDao()->batchInsert($keys,$params);
	}
	
	public static function get($id){
		return self::_getDao()->get($id);
	}
	
	public static function getsBy($params){
		if(!is_array($params)) return false;
		return self::_getDao()->getsBy($params);
	}
	
	public static function getList($page=1,$pageSize=20,$where=array(),$orderBy=array()){
		$page = max($page,1);
		$count = self::count($where);
		return array(self::count($where),self::_getDao()->getList($pageSize *($page-1),$pageSize,$where,$orderBy));
	}
	
	public static function count($params){
		return self::_getDao()->count($params);
	}
	
	
	public static function getDayEarnScoresInfo($page,$pageSize,$params,$groupBy,$orderBy){
		$page = $pageSize *($page -1);
		$data = self::_getDao()->getDayEarnScoresInfo($page, $pageSize, $params, $groupBy, $orderBy);
		$count  = self::_getDao()->getCountByParams($params,$groupBy);
		return array(count($count),$data);
	}
	//获得当天用户所得到的积分数
	public static function getDayIncreScores($params){
		if(!is_array($params)) return false;
		return self::_getDao()->getDayIncreScores($params);
	}
	
	//检测用户当天完成任务情况
	public static function checkTasks($params,$groupBy){
		if(!is_array($params)) return false;
		return self::_getDao()->checkTasks($params,$groupBy);
	}
	
	public static function getDoneTasksList($page,$pageSize,$where=array(),$group=array(),$order=array()){
		if(!is_array($where)) return false;
		$total = self::_getDao()->getCountByParams($where,$group);
		$data = self::_getDao()->getDoneTasksList($pageSize *($page-1),$pageSize,$where,$group,$order);
		return array(count($total),$data);
	}
	
	public static function getTotalDoneTasksInfo($where=array()){
		if(!is_array($where)) return false;
		return self::_getDao()->getTotalDoneTasksInfo($where);
	}
	private  static function _getDao(){
		return Common::getDao("User_Dao_Scorelog");
	}
}