<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Service_User
{
	public  static function add($params){
		
	}
	
	public  static  function get($id)
	{
		return self::_getDao()->get($id);
	}

	public static function update($id,$params){
		if(!is_array($params) ||! is_numeric($id)) return false;
		return self::_getDao()->update($params,$id);
	}
	private static function _getDao()
	{
		return Common::getDao('User_Dao_User');
	}
}