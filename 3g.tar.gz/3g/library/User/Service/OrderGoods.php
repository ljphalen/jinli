<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class User_Service_OrderGoods {
	
	public static function add($params){
		if(!is_array($params)) return false;
		return self::_getDao()->insert($params);
	}
	
	public static function getsBy($params =array(),$order = array()){
		if(!is_array($params)) return false;
		return self::_getDao()->getsBy($params,$order);
	}
	private static function _getDao(){
		return Common::getDao("User_Dao_OrderGoods");
	}
}