<?php
if (!defined('BASE_PATH')) exit('Access Denied!');
//用户积分表

class User_Service_Gather {
	
	//添加信息
	public static  function add($params){
		 if(!is_array($params)) return false;
		 return self::_getDao()->insert($params);
	}
	
	public  static function get($id){
		if(!is_numeric($id)) return false;
		return  self::_getDao()->get($id);
	}
	
	public static function getBy($params = array()){
		if(!is_array($params)) return false;
		return self::_getDao()->getBy($params);
	}
	
	public static function update($params=array(),$id){
		if(!is_array($params)) return false;
		return self::_getDao()->update($params,$id);
	}
	
	public static function updateBy($params=array(),$where=array()){
		if(!is_array($params)) return false;
		return self::_getDao()->updateBy($params,$where);
	}
	
	
	public static function getSumScoresInfo(){
		return self::_getDao()->getSumScoresInfo();
	}
	
	/**
	 * 
	 * @param array $goods  商品的信息
	 * @param int  $uid 	用户ID
	 * @param int $goods_number 兑换商品的个数
	 * 冻结积分并写日志
	 */
	public static function frozenUserScores($goods,$uid ,$goods_number = 1){
		$totalCost =$goods['scores']*$goods_number; //总共消费的积分
		$scoreMsg = User_Service_Gather::getBy(array('uid'=>$uid));
		if($scoreMsg['remained_score'] - $totalCost <0){
				return array('key'=>'0','msg'=> "对不起,您的积分不足已兑换该商品!");
		}
		//更新积分表
		$initScores = $scoreMsg['remained_score']; //初始积分数
		$scoreMsg['remained_score'] -= $totalCost;
		$scoreMsg['affected_score'] = $totalCost;
		$scoreMsg['frozed_score'] += $totalCost;
		$ret = User_Service_Gather::update($scoreMsg,$scoreMsg['id']);
		$category = User_Service_Category::get($goods['cat_id']);
		$datas[] = array(
				'uid'=>$uid,
				'group_id'=>3,
				'before_score'=>$initScores,
				'after_score'=>$scoreMsg['remained_score'],
				'affected_score'=> - $totalCost,
				'score_type'=>$category['score_type'],//默认为兑换话费
				'add_time'=>time(),
				'date' =>date('Ymd',time()),
		);
		$add = Common_Service_User::score($datas);
		return $ret && $add;
	}
	
	
	private static function _getDao(){
		return Common::getDao("User_Dao_Gather");
	}
	
}