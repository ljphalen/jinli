<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Cache_Picture
 * @author tiansh
 *
 */
class Gionee_Cache_Picture extends Cache_Base {
}
