<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Cache_Resource
 * @author tiansh
 *
 */
class Gionee_Cache_Resource extends Cache_Base {

}
