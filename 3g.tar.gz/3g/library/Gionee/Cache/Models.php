<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Cache_Models
 * @author tiansh
 *
 */
class Gionee_Cache_Models extends Cache_Base {

}
