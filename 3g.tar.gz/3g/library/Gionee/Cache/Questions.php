<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Cache_Questions
 * @author tiansh
 *
 */
class Gionee_Cache_Questions extends Cache_Base {

}
