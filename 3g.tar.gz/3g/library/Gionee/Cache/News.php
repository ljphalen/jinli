<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Cache_News
 * @author tiansh
 *
 */
class Gionee_Cache_News extends Cache_Base {

	public $expire = 60;

}
