<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * Gionee_Cache_Jhnews
 * @author rainkid
 *
 */
class Gionee_Cache_Jhnews extends Cache_Base {
}
