<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * Gionee_Dao_Page
 * @author tiger
 *
 */
class Gionee_Dao_Page extends Common_Dao_Base {
	protected $_name = '3g_page';
	protected $_primary = 'id';

}