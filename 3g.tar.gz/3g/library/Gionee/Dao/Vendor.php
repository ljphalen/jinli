<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_Vendor
 * @author tiger
 *
 */
class Gionee_Dao_Vendor extends Common_Dao_Base {
	protected $_name = '3g_vendor';
	protected $_primary = 'id';

}