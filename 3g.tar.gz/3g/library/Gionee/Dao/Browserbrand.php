<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_Browserbrand
 */
class Gionee_Dao_Browserbrand extends Common_Dao_Base {
	protected $_name = '3g_browser_brand';
	protected $_primary = 'id';

}