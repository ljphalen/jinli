<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_Column
 * @author rainkid
 *
 */
class Gionee_Dao_Column extends Common_Dao_Base {
	protected $_name = '3g_browser_column';
	protected $_primary = 'id';
}