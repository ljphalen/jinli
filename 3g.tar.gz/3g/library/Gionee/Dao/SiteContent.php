<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *网址大全 内容页
*/
class Gionee_Dao_SiteContent extends Common_Dao_Base{
	protected $_name = '3g_site_content';
	protected $_primary = 'id';
	
	

}