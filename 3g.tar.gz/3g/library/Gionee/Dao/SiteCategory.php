<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * 网址大全分类
 */

class Gionee_Dao_SiteCategory extends Common_Dao_Base{
	
		protected $_name = '3g_site_category';
		protected $_primary = 'id';
	
}