<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class Gionee_Dao_OnlineLog extends Common_Dao_Base {
	
	protected $_name = '3g_online_log';
	protected $_primary = 'id';
}