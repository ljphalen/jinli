<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_RecsiteType
 * @author tiger
 *
 */
class Gionee_Dao_WebThemeType extends Common_Dao_Base {
	protected $_name = '3g_web_themetype';
	protected $_primary = 'id';

}