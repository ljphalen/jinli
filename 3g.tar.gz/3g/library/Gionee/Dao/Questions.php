<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * @author rainkid
 *
 */
class Gionee_Dao_Questions extends Common_Dao_Base {
	protected $_name = '3g_questions';
	protected $_primary = 'id';
}
