<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_Browserserie
 */
class Gionee_Dao_Browserseries extends Common_Dao_Base {
	protected $_name = '3g_browser_series';
	protected $_primary = 'id';

}