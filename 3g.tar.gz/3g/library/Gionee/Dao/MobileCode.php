<?php

if (!defined('BASE_PATH')) exit('Access Denied!');
 //查询手机归属地
class Gionee_Dao_MobileCode extends Common_Dao_Base {
	
	protected $_name = '3g_mobile_code';
	protected $_primary = 'id'; 
}