<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * @author rainkid
 *
 */
class Gionee_Dao_UserSignin extends Common_Dao_Base {
	protected $_name = '3g_user_signin';
	protected $_primary = 'id';


	/**
	 *
	 * 获取列表数据
	 * @param array $params
	 * @param int $page
	 * @param int $limit
	 */
	public function getList($start = 0, $limit = 20, $params) {
		$where = $this->_cookSearch($params);
		$sql   = sprintf('SELECT * FROM %s WHERE %s ORDER BY id DESC LIMIT %d,%d', $this->getTableName(), $where, intval($start), intval($limit));
		return Db_Adapter_Pdo::fetchAll($sql);
	}

	/**
	 *
	 * 获取单条数据
	 * @param int $value
	 */
	public function getLastByUserId($user_id) {
		$sql = sprintf('SELECT * FROM %s WHERE user_id = %s ORDER BY id DESC LIMIT 0 , 1', $this->getTableName(), Db_Adapter_Pdo::quote($user_id));
		return Db_Adapter_Pdo::fetch($sql);
	}

	/**
	 *
	 * @param unknown_type $params
	 * @return Ambigous <number, string>
	 */
	private function _cookSearch($params) {
		$where = 1;
		if ($params['img_id']) $where .= ' AND img_id = ' . Db_Adapter_Pdo::quote($params['img_id']);
		if ($params['prize_id']) $where .= ' AND prize_id = ' . Db_Adapter_Pdo::quote($params['prize_id']);
		if ($params['user_id']) $where .= ' AND user_id = ' . Db_Adapter_Pdo::quote($params['user_id']);
		return $where;
	}
}