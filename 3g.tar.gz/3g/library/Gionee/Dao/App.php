<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Browser_Dao_RecMark
 * @author tiansh
 *
 */
class Gionee_Dao_App extends Common_Dao_Base {
	protected $_name = '3g_app';
	protected $_primary = 'id';

}