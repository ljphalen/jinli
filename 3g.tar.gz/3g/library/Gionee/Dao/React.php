<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_React
 * @author lichanghua
 *
 */
class Gionee_Dao_React extends Common_Dao_Base {
	protected $_name = '3g_react';
	protected $_primary = 'id';
}
