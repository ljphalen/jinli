<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_Browsermodel
 */
class Gionee_Dao_Browsermodel extends Common_Dao_Base {
	protected $_name = '3g_browser_model';
	protected $_primary = 'id';

}