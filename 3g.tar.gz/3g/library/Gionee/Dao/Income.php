<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class Gionee_Dao_Income extends Common_Dao_Base {
	
		protected  $_name = "3g_income_log";
		protected  $_primary = "id";
}