<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * @author rainkid
 *
 */
class Gionee_Dao_Blackurl extends Common_Dao_Base {
	protected $_name = '3g_blackurl';
	protected $_primary = 'id';

}