<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_Welcome
 * @author tiger
 *
 */
class Gionee_Dao_Welcome extends Common_Dao_Base {
	protected $_name = '3g_welcome';
	protected $_primary = 'id';

}