<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * @author huwei
 *
 */
class Gionee_Dao_RecWebsite extends Common_Dao_Base {
	protected $_name = '3g_rec_website';
	protected $_primary = 'id';

}
