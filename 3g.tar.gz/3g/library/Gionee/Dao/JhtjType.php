<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * @author rainkid
 *
 */
class Gionee_Dao_JhtjType extends Common_Dao_Base {
	protected $_name = '3g_jhtj_type';
	protected $_primary = 'id';

	/**
	 *
	 * 二级分类
	 */
	public function getParentList() {
		$sql = sprintf('SELECT * FROM %s WHERE root_id != 0 AND parent_id != 0 and root_id = parent_id ORDER BY sort DESC, id DESC', $this->_name);
		return Db_Adapter_Pdo::fetchAll($sql);
	}

	/**
	 *
	 * @param getAllChild
	 * @return multitype:
	 */
	public function getAllChild() {
		$sql = sprintf('SELECT * FROM %s WHERE root_id != 0 AND parent_id != 0 and parent_id != root_id  ORDER BY sort DESC, id DESC', $this->_name);
		return Db_Adapter_Pdo::fetchAll($sql);
	}

	/**
	 *
	 * @param getAllChild
	 * @return multitype:
	 */
	public function getTjName() {
		$sql = sprintf('SELECT * FROM %s ORDER BY sort DESC, id DESC', $this->_name);
		return Db_Adapter_Pdo::fetchAll($sql);
	}
}