<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 * Browser_Dao_RecMark
 * @author tiger
 */
class Gionee_Dao_Bookmark extends Common_Dao_Base {
	protected $_name = '3g_bookmark';
	protected $_primary = 'id';

}