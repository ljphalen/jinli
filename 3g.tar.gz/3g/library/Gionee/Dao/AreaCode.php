<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Gionee_Dao_AreaCode
 * @author rainkid
 *
*/
class Gionee_Dao_AreaCode extends Common_Dao_Base {
	protected $_name = '3g_area_code';
	protected $_primary = 'id';
} 