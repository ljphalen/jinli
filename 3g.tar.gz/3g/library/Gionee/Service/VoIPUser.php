<?php

if (!defined('BASE_PATH')) exit('Access Denied!');

class  Gionee_Service_VoIPUser {

	//获得某一期内总共领取的用户数
	public static function getCount($params) {
		if (!is_array($params)) return false;
		return self::_getDao()->count($params);
	}

	//检测用户是否已领取
	public static function isObtained($params) {
		if (!is_array($params)) return false;
		return self::_getDao()->getBy($params);
	}

	//成功抢到资格
	public static function add($params) {
		return self::_getDao()->insert($params);
	}

	public static function getBy($params, $order = array()) {
		if (!is_array($params)) return false;
		return self::_getDao()->getBy($params, $order);
	}

	//
	public static function getDataList($page, $pageSize, $where, $orderBy) {
		if ($page < 1) {
			$page = 1;
		}
		$conf  = Gionee_Service_Config::getValue('voip_config');
		$cfg   = json_decode($conf, true);
		$total = self::_getDao()->count($where);
		$data  = self::_getDao()->getList(($page - 1) * $pageSize, $pageSize, $where, $orderBy);
		foreach ($data as $key => $val) {
			$callTime                = Gionee_Service_VoIPLog::getTotalTimeByMonth($val['user_phone']);
			$diff                    = max($cfg['month_call_time'] - $callTime, 0);
			$data[$key]['left_time'] = $diff;
			$data[$key]['total_time'] = Gionee_Service_VoIPLog::getTotalTimeByMonth($val['user_phone'],-1);
		}
		return array($total, $data);
	}

	//统计
	public static function getCountByDate($page, $pageSize, $params = array(), $groupBy = array(), $orderBy = array()) {
		if (!is_array($params) || !is_array($groupBy)) return false;
		$total = self::getTotalActivitedNumber($params, $groupBy);
		$data  = self::_getDao()->getCountByDate($page, $pageSize, $params, $groupBy, $orderBy);
		return array(count($total), $data);
	}

	//
	public static function getTotalActivitedNumber($parms = array(), $group = array()) {
		if (!is_array($parms) || !is_array($group)) return false;
		$data = self::_getDao()->getTotalActivatedNumber($parms, $group);
		return $data;
	}

	private function _checkData($parms) {
		$temp = array();
		if (isset($parms['uid'])) $temp['uid'] = $parms['uid'];
		if (isset($parms['pid'])) $temp['pid'] = $parms['pid'];
		if (isset($parms['get_time'])) $temp['get_time'] = $parms['get_time'];
		return $temp;
	}

	private function _getDao() {
		return Common::getDao('Gionee_Dao_VoIPUser');
	}
}