<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Enter description here ...
 * @author rainkid
 *
 */
class Gionee_Service_User {
	static private $hash = 'gixsza'; //hash值
	static private $cookieTime = 2592000; //默认设置为30天
	static private $cookieName = 'GioneeUser';
	static private $cookieSidName = 'GioneeUserSid';

	/**
	 *
	 * 获取所有用户
	 */
	public static function getAllUser() {
		return self::_getDao()->getAllUser();
	}

	/**
	 *
	 * 分页取用户列表
	 * @param array $params
	 * @param int $page
	 * @param int $limit
	 */
	public static function getList($page = 1, $limit = 10, $params = array(),$order =array()) {
		$params = self::_cookData($params);
		if ($page < 1) $page = 1;
		$start = ($page - 1) * $limit;
		$ret   = self::_getDao()->getList($start, $limit, $params,$order);
		$total = self::_getDao()->count($params);
		return array($total, $ret);
	}

	/**
	 *
	 * Enter description here ...
	 * @param array $params
	 * @param int $page
	 * @param int $limit
	 */
	public static function search($page = 1, $limit = 10, $params = array()) {
		$params = self::_cookData($params);
		if ($page < 1) $page = 1;
		$start    = ($page - 1) * $limit;
		$sqlWhere = self::_getDao()->_cookParams($params);
		$ret      = self::_getDao()->searchBy($start, $limit, $sqlWhere, array('id' => 'DESC'));
		$total    = self::_getDao()->searchCount($sqlWhere);
		return array($total, $ret);
	}


	/**
	 *
	 * 分页取用户列表
	 * @param array $params
	 * @param int $page
	 * @param int $limit
	 */
	public static function getListByTime($page = 1, $limit = 10) {
		if ($page < 1) $page = 1;
		$start = ($page - 1) * $limit;
		$ret   = self::_getDao()->getListByTime($start, $limit);
		$total = self::_getDao()->countByTime();
		return array($total, $ret);
	}

	/**
	 *
	 * get by uids
	 * @param array $uids
	 */
	public static function getListByUids($uids) {
		if (!count($uids)) return false;
		return self::_getDao()->getListByUids($uids);
	}

	/**
	 *
	 * @param string $out_uid
	 * @return array
	 */
	public static function getByOutUid($out_uid) {
		if (!$out_uid) return false;
		return self::_getDao()->getBy(array('out_uid' => $out_uid));
	}

	/**
	 *
	 * 读取一条用户信息
	 * @param int $id
	 */
	public static function getUser($id) {
		if (!intval($id)) return false;
		return self::_getDao()->get(intval($id));
	}

	/**
	 *
	 * 根据用户名查用户信息
	 * @param srting username
	 */
	public static function getUserByName($username) {
		if (!$username) return false;
		return self::_getDao()->getByUserName($username);
	}

	/**
	 *
	 * 根据手机查用户信息
	 * @param string $mobile
	 */
	public static function getUserByMobile($mobile) {
		if (!$mobile) return false;
		return self::_getDao()->getByEmail($mobile);
	}

	/**
	 *
	 * @param array $uids
	 * @return boolean
	 */
	public static function getUserByUids($uids) {
		if (!count($uids)) return false;
		return self::_getDao()->getUserByUids($uids);
	}

	/**
	 * update user want_num
	 */
	public function signin($uid) {
		return self::_getDao()->increment('signin_num', array('id' => $uid));
	}

	/**
	 * get user info by out_uid
	 * @param string $out_uid
	 * @return boolean|mixed
	 */
	public static function getUserBy($params) {
		if (!is_array($params)) return false;
		$data = self::_cookData($params);
		return self::_getDao()->getBy($data);
	}

	/**
	 *
	 * 更新用户信息
	 * @param array $data
	 * @param int $id
	 */
	public static function updateUser($data, $id) {
		if (!is_array($data)) return false;
		$data = self::_cookData($data);
		return self::_getDao()->update($data, intval($id));
	}


	/**
	 * 批量修改免单数
	 */
	public static function updateFreeNumberByIds($ids) {
		if (!is_array($ids)) return false;
		return self::_getDao()->updateFreeNumberByIds($ids);
	}

	/**
	 *
	 * del user
	 * @param int $id
	 */
	public static function deleteUser($id) {
		return self::_getDao()->delete(intval($id));
	}

	/**
	 *
	 * 会员总数
	 */
	public static function getCount() {
		return self::_getDao()->getCount();
	}

	/**
	 *
	 * 签到总数
	 */
	public static function getSignCount() {
		return self::_getDao()->getSignCount();
	}

	/**
	 *
	 * 添加用户并获得该用户ID
	 * @param array $data
	 */
	public static function addUser($data) {
		if (!is_array($data)) return false;
		$data['register_time']   = Common::getTime();
		$data['last_login_time'] = Common::getTime();
		$data['status']          = 1;
		$data                    = self::_cookData($data);
		$res                     = self::_getDao()->insert($data);
		return $res ? self::_getDao()->getLastInsertId() : false;
	}

	/**
	 *
	 * cookpasswd
	 * @param string $password
	 */
	static private function _cookPasswd($password) {
		$hash   = Common::randStr(6);
		$passwd = self::_password($password, $hash);
		return array($hash, $passwd);
	}

	/**
	 *
	 * login
	 * @param string $username
	 * @param string $passwd
	 */
	public static function login($out_uid, $password) {
		$result = self::checkUser($out_uid, $password);
		if (!$result || Common::isError($result)) return $result;
		return self::cookieUser($result);
	}

	/**
	 *
	 * logout
	 */
	public static function logout() {
		return Util_Cookie::delete(self::$cookieName, '/', self::getDomain());
	}

	public static function checkLogin($callback_url) {
		$user = Gionee_Service_User::isLogin();
		if (!$user) {
			$webroot  = Common::getCurHost();
			$callback = $webroot . '/user/login/login';
			$url      = Api_Gionee_Oauth::requestToken($callback);
			Util_Cookie::set('GIONEE_LOGIN_REFER', $callback_url, true, Common::getTime() + (5 * 3600), '/');
			header('Location: ' . $url);
			exit;
		}
		return $user;
	}

	/**
	 *
	 * islogin
	 */
	public static function isLogin() {
		$cookie = Util_Cookie::get(self::$cookieName, true);
		if (!$cookie) return false;

		$cookie = self::_cookieEncrypt($cookie, 'DECODE');
		if (!$cookie[1] || !$cookie[3]) return false;
		$userInfo = self::getUserBy(array('out_uid' => $cookie['3'], 'id' => $cookie['2']));
		if (!$userInfo) return false;
		self::cookieUser($userInfo);
		return $userInfo;
	}

	/**
	 * cookie字符串加密解密方式
	 * @param string $str 加密方式
	 * @param string $encode ENCODE-加密|DECODE-解密
	 * @return array
	 */
	static private function _cookieEncrypt($str, $encode = 'ENCODE') {
		if ($encode == 'ENCODE') return Common::encrypt($str);
		$result = Common::encrypt($str, 'DECODE');
		return explode('\t', $result);
	}

	/**
	 *
	 * @return boolean
	 */
	public static function getToday() {
		$is_3g_user = Util_Cookie::get('IS3GUSER', true);
		if ($is_3g_user) return false;
		return Util_Cookie::set('IS3GUSER', 1, true, strtotime(date('Y-m-d 23:59:59')), '/', self::getDomain());
	}

	/**
	 * 根据类型检测Cookie是否存在
	 * @param string $type
	 */
	public static function isCookieSet($type) {
		$type      = !empty($type) ? '3G_' . strtoupper($type) : 'IS3GUSER';
		$getCookie = Util_Cookie::get($type, true);
		if ($getCookie) {
			return false;
		}
		return Util_Cookie::set($type, uniqid($type), true, strtotime(date('Y-m-d 23:59:59')), '/', self::getDomain());

	}


	/**
	 * cookie添加
	 * @param string $userInfo 用户信息
	 * @return array
	 */
	public static function cookieUser($userInfo) {
		$str = Common::getTime() . '\t';
		$str .= $userInfo['username'] . '\t';
		$str .= $userInfo['id'] . '\t';
		$str .= $userInfo['out_uid'] . '\t';

		$cookieStr = self::_cookieEncrypt($str);
		Util_Cookie::set(self::$cookieName, $cookieStr, true, Common::getTime() + self::$cookieTime, '/', self::getDomain());
		//更新最后登录时间
		//return self::updateUser(array('last_login_time' => Common::getTime()), $userInfo['id']);
		return true;
	}

	/**
	 * cookie user sid
	 * @param array $token
	 */
	public static function cookieUserSid($token, $time) {
		Util_Cookie::set(self::$cookieSidName, $token, true, $time, '/');
	}

	/**
	 *
	 * @return Admin_Dao_User
	 */
	private static function getDomain() {
		$domain = str_replace('http://', '', Common::getCurHost());
		if ($number = strrpos($domain, ':')) {
			$domain = Util_String::substr($domain, 0, $number);
		}
		return $domain;
	}


	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $username
	 * @param unknown_type $password
	 */
	public static function checkUser($out_uid, $password) {
		if (!$out_uid) return false;
		$userInfo = self::getByOutUid($out_uid);
		if (!$userInfo) return Common::formatMsg(-1, '用户不存在.');
		//更新最后登录时间
		self::updateUser(array('last_login_time' => Common::getTime()), $userInfo['id']);
		return $userInfo;
	}

	/**
	 *
	 */
	public static function ckLogin() {
		$cookie = Util_Cookie::get(self::$cookieName, true);

		if (!$cookie) return false;
		$userInfo = self::_cookieEncrypt($cookie, 'DECODE');
		if (!$userInfo) {
			$userInfo = self::getUserBy(array('out_uid' => $cookie['3'], 'id' => $cookie['2']));
		}
		return $userInfo;
	}

	
	/**
	 * 每天新增注册用户数
	 */
	public static function countByDays($page,$pageSize,$where=array()){
		if(!is_array($where)) return false;
		$sumInfo = self::_getDao()->countBy($where);
		$dataList = self::_getDao()->countByDays(($page-1) * $pageSize,$pageSize,$where);
		return array($sumInfo,$dataList);
	}
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $password
	 * @param unknown_type $hash
	 */
	private static function _password($password, $hash) {
		return md5(md5($password) . $hash);
	}


	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $data
	 */
	private static function _cookData($data) {
		$tmp = array();
		if (isset($data['id'])) $tmp['id'] = $data['id'];
		if (isset($data['username'])) $tmp['username'] = $data['username'];
		if (isset($data['out_uid'])) $tmp['out_uid'] = $data['out_uid'];
		if (isset($data['mobile'])) $tmp['mobile'] = $data['mobile'];
		if (isset($data['password'])) {
			list($tmp['hash'], $tmp['password']) = self::_cookPasswd($data['password']);
		}
		if (isset($data['register_time'])) $tmp['register_time'] = $data['register_time'];
		if (isset($data['nickname'])) $tmp['nickname'] = $data['nickname'];
		if (isset($data['sex'])) $tmp['sex'] = $data['sex'];
		if (isset($data['birthday'])) $tmp['birthday'] = $data['birthday'];
		if (isset($data['status'])) $tmp['status'] = $data['status'];
		if (isset($data['last_login_time'])) $tmp['last_login_time'] = $data['last_login_time'];
		if (isset($data['qq'])) $tmp['qq'] = $data['qq'];
		if (isset($data['signin_num'])) $tmp['signin_num'] = $data['signin_num'];
		if (isset($data['email'])) $tmp['email'] = $data['email'];
		if (isset($data['model'])) $tmp['model'] = intval($data['model']);

		if (isset($data['user_level'])) $tmp['user_level'] = $data['user_level'];
		if (isset($data['user_group'])) $tmp['user_group'] = $data['user_group'];
		if (isset($data['province_id'])) $tmp['province_id'] = $data['province_id'];
		if (isset($data['city_id'])) $tmp['city_id'] = $data['city_id'];
		if (isset($data['address'])) $tmp['address'] = $data['address'];

		if (isset($data['register_date'])) $tmp['register_date'] = $data['register_date'];
		if (isset($data['come_from'])) $tmp['come_from'] = $data['come_from'];
		return $tmp;
	}

	/**
	 *
	 * @return Admin_Dao_User
	 */
	private static function _getDao() {
		return Common::getDao("Gionee_Dao_User");
	}
}
