<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 */
class Gionee_Service_Log {

	const TYPE_SOHU = 'sohu';
	const TYPE_PV = 'pv';
	const TYPE_UV = 'uv';
	const TYPE_URL = 'url';
	const TYPE_URL_UV = 'url_uv';
	const TYPE_NAV = 'nav';
	const TYPE_NG_INDEX = 'ng_index';
	const TYPE_NG_LIST = 'ng_list';
	const TYPE_BAIDU_HOT = 'baidu_hot';
	const TYPE_TOPIC = 'topic';
	const TYPE_TOPIC_LIST = 'topic_list';
	const TYPE_TOPIC_MAIN = 'topic_main';
	const TYPE_TOPIC_CONTENT = 'topic_content';
	const TYPE_CONTENT_UV = 'content_uv';
	const TYPE_NEWS_CONTENT_UV = 'news_content_uv';
	const TYPE_WORLD_CUP = 'world_cup';
	const TYPE_NEWS_UV = 'news_uv';
	const TYPE_SITE_INDEX='sitemap';

	static $types = array(
		self::TYPE_PV,
		self::TYPE_UV,
		self::TYPE_SOHU,
		self::TYPE_URL,
		self::TYPE_URL_UV,
		self::TYPE_NAV,
		self::TYPE_NG_INDEX,
		self::TYPE_NG_LIST,
		self::TYPE_BAIDU_HOT,
		self::TYPE_TOPIC,
		self::TYPE_TOPIC_LIST,
		self::TYPE_TOPIC_MAIN,
		self::TYPE_TOPIC_CONTENT,
		self::TYPE_CONTENT_UV,
		self::TYPE_NEWS_CONTENT_UV,
		self::TYPE_WORLD_CUP,
		self::TYPE_NEWS_UV,
		self::TYPE_SITE_INDEX,
	);

	static $pvKeys = array(
		'3g_recweb_url'  => '推荐网址',
		'3g_recweb_site' => '推荐站点',
		'3g_nav'         => '导航',
		'3g_news'        => '新闻',
		'3g_vendor'      => '合作商',
		'3g_index'       => '首页',
		'voip_uv_list'   => 'voip拨打页',
		'voip_uv_call'   => 'voip拨号',
		'voip_uv'        => 'voip规则页',
		'user_index'	=>'用户中心首面',
		'user_produces'=>'产生积分列表',
		'user_cosume_list'=>'兑换列表页',
		'user_cosume_detail'=>'兑换详情页',
		'user_cosume_success'=>'兑换成功页',
		'user_center_index'=>"信息设置页",
		'user_innermsg'	=>'站内信页',
		'user_scorelog'		=>'积分日志页',
		'sites_map'				=>'网址大全',
	);

	static $uvKeys = array(
		'3g_nav'       => '导航',
		'3g_news'      => '新闻',
		'3g_vendor'    => '合作商',
		'3g_ad'        => 'ad_api',
		'voip_uv_list' => 'voip拨打页',
		'voip_uv_call' => 'voip拨号',
		'voip_uv'      => 'voip规则页',
		'user_index'	=>'用户中心首面',
		'user_produces'=>'产生积分列表',
		'user_cosume_list'=>'兑换列表页',
		'user_cosume_detail'=>'兑换详情页',
		'user_cosume_success'=>'兑换成功页',
		'user_center_index'=>"信息设置页",
		'user_innermsg'	=>'站内信页',
		'user_scorelog'		=>'积分日志页',
		'sites_map'				=>'网址大全',
	);

	public static function incrBy($type, $key, $num = 1) {
		$nowDay = date('Ymd');
		Common::getCache()->hIncrBy($type . '_' . $nowDay, $key, $num);
	}

	public static function sync2DB($type) {
		$nowDay = date('Ymd', time() - 3600); //目的 在切换日期的时候不会漏掉数据
		$key    = $type . '_' . $nowDay;
		$list   = Common::getCache()->hGetAll($key);
		Common::getCache()->delete($key);
		foreach ($list as $key => $num) {
			$tmpKey = explode(':', $key);
			$params = array(
				'date' => $nowDay,
				'type' => $type,
				'key'  => isset($tmpKey[0]) ? $tmpKey[0] : '',
			);
			if (!empty($tmpKey[1])) { //渠道号
				$params['ver'] = $tmpKey[1];
			}

			$row = Gionee_Service_Log::getBy($params);

			if (!empty($row['id'])) {
				$params['val'] = $row['val'] + $num;
				Gionee_Service_Log::set($params, $row['id']);
			} else {
				$params['val'] = $num;
				Gionee_Service_Log::add($params);
			}
		}
	}

	public static function getBy($param) {
		if (!is_array($param)) return false;
		return self::_getDao()->getBy($param);
	}

	/**
	 *
	 * @return Gionee_Dao_Log
	 */
	private static function _getDao() {
		return Common::getDao("Gionee_Dao_Log");
	}

	public static function getLastIdByType($type, $limit) {
		$ret  = array();
		$list = self::_getDao()->getLastIdByType($type, $limit);
		foreach ($list as $v) {
			$ret[] = $v['key'];
		}
		return $ret;
	}

	/**
	 * @param string $type
	 * @param array $keys
	 * @param string $sDate
	 * @param string $eDate
	 * @return array
	 */
	public static function getUrlList($keys, $sDate, $eDate, $type = Gionee_Service_Log::TYPE_URL) {
		$params  = array(
			'type' => $type,
			'key'  => array('IN', $keys),
			'date' => array(array('>=', $sDate), array('<=', $eDate))
		);
		$orderBy = array('val' => 'DESC');
		$list    = self::_getDao()->getsBy($params, $orderBy);
		$pvData  = array();
		foreach ($keys as $k) {
			$pvData[$k][$sDate] = 0;
		}

		foreach ($list as $v) {
			$k              = $v['key'];
			$d              = date('Y-m-d', strtotime($v['date']));
			$num            = $v['val'];
			$pvData[$k][$d] = $num;
		}
		return $pvData;
	}

	/**
	 * @param string $type
	 * @param array $keys
	 * @param string $sDate
	 * @param string $eDate
	 * @return array
	 */
	public static function getStatData($type, $keys, $sDate, $eDate) {
		if (empty($type) || empty($keys)) {
			return false;
		}
		$params = array(
			'type' => $type,
			'key'  => array('IN', array_keys($keys)),
			'date' => array(array('>=', $sDate), array('<=', $eDate))
		);
		$list   = self::_getDao()->getsBy($params);
		$pvData = array();
		foreach ($list as $v) {
			$d              = date('Y-m-d', strtotime($v['date']));
			$num            = $v['val'];
			$k              = $keys[$v['key']];
			$pvData[$k][$d] = $num;
		}

		return $pvData;
	}

	public static function getNgColumnData($columnId, $sDate, $eDate, $type = self::TYPE_NAV, $other = array()) {
		if (!$columnId) {
			return array();
		}
		$columList = Gionee_Service_Ng::getsBy(array('column_id' => $columnId), array('sort' => 'ASC', 'id' => 'ASC'));
		$keys      = array(0);
		foreach ($columList as $k => $v) {
			$keys[] = $v['id'];
		}

		$params = array(
			'type' => $type,
			'key'  => array('IN', $keys),
			'date' => array(array('>=', $sDate), array('<=', $eDate)),
		);
		if (isset($other['ver'])) {
			$params['ver'] = $other['ver'];
		}
		$list = self::_getDao()->getsBy($params);

		//基于渠道号的统计，做出一定的修改 panxb 2014-5-15
		$tempData = $pvData = array();
		foreach ($list as $v) {
			$d                          = date('Y-m-d', strtotime($v['date']));
			$m                          = $v['key'];
			$tempData[$m][$d][$v['id']] = $v['val'];
		}
		foreach ($tempData as $k => $v) {
			foreach ($v as $m => $n) {
				$sm = 0;
				foreach ($n as $j) {
					$sm += $j;
				}
				$pvData[$k][$m] = $sm;
			}
		}

		return $pvData;
	}

	public static function getNgTypeData($typeId, $sDate, $eDate) {

		$typeList = Gionee_Service_Ng::getsBy(array('type_id' => $typeId), array('sort' => 'ASC', 'id' => 'ASC'));
		foreach ($typeList as $k => $v) {
			$keys[] = $v['id'];
		}

		$params = array(
			'type' => self::TYPE_NAV,
			'key'  => array('IN', $keys),
			'date' => array(array('>=', $sDate), array('<=', $eDate))
		);
		$list   = self::_getDao()->getsBy($params);
		$pvData = array();
		foreach ($list as $v) {
			$d              = date('Y-m-d', strtotime($v['date']));
			$num            = $v['val'];
			$k              = $v['key'];
			$pvData[$k][$d] = $num;
		}

		return $pvData;
	}

	public static function getNgTotalNumber(array $params) {
		$temp = array();
		if (isset($params['type'])) $temp['type'] = $params['type'];
		if (isset($params['key'])) $temp['key'] = $params['key'];
		if (isset($params['edate']) && isset($params['sdate'])) $temp['date'] = array(array('>=', date('Ymd', $params['sdate'])), array('<=', date('Ymd', $params['edate'])));
		if (isset($params['ver'])) $temp['ver'] = $params['ver'];
		$num = self::_getDao()->sum('val', $temp);
		return empty($num) ? 0 : $num;

	}

	/**
	 *
	 * @param arrray $arr 基本参数
	 * @param varchar $type 类型
	 * @param array $search 其它相查询的参数
	 * @param array $group GROUP BY 的参数
	 * @param array $orderBy 排序
	 * @param array $limit limit条件
	 * @return array
	 */

	public static function getSumByChannel($arr = array(), $type = self::TYPE_NAV, $search = array(), $group = array(), $orderBy = array('id' => 'DESC')) {
		$params = array();
		if (isset($arr['ver'])) $params['ver'] = $arr['ver'];
		if (isset($arr['sdate']) && isset($arr['sdate'])) $params['date'] = array(array('>=', date('Ymd', $arr['sdate'])), array('<=', date('Ymd', $arr['edate'])));
		if (is_array($type)) {
			$params['type'] = array("IN", $type);
		} else {
			$params['type'] = $type;
		}
		$data = self::_getDao()->complexSum('val', $search, $params, $group, $orderBy);

		return $data;
	}

	/**
	 * 根据内容ID或渠道号查询统计纪录
	 * @param array $array
	 * @param string $type
	 */
	public static function getTotalByNidVer($arr = array(), $type = self::TYPE_NAV) {
		if (!is_array($arr)) {
			return false;
		}
		$params = array();
		if (isset($arr['sdate']) && isset($arr['edate'])) $params['date'] = array(array('>=', date('Ymd', $arr['sdate'])), array('<=', date('Ymd', $arr['edate'])));
		if (isset($arr['ids'])) { //
			$params['key'] = array('IN', $arr['ids']);
			$result        = self::_getDao()->complexSum('val', array('key'), $params, array('key'), array('total' => 'DESC'));
		} elseif (isset($arr['ver'])) {
			$result = self::_getDao()->sum('val', $params);
		}
		return $result;
	}

	/**
	 *
	 * @param string $data
	 */
	public static function get($date) {
		return self::_getDao()->get($date);
	}

	public static function getsBy($param, $orderBy = array()) {
		if (!is_array($param)) return false;
		return self::_getDao()->getsBy($param, $orderBy);
	}

	/**
	 *
	 * @param array $data
	 * @param string $date
	 */
	public static function set($data, $date) {
		if (!is_array($data)) return false;
		return self::_getDao()->update($data, $date);
	}

	/**
	 *
	 *
	 * @param array $data
	 */
	public static function add($data) {
		if (!is_array($data)) return false;
		return self::_getDao()->insert($data);
	}

	public static function count($params) {
		return self::_getDao()->count($params);
	}

	public static function getList($page, $limit, $params = array(), $sort = array()) {
		if ($page < 1) $page = 1;
		$start = ($page - 1) * $limit;
		$ret   = self::_getDao()->getList($start, $limit, $params, $sort);
		$total = self::count($params);
		return array($total, $ret);
	}

	/**
	 * public static function uvLog($val) {
	 * $key = Gionee_Service_Log::TYPE_UV . ':' . $val;
	 * if (Gionee_Service_User::isCookieSet($key)) {
	 * Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_UV, $val); //UV统计
	 * }
	 * }
	 **/
	public static function uvLog($val, $t_bi) {
		if (empty($t_bi)) {
			return false;
		}
		Gionee_Service_Log::toUVByCacheKey(Gionee_Service_Log::TYPE_UV, $val, $t_bi);
	}

	public static function pvLog($val) {
		Gionee_Service_Log::incrBy(Gionee_Service_Log::TYPE_PV, $val);
	}

	/**
	 * 搜集用户访问次数
	 * 公共KEY 用 uvLog方法 (页面)
	 * 独立KEY 下面有多个值(新闻ID)
	 * @param $uvKey  记录KEY
	 * @param $val 值
	 * @param $t_bi 用户唯一标记
	 * @return bool
	 */
	public static function toUVByCacheKey($uvKey, $val, $t_bi) {
		if (empty($t_bi)) {
			return false;
		}
		$nowDay = date('Ymd');
		$key    = $uvKey . $t_bi;
		//检测用户是否点击
		$flag = Common::getCache()->hGet($key, $val);
		if (empty($flag) || $flag != $nowDay) {
			//更新用户点击标记
			Common::getCache()->hSet($key, $val, $nowDay, 86400);
			//更新点击记录
			Gionee_Service_Log::incrBy($uvKey, $val);
		}
		return true;
	}

	public static function getTotalByMonth($type, $m = '') {
		return self::_getDao()->getTotalByMonth($type, $m);
	}

}
