<?php

if (!defined('BASE_PATH')) exit('Access Denied!');

class Gionee_Service_VoIPClient {

	public static function insert($params) {
		if (!is_array($params)) return false;
		$ret = self::_getDao()->insert($params);
		if (!$ret) {
			return $ret;
		}
		return self::_getDao()->getLastInsertId();
	}


	//获取数据
	public static function _getClientNumber($mobile) {
		if (empty($mobile)) {
			return 0;
		}
		$info = self::_getDao()->getBy(array('mobile_number' => $mobile));
		return isset($info['client_number']) ? $info['client_number'] : 0;
	}

	public static function _getMobileNumber($client) {
		if (empty($client)) {
			return 0;
		}
		$info = self::_getDao()->getBy(array('client_number' => $client));
		return isset($info['mobile_number']) ? $info['mobile_number'] : 0;
	}

	public static function getClientNumber($mobile, $isCall = false) {
		if (empty($mobile)) {
			return 0;
		}

		$key    = 'VOIP_MOBILE_NUMBER:' . $mobile;
		$number = Common::getCache()->get($key);
		if (empty($number)) {
			$number = self::_getClientNumber($mobile);
			if ($isCall && empty($number)) {
				$test   = new Vendor_Tel();
				$number = $test->getClientNumber($mobile);
				$param  = array(
					'mobile_number' => $mobile,
					'client_number' => $number,
					'created_at'    => time(),
				);
				$id = self::insert($param);
			}

			if (!empty($clientNumber)) {
				Common::getCache()->set($key, $number, 86400);
			}
		}
		return !empty($number) ? $number : 0;
	}

	public static function getMobileNumber($client) {
		if (empty($client)) {
			return 0;
		}
		$key    = 'VOIP_CLIENT_NUMBER:' . $client;
		$number = Common::getCache()->get($key);
		if (empty($number)) {
			$number = self::_getMobileNumber($client);
			Common::getCache()->set($key, $number, 86400);
		}
		return !empty($number) ? $number : 0;
	}


	public static function update($params, $id) {
		return self::_getDao()->update($params, $id);
	}

	public static function updateBy($params, $where) {
		return self::_getDao()->updateBy($params, $where);
	}

	//
	public static function delete($id) {
		if (!is_numeric($id)) return false;
		return self::_getDao()->delete($id);
	}

	private static function  _getDao() {
		return Common::getDao('Gionee_Dao_VoIPClient');
	}
}