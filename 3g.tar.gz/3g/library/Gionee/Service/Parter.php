<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class Gionee_Service_Parter {
	
	
	/**
	 *
	 * Enter desAreaiption here ...
	 * @param unknown_type $params
	 * @param unknown_type $page
	 * @param unknown_type $limit
	 */
	public static function getList($page = 1, $limit = 10, $params = array()) {
		$params = self::_cookData($params);
	
		if ($page < 1) $page = 1;
		$start = ($page - 1) * $limit;
		$ret   = self::_getDao()->getList($start, $limit, $params);
		$total = self::_getDao()->count($params);
		return array($total, $ret);
	}
	
	/**
	 * @param string $data
	 */
	public static function get($date) {
		return self::_getDao()->get($date);
	}
	/**
	 * 
	 */
	public static function getAll($orderBy = array()) {
		return self::_getDao()->getAll($orderBy = array());
	}
	/**
	 *
	 * Enter desAreaiption here ...
	 * @param unknown_type $data
	 */
	private static function _cookData($data) {
		$tmp = array();
		if (isset($data['name'])) $tmp['name'] = $data['name'];
		if (isset($data['url'])) $tmp['url'] = $data['url'];
		if (isset($data['other'])) $tmp['other'] = intval($data['other']);
		return $tmp;
	}
	
	/**
	 * 
	 * @param unknown $data
	 * @param unknown $id
	 * @return boolean|Ambigous <boolean, number>
	 */
	public static function update($data, $id) {
		if (!is_array($data)) return false;
		$data = self::_cookData($data);
		return self::_getDao()->update($data, intval($id));
	}
	
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $id
	 */
	public static function delete($id) {
		return self::_getDao()->delete(intval($id));
	}
	
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $data
	 */
	public static function add($data) {
		if (!is_array($data)) return false;
		$data = self::_cookData($data);
		return self::_getDao()->insert($data);
	}
	
	/**
	 *
	 * @return Gionee_Dao_Area
	 */
	private static function _getDao() {
		return Common::getDao("Gionee_Dao_Parter");
	}
}