<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

/**
 *
 * Enter description here ...
 * @author tiger
 *
 */
class Gionee_Service_Feedback {


	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $params
	 * @param unknown_type $page
	 * @param unknown_type $limit
	 */
	public static function getList($page = 1, $limit = 10, $params = array(), $sort = array()) {
		$params = self::_cookData($params);
		if ($page < 1) $page = 1;
		$start = ($page - 1) * $limit;
		$ret   = self::_getDao()->getList($start, $limit, $params, $sort);
		$total = self::_getDao()->count($params);
		return array($total, $ret);
	}

	/**
	 * 
	 * @param unknown $id
	 * @return boolean
	 */
	public static function get($id) {
		if (!intval($id)) return false;
		return self::_getDao()->get(intval($id));
	}

	public static function getsBy($params =array(),$orderBy=array()){
		if(!is_array($params) || !is_array($orderBy) ) return false;
		return array(self::_getDao()->count($params),self::_getDao()->getsBy($params,$orderBy));
	}
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $data
	 * @param unknown_type $id
	 */
	public static function updateApp($data, $id) {
		if (!is_array($data)) return false;
		$data = self::_cookData($data);
		return self::_getDao()->update($data, intval($id));
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $id
	 */
	public static function deleteApp($id) {
		return self::_getDao()->delete(intval($id));
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $data
	 */
	public static function add($data) {
		if (!is_array($data)) return false;
		$data = self::_cookData($data);
		return self::_getDao()->insert($data);
	}

	
	/**
	 * 
	 */
	public static function getFeedBackDatas($elems,$params= array(),$groupBy=array(),$orderBy=array(),$limitBy = array()){
		if(!is_array($params)||!is_array($elems)) return false;
		return array(self::_getDao()->count($params,$groupBy),self::_getDao()->getDataByParams($elems,$params,$groupBy,$orderBy,$limitBy));
	}
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $id
	 */
	public static function updateTJ($id) {
		if (!$id) return false;
		return self::_getDao()->increment('hits', array('id' => intval($id)));
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $data
	 */
	private static function _cookData($data) {
		$tmp = array();
		if (isset($data['user_flag'])) $tmp['user_flag'] = $data['user_flag'];
		if (isset($data['topic_id'])) $tmp['topic_id'] = $data['topic_id'];
		if (isset($data['option_num'])) $tmp['option_num'] = $data['option_num'];
		if (isset($data['answer'])) $tmp['answer'] = $data['answer'];
		if (isset($data['contact'])) $tmp['contact'] = $data['contact'];
		if (isset($data['create_time'])) $tmp['create_time'] = $data['create_time'];
		if (isset($data['ip'])) $tmp['ip'] = $data['ip'];
		if (isset($data['num'])) $tmp['num'] = $data['num'];
		return $tmp;
	}

	/**
	 *
	 * @return Gionee_Dao_App
	 */
	private static function _getDao() {
		return Common::getDao("Gionee_Dao_Feedback");
	}
}