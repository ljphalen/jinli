<?php
if (!defined('BASE_PATH')) exit('Access Denied!');

class Api_Gionee_Account {
	
	//获取账号的配置文件信息
	public static function getConfig(){
		return Common::getConfig('apiConfig','oauth');
	}
	
	//根据环境的不同,设置不到的域名
	public static function getDomain(){
		return ENV == 'product'? 'https://id.gionee.com' : 'https://t-id.gionee.com:6443';
	}

	//获取服务器时间
	public static function getServiceTime(){
		$url = self::getDomain().'/time.do';
		$request = Util_Http::post($url, array('Content-Type' => 'application/json'));
		return $request->headers;
	}
	
	//生成APP-TOKEN
	public static function getAppToken(){
		$config = Api_Gionee_Account::getConfig();
		$appKey = $config['gionee_user_appkey'];
		$appId = $config['gionee_user_appid'];
		$string = self::_getShuttleString();
		$url = self::getDomain().'/api/token/getapptoken.do';
		$mac= self::_getMacSignature($appKey,$string);
		$data = json_encode(array('id'=>$appId, 'ts'=>time(),'nonce'=>$string,'mac'=>$mac));
		$result = Util_Http::post($url, $data,array('Content-Type' => 'application/json'));
		return json_decode($result->data,true);
	}
	//获取图形验证码
	public static function getImageCode(){
		$url = self::getDomain() . '/account/refreshgvc.do';
		$data = json_encode(array('vty'=> 'vtext'));
		$result = Util_Http::post($url, $data, array('Content-Type' => 'application/json'));
		return json_decode($result->data, true);
	}
	
	/**
	 * 图形码验证
	 * @param string tn  电话号码
	 * @param string vid 图形码状态
	 */
	public static function registerByGvc($tn,$vid,$vtx,$vty='vtext'){
		$url = self::getDomain() . '/api/gsp/register_by_gvc.do';
		$data = json_encode(array('tn'=> $tn, 'vid' => $vid, 'vtx' => $vtx, 'vty' => $vty));
		$result = Util_Http::post($url, $data, array('Content-Type' => 'application/json'));
		return json_decode($result->data, true);
	}
	
	/**
	 * 获取短信验证码
	 */
	public static function getSmsVerifyCode($mobile,$imgCode){
		$url = self::getDomain() . '/api/gsp/get_sms_for_register.do';
		$data = json_encode(array('tn'=> $mobile, 's' => $imgCode));
		$result = Util_Http::post($url, $data, array('Content-Type' => 'application/json'));
		return json_decode($result->data, true);	
	}
	
	/**
	 * 短信注册
	 */
	public static function registerBySms($mobile ,$verifyCode,$imgCode){
		$url = self::getDomain() . '/api/gsp/register_by_smscode.do';
		$data = json_encode(array('tn'=> $mobile, 'sc' => $verifyCode, 's' => $imgCode));
		$result = Util_Http::post($url, $data, array('Content-Type' => 'application/json'));
		return json_decode($result->data, true);
	}
	
	/**
	 * 设置密码
	 * @param string $pwd 要设置的密码
	 * @param string $code 短信验证码
	 */
	
	public static function setLoginPassword($pwd,$code){
		$url = self::getDomain() . '/api/gsp/register_by_pass.do';
		//增加注册接口中使用的appid
		$config = self::getConfig();
		$a = $config['gionee_user_appid'];
		$data = json_encode(array('s'=> $code, 'p' => $pwd, 'a' => a));
		$result = Util_Http::post($url, $data, array('Content-Type' => 'application/json'));
		return json_decode($result->data, true);
	}
	
	/**
	 * 生成MAC签名
	 * @param string $host  主域名
	 * @param int  $port 端口
	 * @param string  $url 链接
	 * @param string  $appkey MACKey
	 * @param unknown $string 随机字符串
	 * @param unknown $time 时间
	 * @param string $method 提交方式
	 */
	private  static function _getMacSignature($appKey,$string){
		 	$time = time();
			$method = 'POST';
			$url = '/api/token/getapptoken.do';
			$host ='t-id.amigo.cn';
			$port = '6443';
			$array = array($time,$string,$method,$url,$host,$port);
			$macString = implode("\n", $array)."\n\n";
			$uft8Str = mb_convert_encoding($macString, 'UTF-8');
			
			$hmacStr = base64_encode(hash_hmac('sha1', $uft8Str, $appKey));
			//var_dump($macString,$hmacStr);exit;
			return urlencode($hmacStr);
	}
	
	private static function _getShuttleString($len=8){
		$character = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghigklmnopqrstuvwxyz0123456789";
		$chaos = str_shuffle($character);
		return substr($chaos, 0,$len);
	}
	
	/**
	 * Gionee 密码加密算法(帐号系统)
	 * @param string $p
	 * @return string
	 */
	public static function encode_password($p){
		return strtoupper(sha1($p));
	}
}