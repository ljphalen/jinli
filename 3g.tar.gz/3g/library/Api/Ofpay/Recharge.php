<?php 
if (!defined('BASE_PATH')) exit('Access Denied!');

class Api_Ofpay_Recharge {
	
	
	/**
	 * 用户信息查询接口，用于查询SP用户的信用点余额
	 */
	
	public static function getUserInfo(){
		return self::_getResponse('queryuserinfo.do?',self::_getBaseParams());
	}
	
	/**
	 * 检测用户手机号是否能充值
	 * 此接口用于查询手机号是否能充值，如果能就返回商品信息，不能就返回提示正中维护中
	 */
	public static function checkMobileStatus($mobile,$pervalue){
		$params = array_merge(
				self::_getBaseParams(),
				array('phoneno'=>$mobile,
							'pervalue'=>intval($pervalue)
				)
			);
		return self::_getResponse('telquery.do?', $params);
	}
	
	/**
	 * 查询手机号码平台信息
	 */
	
	public static function getMobileplatform($mobile){
		$config = Common::getConfig('apiConfig');
		$url = $config['ofpay_url'].'mobinfo.do?'.http_build_query(array('mobilenum'=>$mobile));
		$response = Util_Http::get($url);
		if ($response->state !== 200) {
			Common::log(array($url, $response), 'ofpay_response.log');
			return false;
		}
		$mobinfo = iconv('gbk', 'utf-8', $response->data);
		$mobinfo = explode('|', $mobinfo);
		$plat = Util_String::substr($mobinfo[2], 0, 2);
		$plat_id = 0;
		
		switch ($plat){
			case '移动':
				$plat_id = 1;
				break;
			case '联通':
				$plat_id = 2;
				break;
			case '电信':
				$plat_id = 3;
				break;
			default:
				$plat_id = 0;
		}
		
		return $plat_id;
	}
	
	/**
	 * 充值接口
	 */
	public static function recharge($order_sn){
		$orderInfo = User_Service_Order::getBy(array('order_sn'=>$order_sn));
		if(!$orderInfo) {
			Common::log('Error: error order_no:' . $order_sn, 'recharge.log');
		}
		$queryInfo = self::checkMobileStatus($orderInfo['recharge_mobile'], intval($orderInfo['order_amount']));
		if($queryInfo['cardinfo']['retcode'] == 1){
			$data = array(
					'cardid'=>$queryInfo['cardinfo']['cardid'],
					'cardnum'=>$orderInfo['order_amount'],
					'order_sn'=>$orderInfo['order_sn'],
					'create_time'=>$orderInfo['add_time'],
					'phone'=>$orderInfo['recharge_mobile'],
					'ret_url'=>Common::getMainHost().'/api/recharge/response'
			);
			$chargeResult = self::onlineOrder($data);
			$orderStatus = $chargeResult['orderinfo'];
			if($orderStatus['retcode'] == 9){
				User_Service_Order::update(array('order_status'=>-1,'rec_status'=>-1), $orderInfo['id']);
				return array('key'=>'-1','msg'=>'充值失败！');
			}elseif($orderStatus['retcode'] ==1){
				switch ($orderStatus['game_state']){
					case 0:{ //充值中
						$order_status = 2;
						$rechare_status= 2;
						break;
					}
					case 1:{ //充值成功
						$order_status  = 1;
						$rechare_status = 1;
						break;
					} 
					case 9:{ //充值失败
						$order_status = -1;
						$rechare_status = -1;
						break;
					}
					default: break;
				}
				$options = array(
					'order_status'=>$order_status,
					'rec_status'=>$rechare_status,
					'rec_order_id'=>$orderStatus['orderid'],
					'rec_money'=>$orderStatus['ordercash'],
				);
				User_Service_Order::update($options,	 $orderInfo['id']);
				return array('key'=>'1','msg'=>'正在充值中，请稍候！');
			}else{
				$res = Common_Service_User::changeUserScores($orderInfo['id'],205);
				return array('key'=>'-1','msg'=>$orderStatus['err_msg']);
			}
		}else{
			Common::log('无法充值 : ' . $orderInfo['trade_no'], 'recharge.log');
			return array('key'=>'-2','msg'=>'运营商系统维护中，暂不能充值！');
		}
	}
	
	
	/**
	 * 查询商品信息的同步接口
	 */
	public static function queryCardInfo($cardId){
		$params = array_merge(
				self::_getBaseParams(),
				array(
					'cardid'	=>$cardId,
				)
			);
		return self::_getResponse('querycardinfo.do?', $params);
	}
	
	/**
	 * 查询是否有库存
	 */
	public static function queryleftnumber($cardId){
		$params = array_merge(
				self::_getBaseParams(),
				array(
						'cardid'	=>$cardId,
				)
		);
		return self::_getResponse('queryleftcardnum.do?', $params);
	}
	/**
	 * 获取购物券
	 */
	public static function getCoupon($order_sn,$cardMsg=array()){
		try{
			$cardInfo = self::queryCardInfo($cardMsg['card_id']);
			if( $cardInfo['cardinfo']['retcode'] =='1'){ //信息查询成功
				$leftInfo = self::queryleftnumber($cardMsg['card_id']);//查看剩下的卡数量
				if($leftInfo['cardinfo']['retcode'] =='1'){
					if($leftInfo['cardinfo']['ret_cardinfos']['card']['innum'] <1){
						return array('key'=>'0','msg'=>'该卡库存不足！');
					}
				}else{
					return array('key'=>'0','msg'=>'系统内部错误！');
				}
				$orderInfo = User_Service_Order::getBy(array('order_sn'=>$order_sn));
				$params  = array(
					'cardid'=>$cardMsg['card_id'],
					'cardnum'=>1,
					'sporder_id'=>$order_sn,
					'sporder_time'=>date('YmdHis',$orderInfo['add_time']),
				);
				$fields = array();
			//	$response  = self::couponMsg($params);
				$response = array(
						"orderinfo"=>array(
						"err_msg"=>"",
						"retcode"=> "1",
						"orderid"=> "S1411131484353",
						"cardid"=>"2116712",
						"cardnum"=> "1",
						"ordercash"=> "5.035",
						"cardname"=>"支付宝预付卡5元卡密",
						"sporder_id"=> "201411131656201581050663",
						"cards"=>array(
							"card"=>array(
								"cardno"=> "8007130056838271",
								"cardpws"=>"056266",
								"expiretime"=> "2015-11-30"
							)
						)
					)
				);
				switch ($response['orderinfo']['retcode']){
					case 1:
						$fields['order_status'] = 1;
						$fields['shipping_status'] = 1;
						$fields['rec_status'] = 1;
						$fields['rec_order_id']  = $response['orderinfo']['orderid'];
					break;
					case 9:{
						$fields['order_status'] = -1;
						$fields['order_id'] = -1;
						$fields['shipping_status'] = 0;
						$fields['rec_status'] = -1;
						break;
					}
					default:break;
				}
				$fields['ordercrach'] = $response['orderinfo']['ordercash'];
				$fields['rec_order_time'] = time();
				User_Service_Recharge::add(array('api_type'=>'2','order_id'=>$response['orderinfo']['orderid'],'add_time'=>time(), 'order_sn'=>$order_sn,'status'=>$response['orderinfo']['retcode'],'desc'=>json_encode($response)));
				$ret = User_Service_Order::update($fields, $orderInfo['id']); //更新订单状态
				$ret2 = Common_Service_User::sendInnerMsg(array('uid'=>$orderInfo['uid'],'classify'=>2,'status'=>$fields['order_status'],'cardMsg'=>$cardMsg, 'card'=>$response['orderinfo']['cards']['card']),'coupon_msg_tpl');
				if( $ret && $ret2){
					if($fields['order_status'] == '1'){
						Common_Service_User::changeUserScores($orderInfo['id'],'401','-');//扣除冻结积分
						return array('key'=>'1','msg'=>'获取成功！');
					}elseif($fields['order_status'] == '-1'){
						Common_Service_User::changeUserScores($orderInfo['id'],'205');//返还冻结积分
						return  array('key'=>'-1','msg'=>'获取失败!');
					}
				}else{
					Common_Service_User::changeUserScores($orderInfo['id'],'205');//返还冻结积分
					return  array('key'=>'-2','msg'=>'订单状态或站内信发送失败');
				}
			}else{
				return array('key'=>'-3','msg'=>'查询商品信息失败，请重试！');
				}
		}catch (Exception $e){
			return array('key'=>'-4','msg'=>"系统内部错误！");
		}
	}
	
	/**
	 * 获取优惠券的密码
	 */
	private static function  couponMsg($data =array()){
		if(is_array($data) && $data['cardid'] &&$data['cardnum'] && $data['sporder_id'] && $data['sporder_time']){
			$params = array_merge(self::_getBaseParams(),$data);
			$config = self::_ofpayConfig();
			$key_str = $config['ofpay_keyStr'];
			$md5_str= $params['userid'].$params['userpws'].$params['cardid'].$params['cardnum'].$params['sporder_id'].$params['sporder_time'].$key_str;
			$params['md5_str'] = strtoupper(md5($md5_str));
			return  self::_getResponse('order.do?', $params);
		}
	}
	/**
	 * 充值第三方处理接口
	 * @param unknown $data
	 * @return boolean|Ambigous <boolean, DOMDocument, mixed, string, multitype:multitype: string multitype:string  mixed >
	 */
	public static function onlineOrder($data){
		if(!is_array($data) || !$data['cardid'] || !$data['cardnum']  || !$data['order_sn'] || !$data['create_time'] || !$data['phone'] || !$data['ret_url']) return false;
		$params = array_merge(
				self::_getBaseParams(),
				array(
						'cardid' => '140101',
						'cardnum' => intval($data['cardnum']),
						'sporder_id' => $data['order_sn'],
						'sporder_time' => date('YmdHis', $data['create_time']),
						'game_userid' => $data['phone'],
						'ret_url'=>$data['ret_url']
				)
		);
		$config = self::_ofpayConfig();
		$key_str = $config['ofpay_keyStr'];
		$md5_str = $params['userid'].$params['userpws'].$params['cardid'].$params['cardnum'].$params['sporder_id'].$params['sporder_time'].$params['game_userid'].$key_str;
		$params['md5_str'] = strtoupper(md5($md5_str));
		return self::_getResponse('onlineorder.do?', $params);
	}
	

	
	/**
	 * 根据SP订单号补发充值状态
	 * 此接口用于没有接收到回调充值状态的情况下进行补发
	 *
	 * @param string $phone
	 * @param string $pervalue
	 */
	public static function reissue($order_id) {
		$params = array_merge(
				self::_getBaseParams(),
				array(
						'spbillid'=>$order_id
				)
		);
		return self::_getResponse('reissue.do?', $params);
	}
	
	/**
	 * 获得商品的信息
	 */
	
	//数据处理
	public static function _getResponse($action,$params){
		$config = self::_ofpayConfig();
		$url = $config['ofpay_url'].$action.http_build_query($params);
		$response = Util_Http::get($url);
		if ($response->state != 200) {
			Common::log(array($url.$action, $params, $response), 'ofpay_response.log');
			return false;
		}
		$ret = Util_XML2Array::createArray($response->data);
		
		//如果是充值就是写充值日志
		if($action == 'onlineorder.do?'){
			$options = array(
				'api_type'=>'1',
				'order_sn'=>$params['sporder_id'],
				'order_id'=>$ret['orderinfo']['orderid'],
				'add_time'=>time(),
				'desc' =>json_encode($ret),
				'status'=>$ret['orderinfo']['game_state']
			);
			User_Service_Recharge::add($options);
		}
		return $ret;
	}
	
	//基础数据信息
	public static function _getBaseParams(){
		$config = self::_ofpayConfig();
		return array(
				'userid'=>$config['ofpay_userid'],
				'userpws'=>md5($config['ofpay_userpws']),
				'version' => '6.0'
		);
	}
	
	
	private static function _ofpayConfig(){
		$ofpayConfig = Common::getConfig('authConfig', 'ofpay');
		return $ofpayConfig;
	}
}

?>