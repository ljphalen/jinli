﻿for(var i = 0; i < 221; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'center';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u21'] = 'top';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_2.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u140'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核信息.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u186'] = 'center';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'center';document.getElementById('u105_img').tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	SetPanelVisibility('u207','','none',500);

}
});
u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用上线.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u192'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u6'] = 'center';u205.tabIndex = 0;

u205.style.cursor = 'pointer';
$axure.eventManager.click('u205', function(e) {

if (true) {

	self.location.href='#';

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u205'] = 'top';gv_vAlignTable['u108'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u16'] = 'top';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发文档发布.html');

}
});
gv_vAlignTable['u37'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u11'] = 'top';document.getElementById('u93_img').tabIndex = 0;

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

	SetPanelVisibility('u207','','none',500);

}
});
gv_vAlignTable['u200'] = 'center';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u34'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u184'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u164'] = 'center';u31.tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u214'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u67'] = 'top';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'center';document.getElementById('u216_img').tabIndex = 0;

u216.style.cursor = 'pointer';
$axure.eventManager.click('u216', function(e) {

if (true) {

	SetPanelVisibility('u207','hidden','none',500);

}
});
gv_vAlignTable['u100'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u202'] = 'center';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u82'] = 'center';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u36'] = 'top';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u114'] = 'center';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u198'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u180'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u154'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u211'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u209'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u190'] = 'center';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u64'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u188'] = 'center';gv_vAlignTable['u162'] = 'center';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u152'] = 'center';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u58'] = 'top';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u178'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u196'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u102'] = 'center';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u90'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u45'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u182'] = 'center';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u218'] = 'top';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u194'] = 'center';