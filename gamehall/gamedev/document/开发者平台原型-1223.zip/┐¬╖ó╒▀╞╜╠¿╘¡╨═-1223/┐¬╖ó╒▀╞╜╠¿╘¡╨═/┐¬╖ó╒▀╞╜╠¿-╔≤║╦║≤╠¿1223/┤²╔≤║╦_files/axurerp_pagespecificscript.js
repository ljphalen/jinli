﻿for(var i = 0; i < 361; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u202'] = 'center';gv_vAlignTable['u180'] = 'center';gv_vAlignTable['u216'] = 'center';gv_vAlignTable['u194'] = 'center';gv_vAlignTable['u333'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u298'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u43'] = 'center';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u126'] = 'center';document.getElementById('u332_img').tabIndex = 0;

u332.style.cursor = 'pointer';
$axure.eventManager.click('u332', function(e) {

if (true) {

	SetPanelVisibility('u305','hidden','none',500);

}
});
document.getElementById('u346_img').tabIndex = 0;

u346.style.cursor = 'pointer';
$axure.eventManager.click('u346', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u236'] = 'center';gv_vAlignTable['u214'] = 'center';gv_vAlignTable['u192'] = 'center';gv_vAlignTable['u331'] = 'center';gv_vAlignTable['u321'] = 'center';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u327'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u318'] = 'center';gv_vAlignTable['u268'] = 'center';document.getElementById('u330_img').tabIndex = 0;

u330.style.cursor = 'pointer';
$axure.eventManager.click('u330', function(e) {

if (true) {

	SetPanelVisibility('u322','hidden','none',500);

}
});
gv_vAlignTable['u274'] = 'center';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发文档发布.html');

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u307'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u343'] = 'center';gv_vAlignTable['u162'] = 'center';gv_vAlignTable['u357'] = 'top';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u284'] = 'center';gv_vAlignTable['u329'] = 'center';gv_vAlignTable['u356'] = 'top';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u348'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u160'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u49'] = 'top';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u309'] = 'center';gv_vAlignTable['u228'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u304'] = 'center';gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u240'] = 'center';gv_vAlignTable['u296'] = 'center';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u254'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u358'] = 'top';document.getElementById('u317_img').tabIndex = 0;

u317.style.cursor = 'pointer';
$axure.eventManager.click('u317', function(e) {

if (true) {

	SetPanelVisibility('u322','','none',500);

}
});
gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u302'] = 'center';gv_vAlignTable['u280'] = 'center';gv_vAlignTable['u316'] = 'top';gv_vAlignTable['u294'] = 'center';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u252'] = 'center';gv_vAlignTable['u266'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u315'] = 'center';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u82'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u238'] = 'center';gv_vAlignTable['u200'] = 'center';document.getElementById('u314_img').tabIndex = 0;

u314.style.cursor = 'pointer';
$axure.eventManager.click('u314', function(e) {

if (true) {

	SetPanelVisibility('u305','hidden','none',500);

}
});
gv_vAlignTable['u292'] = 'center';gv_vAlignTable['u250'] = 'center';gv_vAlignTable['u58'] = 'center';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u190'] = 'center';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u262'] = 'center';gv_vAlignTable['u276'] = 'center';gv_vAlignTable['u130'] = 'center';document.getElementById('u85_img').tabIndex = 0;

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if (true) {

	SetPanelState('u305', 'pd0u305','none','',500,'none','',500);

}
});
u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u144'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核信息.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u248'] = 'center';gv_vAlignTable['u210'] = 'center';gv_vAlignTable['u325'] = 'top';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u224'] = 'center';gv_vAlignTable['u341'] = 'center';gv_vAlignTable['u260'] = 'center';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u9'] = 'top';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u188'] = 'center';gv_vAlignTable['u226'] = 'center';gv_vAlignTable['u222'] = 'center';gv_vAlignTable['u311'] = 'center';gv_vAlignTable['u6'] = 'center';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u36'] = 'top';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u353'] = 'top';gv_vAlignTable['u272'] = 'center';gv_vAlignTable['u336'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u232'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u208'] = 'center';gv_vAlignTable['u312'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u339'] = 'top';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u220'] = 'center';u31.tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u234'] = 'center';document.getElementById('u73_img').tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	SetPanelVisibility('u305','','none',500);

}
});
gv_vAlignTable['u351'] = 'top';gv_vAlignTable['u270'] = 'center';gv_vAlignTable['u319'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u338'] = 'top';gv_vAlignTable['u300'] = 'center';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u186'] = 'center';gv_vAlignTable['u350'] = 'top';gv_vAlignTable['u347'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u198'] = 'center';gv_vAlignTable['u313'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u246'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u290'] = 'center';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u70'] = 'center';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u218'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u286'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u230'] = 'center';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_2.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u244'] = 'center';u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用上线.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u360'] = 'top';document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('注册资料管理.html'), "");

}
});
gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u184'] = 'center';gv_vAlignTable['u242'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u344'] = 'top';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u174'] = 'center';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u39'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u288'] = 'center';gv_vAlignTable['u204'] = 'center';gv_vAlignTable['u182'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u335'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u154'] = 'center';gv_vAlignTable['u264'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u258'] = 'center';gv_vAlignTable['u4'] = 'center';document.getElementById('u334_img').tabIndex = 0;

u334.style.cursor = 'pointer';
$axure.eventManager.click('u334', function(e) {

if (true) {

	SetPanelVisibility('u322','hidden','none',500);

}
});
gv_vAlignTable['u324'] = 'center';