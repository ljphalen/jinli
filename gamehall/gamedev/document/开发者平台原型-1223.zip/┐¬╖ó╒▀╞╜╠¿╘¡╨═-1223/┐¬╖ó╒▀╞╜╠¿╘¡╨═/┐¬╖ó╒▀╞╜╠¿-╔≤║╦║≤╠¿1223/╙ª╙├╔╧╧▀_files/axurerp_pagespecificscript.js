﻿for(var i = 0; i < 269; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'top';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u132'] = 'top';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u4'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u186'] = 'top';gv_vAlignTable['u48'] = 'top';u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u120'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u108'] = 'top';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u238'] = 'top';gv_vAlignTable['u62'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u200'] = 'top';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_2.html');

}
});
gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u258'] = 'top';u31.tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u263'] = 'top';document.getElementById('u253_img').tabIndex = 0;

u253.style.cursor = 'pointer';
$axure.eventManager.click('u253', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u16'] = 'top';u41.tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u8'] = 'center';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u250'] = 'center';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u38'] = 'top';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u254'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u265'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u228'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u114'] = 'top';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u251'] = 'top';gv_vAlignTable['u198'] = 'top';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u256'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u154'] = 'top';u40.tabIndex = 0;

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u236'] = 'top';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u259'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u164'] = 'top';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u234'] = 'top';gv_vAlignTable['u140'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核信息.html');

}
});
gv_vAlignTable['u19'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u188'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u156'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u246'] = 'top';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u58'] = 'top';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u36'] = 'top';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发文档发布.html');

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u98'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u178'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u138'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u244'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u248'] = 'center';gv_vAlignTable['u224'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u182'] = 'top';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u194'] = 'top';