﻿for(var i = 0; i < 319; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u299'] = 'center';gv_vAlignTable['u97'] = 'center';document.getElementById('u231_img').tabIndex = 0;

u231.style.cursor = 'pointer';
$axure.eventManager.click('u231', function(e) {

if (true) {

	SetPanelVisibility('u222','hidden','none',500);

}
});
gv_vAlignTable['u139'] = 'center';gv_vAlignTable['u201'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u215'] = 'center';gv_vAlignTable['u193'] = 'center';gv_vAlignTable['u151'] = 'center';gv_vAlignTable['u165'] = 'center';
u236.style.cursor = 'pointer';
$axure.eventManager.click('u236', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html'), "");

}
});
gv_vAlignTable['u67'] = 'center';u269.tabIndex = 0;

u269.style.cursor = 'pointer';
$axure.eventManager.click('u269', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u269'] = 'top';u287.tabIndex = 0;

u287.style.cursor = 'pointer';
$axure.eventManager.click('u287', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_2.html');

}
});
gv_vAlignTable['u287'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u318'] = 'top';gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u268'] = 'top';u286.tabIndex = 0;

u286.style.cursor = 'pointer';
$axure.eventManager.click('u286', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u286'] = 'top';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u177'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u307'] = 'top';u285.tabIndex = 0;

u285.style.cursor = 'pointer';
$axure.eventManager.click('u285', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u285'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u306'] = 'top';u284.tabIndex = 0;

u284.style.cursor = 'pointer';
$axure.eventManager.click('u284', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u284'] = 'top';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u229'] = 'center';u283.tabIndex = 0;

u283.style.cursor = 'pointer';
$axure.eventManager.click('u283', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u283'] = 'top';u279.tabIndex = 0;

u279.style.cursor = 'pointer';
$axure.eventManager.click('u279', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u279'] = 'top';gv_vAlignTable['u297'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u309'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u304'] = 'top';u282.tabIndex = 0;

u282.style.cursor = 'pointer';
$axure.eventManager.click('u282', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用上线.html');

}
});
gv_vAlignTable['u282'] = 'top';gv_vAlignTable['u123'] = 'center';u278.tabIndex = 0;

u278.style.cursor = 'pointer';
$axure.eventManager.click('u278', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u278'] = 'top';gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u254'] = 'top';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u303'] = 'center';gv_vAlignTable['u281'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u253'] = 'top';document.getElementById('u302_img').tabIndex = 0;

u302.style.cursor = 'pointer';
$axure.eventManager.click('u302', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
u280.tabIndex = 0;

u280.style.cursor = 'pointer';
$axure.eventManager.click('u280', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u280'] = 'top';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u316'] = 'top';u294.tabIndex = 0;

u294.style.cursor = 'pointer';
$axure.eventManager.click('u294', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u294'] = 'top';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u171'] = 'center';u266.tabIndex = 0;

u266.style.cursor = 'pointer';
$axure.eventManager.click('u266', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u266'] = 'top';gv_vAlignTable['u239'] = 'center';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u315'] = 'top';u293.tabIndex = 0;

u293.style.cursor = 'pointer';
$axure.eventManager.click('u293', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u293'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u251'] = 'top';gv_vAlignTable['u314'] = 'top';u292.tabIndex = 0;

u292.style.cursor = 'pointer';
$axure.eventManager.click('u292', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发文档发布.html');

}
});
gv_vAlignTable['u292'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u133'] = 'center';gv_vAlignTable['u250'] = 'center';gv_vAlignTable['u147'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u213'] = 'center';gv_vAlignTable['u191'] = 'center';gv_vAlignTable['u119'] = 'center';u263.tabIndex = 0;

u263.style.cursor = 'pointer';
$axure.eventManager.click('u263', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u263'] = 'top';gv_vAlignTable['u91'] = 'center';u277.tabIndex = 0;

u277.style.cursor = 'pointer';
$axure.eventManager.click('u277', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u277'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u131'] = 'center';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	SetPanelVisibility('u222','','none',500);

}
});
gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u262'] = 'top';u276.tabIndex = 0;

u276.style.cursor = 'pointer';
$axure.eventManager.click('u276', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u276'] = 'top';gv_vAlignTable['u89'] = 'center';document.getElementById('u249_img').tabIndex = 0;

u249.style.cursor = 'pointer';
$axure.eventManager.click('u249', function(e) {

if (true) {

	SetPanelVisibility('u237','hidden','none',500);

}
});
gv_vAlignTable['u211'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u261'] = 'center';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u43'] = 'center';u275.tabIndex = 0;

u275.style.cursor = 'pointer';
$axure.eventManager.click('u275', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u275'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u248'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u224'] = 'center';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u189'] = 'center';gv_vAlignTable['u35'] = 'center';u274.tabIndex = 0;

u274.style.cursor = 'pointer';
$axure.eventManager.click('u274', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u274'] = 'top';gv_vAlignTable['u227'] = 'top';u273.tabIndex = 0;

u273.style.cursor = 'pointer';
$axure.eventManager.click('u273', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u273'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u311'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u209'] = 'center';u272.tabIndex = 0;

u272.style.cursor = 'pointer';
$axure.eventManager.click('u272', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u272'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u221'] = 'center';gv_vAlignTable['u232'] = 'center';gv_vAlignTable['u235'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u13'] = 'center';u271.tabIndex = 0;

u271.style.cursor = 'pointer';
$axure.eventManager.click('u271', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u271'] = 'top';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u31'] = 'center';document.getElementById('u234_img').tabIndex = 0;

u234.style.cursor = 'pointer';
$axure.eventManager.click('u234', function(e) {

if (true) {

	SetPanelVisibility('u237','','none',500);

}
});
gv_vAlignTable['u73'] = 'center';u270.tabIndex = 0;

u270.style.cursor = 'pointer';
$axure.eventManager.click('u270', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u270'] = 'top';gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u233'] = 'top';gv_vAlignTable['u87'] = 'center';document.getElementById('u247_img').tabIndex = 0;

u247.style.cursor = 'pointer';
$axure.eventManager.click('u247', function(e) {

if (true) {

	SetPanelVisibility('u222','hidden','none',500);

}
});
gv_vAlignTable['u226'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u149'] = 'center';u291.tabIndex = 0;

u291.style.cursor = 'pointer';
$axure.eventManager.click('u291', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u291'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u246'] = 'center';gv_vAlignTable['u219'] = 'center';gv_vAlignTable['u259'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u169'] = 'center';u290.tabIndex = 0;

u290.style.cursor = 'pointer';
$axure.eventManager.click('u290', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u290'] = 'top';gv_vAlignTable['u187'] = 'center';document.getElementById('u38_img').tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	SetPanelState('u222', 'pd0u222','none','',500,'none','',500);

}
});
document.getElementById('u245_img').tabIndex = 0;

u245.style.cursor = 'pointer';
$axure.eventManager.click('u245', function(e) {

if (true) {

	SetPanelVisibility('u237','hidden','none',500);

}
});
gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u244'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u257'] = 'top';gv_vAlignTable['u69'] = 'center';u289.tabIndex = 0;

u289.style.cursor = 'pointer';
$axure.eventManager.click('u289', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u289'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u256'] = 'center';u288.tabIndex = 0;

u288.style.cursor = 'pointer';
$axure.eventManager.click('u288', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u288'] = 'top';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u179'] = 'center';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u197'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u23'] = 'center';u264.tabIndex = 0;

u264.style.cursor = 'pointer';
$axure.eventManager.click('u264', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u195'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u153'] = 'center';