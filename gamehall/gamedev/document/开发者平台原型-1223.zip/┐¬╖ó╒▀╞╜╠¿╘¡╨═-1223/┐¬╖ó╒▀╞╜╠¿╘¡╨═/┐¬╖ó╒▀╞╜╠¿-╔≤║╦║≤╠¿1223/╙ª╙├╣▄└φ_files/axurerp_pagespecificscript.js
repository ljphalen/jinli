﻿for(var i = 0; i < 379; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u167'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核信息.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u231'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u298'] = 'center';gv_vAlignTable['u139'] = 'center';gv_vAlignTable['u201'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u215'] = 'center';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u332'] = 'center';gv_vAlignTable['u151'] = 'center';gv_vAlignTable['u346'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u165'] = 'center';u378.tabIndex = 0;

u378.style.cursor = 'pointer';
$axure.eventManager.click('u378', function(e) {

if (true) {

	SetPanelVisibility('u192','','none',500);

}
});
gv_vAlignTable['u378'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u302'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u48'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u318'] = 'center';gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u268'] = 'center';gv_vAlignTable['u330'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u227'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u300'] = 'center';gv_vAlignTable['u63'] = 'top';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_2.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u177'] = 'center';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发文档发布.html');

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u93'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u306'] = 'center';gv_vAlignTable['u284'] = 'center';gv_vAlignTable['u342'] = 'center';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u356'] = 'center';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u229'] = 'center';gv_vAlignTable['u348'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u20'] = 'top';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u241'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u8'] = 'top';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u304'] = 'center';gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u296'] = 'center';gv_vAlignTable['u137'] = 'center';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u213'] = 'center';gv_vAlignTable['u358'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u253'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u280'] = 'center';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u316'] = 'center';gv_vAlignTable['u294'] = 'center';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u266'] = 'center';gv_vAlignTable['u239'] = 'center';gv_vAlignTable['u2'] = 'top';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u251'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u314'] = 'center';gv_vAlignTable['u292'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u133'] = 'center';u369.tabIndex = 0;

u369.style.cursor = 'pointer';
$axure.eventManager.click('u369', function(e) {

if (true) {

	SetPanelState('u367', 'pd1u367','none','',500,'none','',500);

}
});
gv_vAlignTable['u369'] = 'top';gv_vAlignTable['u147'] = 'center';gv_vAlignTable['u58'] = 'center';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u95'] = 'center';u191.tabIndex = 0;

u191.style.cursor = 'pointer';
$axure.eventManager.click('u191', function(e) {

if (true) {

	SetPanelState('u189', 'pd1u189','none','',500,'none','',500);

}
});
gv_vAlignTable['u191'] = 'top';u368.tabIndex = 0;

u368.style.cursor = 'pointer';
$axure.eventManager.click('u368', function(e) {

if (true) {

	SetPanelState('u367', 'pd0u367','none','',500,'none','',500);

}
});
gv_vAlignTable['u368'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u274'] = 'center';gv_vAlignTable['u47'] = 'top';u190.tabIndex = 0;

u190.style.cursor = 'pointer';
$axure.eventManager.click('u190', function(e) {

if (true) {

	SetPanelState('u189', 'pd0u189','none','',500,'none','',500);

}
});
gv_vAlignTable['u190'] = 'top';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u262'] = 'center';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u276'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u249'] = 'center';gv_vAlignTable['u211'] = 'center';gv_vAlignTable['u85'] = 'center';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u44'] = 'center';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u260'] = 'center';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u157'] = 'center';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u328'] = 'center';gv_vAlignTable['u223'] = 'center';gv_vAlignTable['u340'] = 'center';gv_vAlignTable['u237'] = 'center';u188.tabIndex = 0;

u188.style.cursor = 'pointer';
$axure.eventManager.click('u188', function(e) {

if (true) {

	SetPanelState('u186', 'pd1u186','none','',500,'none','',500);

}
});
gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u354'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u6'] = 'center';u372.tabIndex = 0;

u372.style.cursor = 'pointer';
$axure.eventManager.click('u372', function(e) {

if (true) {

	SetPanelState('u370', 'pd1u370','none','',500,'none','',500);

}
});
gv_vAlignTable['u372'] = 'top';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u36'] = 'top';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u209'] = 'center';gv_vAlignTable['u272'] = 'center';gv_vAlignTable['u336'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u308'] = 'center';gv_vAlignTable['u221'] = 'center';gv_vAlignTable['u235'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u352'] = 'center';gv_vAlignTable['u312'] = 'center';gv_vAlignTable['u366'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u117'] = 'center';u31.tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u270'] = 'center';gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u338'] = 'center';gv_vAlignTable['u322'] = 'center';gv_vAlignTable['u233'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u350'] = 'center';gv_vAlignTable['u247'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u364'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u219'] = 'center';u377.tabIndex = 0;

u377.style.cursor = 'pointer';
$axure.eventManager.click('u377', function(e) {

if (true) {

	SetPanelVisibility('u192','hidden','none',500);

}
});
gv_vAlignTable['u377'] = 'top';document.getElementById('u57_img').tabIndex = 0;

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u290'] = 'center';u187.tabIndex = 0;

u187.style.cursor = 'pointer';
$axure.eventManager.click('u187', function(e) {

if (true) {

	SetPanelState('u186', 'pd0u186','none','',500,'none','',500);

}
});
gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u326'] = 'center';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u362'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u286'] = 'center';gv_vAlignTable['u127'] = 'center';u375.tabIndex = 0;

u375.style.cursor = 'pointer';
$axure.eventManager.click('u375', function(e) {

if (true) {

	SetPanelVisibility('u192','','none',500);

}
});
gv_vAlignTable['u375'] = 'top';u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用上线.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u310'] = 'center';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u324'] = 'center';gv_vAlignTable['u243'] = 'center';gv_vAlignTable['u360'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u45'] = 'top';u374.tabIndex = 0;

u374.style.cursor = 'pointer';
$axure.eventManager.click('u374', function(e) {

if (true) {

	SetPanelVisibility('u192','hidden','none',500);

}
});
gv_vAlignTable['u374'] = 'top';gv_vAlignTable['u344'] = 'center';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u179'] = 'center';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u197'] = 'center';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u39'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u288'] = 'center';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u245'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u264'] = 'center';u371.tabIndex = 0;

u371.style.cursor = 'pointer';
$axure.eventManager.click('u371', function(e) {

if (true) {

	SetPanelState('u370', 'pd0u370','none','',500,'none','',500);

}
});
gv_vAlignTable['u371'] = 'top';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u258'] = 'center';gv_vAlignTable['u320'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u195'] = 'center';gv_vAlignTable['u225'] = 'center';gv_vAlignTable['u334'] = 'center';gv_vAlignTable['u153'] = 'center';