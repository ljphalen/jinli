﻿for(var i = 0; i < 300; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';u243.tabIndex = 0;

u243.style.cursor = 'pointer';
$axure.eventManager.click('u243', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u165'] = 'center';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u299'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u236'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u153'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u151'] = 'center';u256.tabIndex = 0;

u256.style.cursor = 'pointer';
$axure.eventManager.click('u256', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u256'] = 'top';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u229'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u235'] = 'center';u268.tabIndex = 0;

u268.style.cursor = 'pointer';
$axure.eventManager.click('u268', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u268'] = 'top';u259.tabIndex = 0;

u259.style.cursor = 'pointer';
$axure.eventManager.click('u259', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u259'] = 'top';gv_vAlignTable['u11'] = 'center';u270.tabIndex = 0;

u270.style.cursor = 'pointer';
$axure.eventManager.click('u270', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u270'] = 'top';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u238'] = 'center';u242.tabIndex = 0;

u242.style.cursor = 'pointer';
$axure.eventManager.click('u242', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u242'] = 'top';u251.tabIndex = 0;

u251.style.cursor = 'pointer';
$axure.eventManager.click('u251', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核信息.html');

}
});
gv_vAlignTable['u251'] = 'top';gv_vAlignTable['u292'] = 'top';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u241'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u133'] = 'center';gv_vAlignTable['u289'] = 'top';document.getElementById('u34_img').tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('注册审核记录.html'), "");

}
});
gv_vAlignTable['u7'] = 'center';u266.tabIndex = 0;

u266.style.cursor = 'pointer';
$axure.eventManager.click('u266', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u266'] = 'top';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u89'] = 'center';u264.tabIndex = 0;

u264.style.cursor = 'pointer';
$axure.eventManager.click('u264', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u103'] = 'center';u258.tabIndex = 0;

u258.style.cursor = 'pointer';
$axure.eventManager.click('u258', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u258'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u233'] = 'top';gv_vAlignTable['u287'] = 'top';gv_vAlignTable['u276'] = 'center';gv_vAlignTable['u179'] = 'center';u263.tabIndex = 0;

u263.style.cursor = 'pointer';
$axure.eventManager.click('u263', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u263'] = 'top';gv_vAlignTable['u57'] = 'center';u253.tabIndex = 0;

u253.style.cursor = 'pointer';
$axure.eventManager.click('u253', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u253'] = 'top';gv_vAlignTable['u197'] = 'center';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u279'] = 'top';gv_vAlignTable['u231'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u189'] = 'center';gv_vAlignTable['u297'] = 'top';u267.tabIndex = 0;

u267.style.cursor = 'pointer';
$axure.eventManager.click('u267', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u267'] = 'top';document.getElementById('u26_img').tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u225'] = 'center';gv_vAlignTable['u119'] = 'center';u254.tabIndex = 0;

u254.style.cursor = 'pointer';
$axure.eventManager.click('u254', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u254'] = 'top';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u191'] = 'center';gv_vAlignTable['u69'] = 'center';u249.tabIndex = 0;

u249.style.cursor = 'pointer';
$axure.eventManager.click('u249', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u249'] = 'top';u252.tabIndex = 0;

u252.style.cursor = 'pointer';
$axure.eventManager.click('u252', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u252'] = 'top';u265.tabIndex = 0;

u265.style.cursor = 'pointer';
$axure.eventManager.click('u265', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u265'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u219'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u195'] = 'center';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u223'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u221'] = 'center';gv_vAlignTable['u137'] = 'center';u255.tabIndex = 0;

u255.style.cursor = 'pointer';
$axure.eventManager.click('u255', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u255'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u43'] = 'center';u257.tabIndex = 0;

u257.style.cursor = 'pointer';
$axure.eventManager.click('u257', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u257'] = 'top';gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u240'] = 'center';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u298'] = 'top';gv_vAlignTable['u227'] = 'center';gv_vAlignTable['u139'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u193'] = 'center';u269.tabIndex = 0;

u269.style.cursor = 'pointer';
$axure.eventManager.click('u269', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u269'] = 'top';u250.tabIndex = 0;

u250.style.cursor = 'pointer';
$axure.eventManager.click('u250', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u250'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u293'] = 'top';gv_vAlignTable['u260'] = 'top';u273.tabIndex = 0;

u273.style.cursor = 'pointer';
$axure.eventManager.click('u273', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u273'] = 'top';u271.tabIndex = 0;

u271.style.cursor = 'pointer';
$axure.eventManager.click('u271', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发文档发布.html');

}
});
gv_vAlignTable['u271'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u177'] = 'center';gv_vAlignTable['u209'] = 'center';gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u147'] = 'center';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u121'] = 'center';u272.tabIndex = 0;

u272.style.cursor = 'pointer';
$axure.eventManager.click('u272', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u272'] = 'top';gv_vAlignTable['u213'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u111'] = 'center';u261.tabIndex = 0;

u261.style.cursor = 'pointer';
$axure.eventManager.click('u261', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用上线.html');

}
});
gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u284'] = 'top';u262.tabIndex = 0;

u262.style.cursor = 'pointer';
$axure.eventManager.click('u262', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u262'] = 'top';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u129'] = 'center';document.getElementById('u68_img').tabIndex = 0;

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u211'] = 'center';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u1'] = 'center';u245.tabIndex = 0;

u245.style.cursor = 'pointer';
$axure.eventManager.click('u245', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u201'] = 'center';gv_vAlignTable['u199'] = 'center';document.getElementById('u281_img').tabIndex = 0;

u281.style.cursor = 'pointer';
$axure.eventManager.click('u281', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u215'] = 'center';u248.tabIndex = 0;

u248.style.cursor = 'pointer';
$axure.eventManager.click('u248', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u248'] = 'top';document.getElementById('u66_img').tabIndex = 0;

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u291'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u286'] = 'top';gv_vAlignTable['u3'] = 'center';