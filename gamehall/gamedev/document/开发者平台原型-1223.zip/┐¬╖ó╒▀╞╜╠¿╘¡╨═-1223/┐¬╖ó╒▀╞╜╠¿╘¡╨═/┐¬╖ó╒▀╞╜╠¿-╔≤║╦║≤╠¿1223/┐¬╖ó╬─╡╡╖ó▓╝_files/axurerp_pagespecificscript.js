﻿for(var i = 0; i < 256; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u128'] = 'top';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('列表页.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u132'] = 'top';
u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	SetPanelState('u41', 'pd0u41','none','',500,'none','',500);

}
});
u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_2.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u140'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核信息.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u186'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u14'] = 'top';u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用上线.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u122'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u120'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核_1.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u108'] = 'top';u37.tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u238'] = 'top';gv_vAlignTable['u178'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u220'] = 'top';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核记录.html');

}
});
gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u176'] = 'top';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u228'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u164'] = 'top';u31.tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待审核.html');

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u110'] = 'top';
u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	SetPanelState('u41', 'pd0u41','none','',500,'none','',500);

}
});
gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u57'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u66'] = 'top';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试标准.html');

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u218'] = 'top';
u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	SetPanelState('u41', 'pd0u41','none','',500,'none','',500);

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u250'] = 'top';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已上线.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u254'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u252'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u82'] = 'center';u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信发布.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u114'] = 'top';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请资料管理.html');

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u236'] = 'top';gv_vAlignTable['u116'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试记录.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u134'] = 'top';
u255.style.cursor = 'pointer';
$axure.eventManager.click('u255', function(e) {

if (true) {

	SetPanelState('u41', 'pd1u41','none','',500,'none','',500);

	SetPanelState('u41', 'pd2u41','none','',500,'none','',500);

}
});
gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u190'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('密码修改.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u234'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册资料管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u246'] = 'top';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部_1.html');

}
});
gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u86'] = 'top';document.getElementById('u111_img').tabIndex = 0;

u111.style.cursor = 'pointer';
$axure.eventManager.click('u111', function(e) {

if (true) {

	SetPanelState('u41', 'pd1u41','none','',500,'none','',500);

}
});

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelState('u41', 'pd0u41','none','',500,'none','',500);

}
});
gv_vAlignTable['u98'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('测试审核.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u63'] = 'top';
u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelState('u41', 'pd1u41','none','',500,'none','',500);

}
});
gv_vAlignTable['u230'] = 'top';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('审核帐号及权限管理.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u196'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册信息审核.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'top';
u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	SetPanelState('u41', 'pd0u41','none','',500,'none','',500);

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u244'] = 'top';gv_vAlignTable['u90'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册审核记录.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u248'] = 'top';gv_vAlignTable['u224'] = 'top';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('APIKEY.html');

}
});
gv_vAlignTable['u30'] = 'top';
u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	SetPanelState('u41', 'pd0u41','none','',500,'none','',500);

}
});
u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏测试.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u182'] = 'top';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开发者黑名单.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u69'] = 'center';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('已通过.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u194'] = 'top';