﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j),_(c,k,e,f,g,l,m,[_(c,n,e,f,g,o,m,[_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w)]),_(c,x,e,f,g,y,m,[_(c,z,e,f,g,A),_(c,B,e,f,g,C),_(c,D,e,f,g,E)]),_(c,F,e,f,g,G,m,[_(c,p,e,f,g,H),_(c,I,e,f,g,J),_(c,K,e,f,g,L)]),_(c,M,e,f,g,N),_(c,O,e,f,g,P,m,[_(c,p,e,f,g,Q),_(c,R,e,f,g,S),_(c,T,e,f,g,U),_(c,V,e,f,g,W)])]),_(c,X,e,f,g,Y),_(c,Z,e,f,g,ba),_(c,bb,e,f,g,bc,m,[_(c,bd,e,f,g,be),_(c,bf,e,f,g,bg),_(c,n,e,f,g,bh),_(c,bi,e,f,g,bj),_(c,bk,e,f,g,bl)]),_(c,bm,e,f,g,bn),_(c,bo,e,f,g,bp)]);}; 
var b="rootNodes",c="pageName",d="流程2",e="type",f="Wireframe",g="url",h="流程2.html",i="登录",j="登录.html",k="首页",l="首页.html",m="children",n="注册信息审核",o="注册信息审核.html",p="全部",q="全部.html",r="待审核信息",s="待审核信息.html",t="注册审核记录",u="注册审核记录.html",v="注册资料管理",w="注册资料管理.html",x="测试审核",y="测试审核.html",z="列表页",A="列表页.html",B="游戏测试",C="游戏测试.html",D="测试记录",E="测试记录.html",F="应用上线",G="应用上线.html",H="全部_1.html",I="已通过",J="已通过.html",K="已上线",L="已上线.html",M="应用下线",N="应用下线.html",O="APIKEY",P="APIKEY.html",Q="全部_2.html",R="待审核",S="待审核.html",T="审核记录",U="审核记录.html",V="申请资料管理",W="申请资料管理.html",X="审核帐号及权限管理",Y="审核帐号及权限管理.html",Z="应用管理",ba="应用管理.html",bb="开发者平台管理",bc="开发者平台管理.html",bd="开发者黑名单",be="开发者黑名单.html",bf="游戏测试标准",bg="游戏测试标准.html",bh="注册信息审核_1.html",bi="站内信发布",bj="站内信发布.html",bk="开发文档发布",bl="开发文档发布.html",bm="密码修改",bn="密码修改.html",bo="错误提示",bp="错误提示.html";
return _creator();
})();
