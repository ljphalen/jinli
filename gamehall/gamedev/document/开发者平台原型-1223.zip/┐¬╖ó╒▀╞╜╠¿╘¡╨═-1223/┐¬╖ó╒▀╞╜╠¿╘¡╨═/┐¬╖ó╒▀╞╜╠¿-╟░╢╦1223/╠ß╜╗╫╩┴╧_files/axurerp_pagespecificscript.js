﻿for(var i = 0; i < 73; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u45'] = 'top';document.getElementById('u36_img').tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交成功.html');

}
});
gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u20'] = 'center';document.getElementById('u50_img').tabIndex = 0;

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('开发者协议.html'), "");

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'top';u72.tabIndex = 0;

u72.style.cursor = 'pointer';
$axure.eventManager.click('u72', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帮助.html');

}
});
gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u29'] = 'top';