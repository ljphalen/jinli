﻿for(var i = 0; i < 25; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'center';document.getElementById('u11_img').tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('成功.html');

}
});
gv_vAlignTable['u23'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帮助.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u7'] = 'top';