﻿for(var i = 0; i < 24; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u7'] = 'center';