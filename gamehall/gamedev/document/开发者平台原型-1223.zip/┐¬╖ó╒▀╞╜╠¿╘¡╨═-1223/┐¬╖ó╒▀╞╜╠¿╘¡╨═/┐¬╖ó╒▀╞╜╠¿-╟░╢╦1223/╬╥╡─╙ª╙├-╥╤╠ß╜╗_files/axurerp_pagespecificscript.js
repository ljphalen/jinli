﻿for(var i = 0; i < 124; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u86.tabIndex = 0;

u86.style.cursor = 'pointer';
$axure.eventManager.click('u86', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('ftp上传.html');

}
});
gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u53'] = 'top';u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

SetGlobalVariableValue('a', '2');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'top';u112.tabIndex = 0;

u112.style.cursor = 'pointer';
$axure.eventManager.click('u112', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u104'] = 'center';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

SetGlobalVariableValue('a', '1');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u34'] = 'top';u64.tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

SetGlobalVariableValue('a', '2');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('版本详情-其它.html');

}
});
gv_vAlignTable['u19'] = 'top';u49.tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

SetGlobalVariableValue('a', '2');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
u79.tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u79'] = 'top';u81.tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u81'] = 'top';document.getElementById('u108_img').tabIndex = 0;

u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u73'] = 'top';u84.tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';document.getElementById('u106_img').tabIndex = 0;

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

	SetPanelVisibility('u100','hidden','none',500);

}
});
u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

SetGlobalVariableValue('a', '2');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u111'] = 'center';document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	SetPanelVisibility('u87','','none',500);

}
});
u78.tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u96'] = 'center';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', u91Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u91LinksClick'></div>")
var u91LinksClick = document.getElementById('u91LinksClick');
function u91Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u91LinksClick');
}

InsertBeforeEnd(u91LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u91Clicku34c50f7f9d044ec0867a1a3425fb2fa4(event)'>上传成功</div>");
function u91Clicku34c50f7f9d044ec0867a1a3425fb2fa4(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-新应用.html');

	ToggleLinks(e, 'u91LinksClick');
}

InsertBeforeEnd(u91LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u91Clicku0f3ceb9dee9e49dc8d43c95a5bb37c02(event)'>包解析失败</div>");
function u91Clicku0f3ceb9dee9e49dc8d43c95a5bb37c02(e)
{

	SetPanelVisibility('u100','','none',500);

	SetPanelVisibility('u90','hidden','none',500);

	ToggleLinks(e, 'u91LinksClick');
}

InsertBeforeEnd(u91LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u91Clicku94a7c62cdc8d4892a842be8359803b25(event)'>包名已存在</div>");
function u91Clicku94a7c62cdc8d4892a842be8359803b25(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用认领.html');

	ToggleLinks(e, 'u91LinksClick');
}
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u109'] = 'center';u82.tabIndex = 0;

u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'top';document.getElementById('u88_img').tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	SetPanelVisibility('u87','hidden','none',500);

	SetPanelVisibility('u90','','none',500);

}
});
gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

SetGlobalVariableValue('a', '1');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用管理.html');

}
});
gv_vAlignTable['u98'] = 'center';u80.tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u121'] = 'top';