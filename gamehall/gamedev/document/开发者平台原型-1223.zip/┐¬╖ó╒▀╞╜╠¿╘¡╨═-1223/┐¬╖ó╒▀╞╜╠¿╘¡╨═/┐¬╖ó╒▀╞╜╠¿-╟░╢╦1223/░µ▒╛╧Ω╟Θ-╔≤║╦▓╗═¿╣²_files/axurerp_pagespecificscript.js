﻿for(var i = 0; i < 265; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u115'] = 'top';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u207'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u140'] = 'top';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	SetPanelVisibility('u29','','none',500);

}
});
gv_vAlignTable['u229'] = 'top';document.getElementById('u55_img').tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

}
});
gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u186'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u235'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u251'] = 'top';document.getElementById('u62_img').tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

}
});
gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u34'] = 'center';u68.tabIndex = 0;

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u68'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

}
});
gv_vAlignTable['u213'] = 'top';u264.tabIndex = 0;

u264.style.cursor = 'pointer';
$axure.eventManager.click('u264', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u164'] = 'top';gv_vAlignTable['u233'] = 'top';u66.tabIndex = 0;

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u253'] = 'top';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u176'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('ftp上传.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u182'] = 'top';gv_vAlignTable['u249'] = 'top';gv_vAlignTable['u241'] = 'top';gv_vAlignTable['u100'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'center';document.getElementById('u30_img').tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	SetPanelVisibility('u29','hidden','none',500);

	SetPanelVisibility('u32','','none',500);

}
});
gv_vAlignTable['u219'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u223'] = 'top';document.getElementById('u33_img').tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', u33Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u33LinksClick'></div>")
var u33LinksClick = document.getElementById('u33LinksClick');
function u33Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u33LinksClick');
}

InsertBeforeEnd(u33LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u33Clicku2e62ccd8ab344d9ca2e60dde74702a55(event)'>上传成功</div>");
function u33Clicku2e62ccd8ab344d9ca2e60dde74702a55(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-更新版本.html');

	ToggleLinks(e, 'u33LinksClick');
}

InsertBeforeEnd(u33LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u33Clickuce56a2b070de446ea197c0eb703a94e9(event)'>包解析失败</div>");
function u33Clickuce56a2b070de446ea197c0eb703a94e9(e)
{

	SetPanelState('u42', 'pd0u42','none','',500,'none','',500);

	SetPanelVisibility('u32','hidden','none',500);

	ToggleLinks(e, 'u33LinksClick');
}

InsertBeforeEnd(u33LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u33Clickuacfb27d1b451406d938f5f4e31af6895(event)'>包名不匹配</div>");
function u33Clickuacfb27d1b451406d938f5f4e31af6895(e)
{

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	SetPanelVisibility('u32','hidden','none',500);

	ToggleLinks(e, 'u33LinksClick');
}

InsertBeforeEnd(u33LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u33Clicku7d03ed41cb674e499279350c1eafc4ca(event)'>版本低于当前版本</div>");
function u33Clicku7d03ed41cb674e499279350c1eafc4ca(e)
{

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	SetPanelVisibility('u32','hidden','none',500);

	ToggleLinks(e, 'u33LinksClick');
}
gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u255'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u225'] = 'top';gv_vAlignTable['u257'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u227'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u211'] = 'top';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u239'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u177'] = 'top';gv_vAlignTable['u209'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u147'] = 'top';gv_vAlignTable['u163'] = 'top';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u131'] = 'top';document.getElementById('u70_img').tabIndex = 0;

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u259'] = 'top';gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u217'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u183'] = 'top';gv_vAlignTable['u263'] = 'center';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u178'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u49'] = 'top';document.getElementById('u124_img').tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交状态.html');

}
});
gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u237'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u161'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u194'] = 'top';