﻿for(var i = 0; i < 51; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u29'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'top';document.getElementById('u14_img').tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u38'] = 'top';u44.tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u39'] = 'top';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u7'] = 'top';u42.tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u25'] = 'top';document.getElementById('u46_img').tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u20'] = 'top';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（有记录）.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u47'] = 'center';u50.tabIndex = 0;

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u34'] = 'top';