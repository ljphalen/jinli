﻿for(var i = 0; i < 23; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u17'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帮助.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u5'] = 'center';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交资料.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u7'] = 'top';