﻿for(var i = 0; i < 48; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
document.getElementById('u16_img').tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	SetPanelVisibility('u15','hidden','none',500);

	SetPanelVisibility('u18','','none',500);

}
});
gv_vAlignTable['u17'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('ftp上传.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u32'] = 'center';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u13'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u4'] = 'center';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u43'] = 'center';u40.tabIndex = 0;

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u10'] = 'center';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u11'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';document.getElementById('u42_img').tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u24'] = 'center';u46.tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u2'] = 'top';document.getElementById('u19_img').tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', u19Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u19LinksClick'></div>")
var u19LinksClick = document.getElementById('u19LinksClick');
function u19Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u19LinksClick');
}

InsertBeforeEnd(u19LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u19Clickuc4defbc8eeb04d32a0f890b7778e3f9e(event)'>上传成功</div>");
function u19Clickuc4defbc8eeb04d32a0f890b7778e3f9e(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-新应用.html');

	ToggleLinks(e, 'u19LinksClick');
}

InsertBeforeEnd(u19LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u19Clicku98b8a669d7bb4c3b9b99686185f52752(event)'>包解析失败</div>");
function u19Clicku98b8a669d7bb4c3b9b99686185f52752(e)
{

	SetPanelVisibility('u28','','none',500);

	SetPanelVisibility('u18','hidden','none',500);

	ToggleLinks(e, 'u19LinksClick');
}

InsertBeforeEnd(u19LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u19Clicku0b74444e2e55433b905cac5e427acdc9(event)'>包名已存在</div>");
function u19Clicku0b74444e2e55433b905cac5e427acdc9(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用认领.html');

	ToggleLinks(e, 'u19LinksClick');
}
gv_vAlignTable['u20'] = 'center';document.getElementById('u5_img').tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	SetPanelVisibility('u15','','none',500);

}
});
gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'top';document.getElementById('u34_img').tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	SetPanelVisibility('u28','hidden','none',500);

}
});
