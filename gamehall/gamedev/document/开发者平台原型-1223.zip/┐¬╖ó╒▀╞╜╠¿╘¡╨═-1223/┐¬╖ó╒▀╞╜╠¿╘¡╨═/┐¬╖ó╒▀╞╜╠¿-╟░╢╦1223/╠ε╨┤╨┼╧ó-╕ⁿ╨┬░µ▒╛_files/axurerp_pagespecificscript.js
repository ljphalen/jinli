﻿for(var i = 0; i < 345; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u167'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u333'] = 'center';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u298'] = 'top';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u193'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u319'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u236'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u331'] = 'top';gv_vAlignTable['u321'] = 'center';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u287'] = 'center';gv_vAlignTable['u48'] = 'top';document.getElementById('u340_img').tabIndex = 0;

u340.style.cursor = 'pointer';
$axure.eventManager.click('u340', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u268'] = 'top';gv_vAlignTable['u330'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u163'] = 'top';gv_vAlignTable['u326'] = 'top';gv_vAlignTable['u177'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u46'] = 'top';
u307.style.cursor = 'pointer';
$axure.eventManager.click('u307', function(e) {

if (true) {

	SetPanelState('u25', 'pd0u25','none','',500,'none','',500);

}
});
gv_vAlignTable['u285'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u306'] = 'top';gv_vAlignTable['u284'] = 'center';
u125.style.cursor = 'pointer';
$axure.eventManager.click('u125', function(e) {

if (true) {

	SetPanelState('u25', 'pd1u25','none','',500,'none','',500);

}
});
gv_vAlignTable['u161'] = 'top';gv_vAlignTable['u329'] = 'top';gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u148'] = 'top';
u305.style.cursor = 'pointer';
$axure.eventManager.click('u305', function(e) {

if (true) {

	SetPanelState('u25', 'pd1u25','none','',500,'none','',500);

}
});
gv_vAlignTable['u124'] = 'top';document.getElementById('u279_img').tabIndex = 0;

u279.style.cursor = 'pointer';
$axure.eventManager.click('u279', function(e) {

if (true) {

}
});
gv_vAlignTable['u228'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u304'] = 'top';gv_vAlignTable['u282'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u296'] = 'top';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u254'] = 'center';gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u343'] = 'center';gv_vAlignTable['u303'] = 'top';gv_vAlignTable['u281'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u317'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u109'] = 'top';document.getElementById('u253_img').tabIndex = 0;

u253.style.cursor = 'pointer';
$axure.eventManager.click('u253', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交状态.html');

}
});
gv_vAlignTable['u302'] = 'center';gv_vAlignTable['u280'] = 'center';u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	NewTab('#', "");

}
});
gv_vAlignTable['u121'] = 'top';u294.tabIndex = 0;

u294.style.cursor = 'pointer';
$axure.eventManager.click('u294', function(e) {

if (true) {

	NewTab('#', "");

}
});
gv_vAlignTable['u294'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u252'] = 'center';gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u266'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u315'] = 'top';gv_vAlignTable['u293'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u238'] = 'top';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u314'] = 'top';gv_vAlignTable['u292'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u250'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u90'] = 'top';document.getElementById('u80_img').tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交状态.html');

}
});
gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u327'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u274'] = 'top';gv_vAlignTable['u277'] = 'center';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u262'] = 'top';u322.tabIndex = 0;

u322.style.cursor = 'pointer';
$axure.eventManager.click('u322', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u322'] = 'top';gv_vAlignTable['u131'] = 'top';document.getElementById('u276_img').tabIndex = 0;

u276.style.cursor = 'pointer';
$axure.eventManager.click('u276', function(e) {

if (true) {

}
});
gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u275'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u248'] = 'top';gv_vAlignTable['u210'] = 'top';u325.tabIndex = 0;

u325.style.cursor = 'pointer';
$axure.eventManager.click('u325', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u325'] = 'top';document.getElementById('u107_img').tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u224'] = 'top';gv_vAlignTable['u341'] = 'center';gv_vAlignTable['u260'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u157'] = 'top';gv_vAlignTable['u328'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u6'] = 'center';
u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

	SetPanelState('u25', 'pd0u25','none','',500,'none','',500);

}
});
gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u272'] = 'top';gv_vAlignTable['u64'] = 'top';u336.tabIndex = 0;

u336.style.cursor = 'pointer';
$axure.eventManager.click('u336', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u336'] = 'top';document.getElementById('u104_img').tabIndex = 0;

u104.style.cursor = 'pointer';
$axure.eventManager.click('u104', function(e) {

if (true) {

}
});
gv_vAlignTable['u308'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u234'] = 'top';gv_vAlignTable['u270'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u92'] = 'top';u338.tabIndex = 0;

u338.style.cursor = 'pointer';
$axure.eventManager.click('u338', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u338'] = 'top';gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u313'] = 'top';gv_vAlignTable['u291'] = 'top';gv_vAlignTable['u246'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u259'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u312'] = 'top';gv_vAlignTable['u290'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u311'] = 'top';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u186'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u244'] = 'top';gv_vAlignTable['u27'] = 'center';document.getElementById('u83_img').tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelVisibility('u82','hidden','none',500);

}
});
gv_vAlignTable['u310'] = 'top';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u40'] = 'top';u324.tabIndex = 0;

u324.style.cursor = 'pointer';
$axure.eventManager.click('u324', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u324'] = 'top';gv_vAlignTable['u257'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u289'] = 'center';gv_vAlignTable['u206'] = 'top';u323.tabIndex = 0;

u323.style.cursor = 'pointer';
$axure.eventManager.click('u323', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u323'] = 'top';gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u96'] = 'top';u344.tabIndex = 0;

u344.style.cursor = 'pointer';
$axure.eventManager.click('u344', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u344'] = 'top';document.getElementById('u256_img').tabIndex = 0;

u256.style.cursor = 'pointer';
$axure.eventManager.click('u256', function(e) {

if (true) {

	SetPanelVisibility('u255','hidden','none',500);

}
});
gv_vAlignTable['u183'] = 'top';gv_vAlignTable['u179'] = 'center';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u335'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u258'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u102'] = 'top';