﻿for(var i = 0; i < 84; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u2'] = 'top';u83.tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u83'] = 'top';document.getElementById('u22_img').tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u47'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u82'] = 'center';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u57'] = 'top';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u80'] = 'top';