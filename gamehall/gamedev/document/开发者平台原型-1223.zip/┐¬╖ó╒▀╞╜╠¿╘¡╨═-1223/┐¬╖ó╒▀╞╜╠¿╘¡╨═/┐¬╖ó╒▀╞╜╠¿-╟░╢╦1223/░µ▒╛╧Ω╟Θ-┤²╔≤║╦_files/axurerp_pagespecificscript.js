﻿for(var i = 0; i < 265; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u21'] = 'center';u264.tabIndex = 0;

u264.style.cursor = 'pointer';
$axure.eventManager.click('u264', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u207'] = 'top';u79.tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u135'] = 'center';document.getElementById('u151_img').tabIndex = 0;

u151.style.cursor = 'pointer';
$axure.eventManager.click('u151', function(e) {

if (true) {

	SetPanelVisibility('u146','hidden','none',500);

}
});
gv_vAlignTable['u42'] = 'top';document.getElementById('u159_img').tabIndex = 0;

u159.style.cursor = 'pointer';
$axure.eventManager.click('u159', function(e) {

if (true) {

	SetPanelVisibility('u146','hidden','none',500);

}
});
gv_vAlignTable['u229'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u186'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u235'] = 'top';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u251'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u34'] = 'center';document.getElementById('u68_img').tabIndex = 0;

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交状态.html');

}
});
gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u233'] = 'top';gv_vAlignTable['u44'] = 'top';u78.tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u253'] = 'top';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u125'] = 'center';u172.tabIndex = 0;

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u26'] = 'top';document.getElementById('u174_img').tabIndex = 0;

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u182'] = 'top';gv_vAlignTable['u249'] = 'top';gv_vAlignTable['u241'] = 'top';u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('ftp上传.html');

}
});
gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u219'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u116'] = 'top';document.getElementById('u74_img').tabIndex = 0;

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	SetPanelVisibility('u133','','none',500);

}
});
gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u160'] = 'center';document.getElementById('u166_img').tabIndex = 0;

u166.style.cursor = 'pointer';
$axure.eventManager.click('u166', function(e) {

if (true) {

}
});
gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u255'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u225'] = 'top';gv_vAlignTable['u257'] = 'top';gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u227'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u259'] = 'top';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u211'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u239'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u63'] = 'top';u170.tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u170'] = 'top';document.getElementById('u134_img').tabIndex = 0;

u134.style.cursor = 'pointer';
$axure.eventManager.click('u134', function(e) {

if (true) {

	SetPanelVisibility('u133','hidden','none',500);

	SetPanelVisibility('u136','','none',500);

}
});
u81.tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u177'] = 'center';gv_vAlignTable['u209'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u162'] = 'center';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u217'] = 'top';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u183'] = 'top';gv_vAlignTable['u263'] = 'center';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u178'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u49'] = 'top';u80.tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u237'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u215'] = 'top';document.getElementById('u137_img').tabIndex = 0;

u137.style.cursor = 'pointer';
$axure.eventManager.click('u137', u137Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u137LinksClick'></div>")
var u137LinksClick = document.getElementById('u137LinksClick');
function u137Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u137LinksClick');
}

InsertBeforeEnd(u137LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u137Clickua0e2c385e0bd48dea77d37c3ad2bedac(event)'>上传成功</div>");
function u137Clickua0e2c385e0bd48dea77d37c3ad2bedac(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-更新版本.html');

	ToggleLinks(e, 'u137LinksClick');
}

InsertBeforeEnd(u137LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u137Clicku74bdc2fed622452abefb3c996b259ff6(event)'>包解析失败</div>");
function u137Clicku74bdc2fed622452abefb3c996b259ff6(e)
{

	SetPanelState('u146', 'pd0u146','none','',500,'none','',500);

	SetPanelVisibility('u136','hidden','none',500);

	ToggleLinks(e, 'u137LinksClick');
}

InsertBeforeEnd(u137LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u137Clicku0397a5c910784aa6b2dad5d9d12c3649(event)'>包名不匹配</div>");
function u137Clicku0397a5c910784aa6b2dad5d9d12c3649(e)
{

	SetPanelState('u146', 'pd1u146','none','',500,'none','',500);

	SetPanelVisibility('u136','hidden','none',500);

	ToggleLinks(e, 'u137LinksClick');
}

InsertBeforeEnd(u137LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u137Clicku0e4afe51fb7a451bb8a04f03c882d85d(event)'>版本低于当前版本</div>");
function u137Clicku0e4afe51fb7a451bb8a04f03c882d85d(e)
{

	SetPanelState('u146', 'pd2u146','none','',500,'none','',500);

	SetPanelVisibility('u136','hidden','none',500);

	ToggleLinks(e, 'u137LinksClick');
}
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u194'] = 'top';