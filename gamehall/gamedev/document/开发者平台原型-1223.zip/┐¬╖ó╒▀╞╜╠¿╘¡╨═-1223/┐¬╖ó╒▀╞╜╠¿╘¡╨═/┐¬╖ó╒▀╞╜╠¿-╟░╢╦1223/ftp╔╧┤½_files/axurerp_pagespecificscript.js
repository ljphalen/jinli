﻿for(var i = 0; i < 53; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u31.tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u31'] = 'top';document.getElementById('u36_img').tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', u36Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u36LinksClick'></div>")
var u36LinksClick = document.getElementById('u36LinksClick');
function u36Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u36LinksClick');
}

InsertBeforeEnd(u36LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u36Clicku0d0c930541ae46a39f601ea9d43b49b3(event)'>上传应用</div>");
function u36Clicku0d0c930541ae46a39f601ea9d43b49b3(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-新应用.html');

	ToggleLinks(e, 'u36LinksClick');
}

InsertBeforeEnd(u36LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u36Clickue09b85f2e4564983b34700c468f27d85(event)'>更新版本</div>");
function u36Clickue09b85f2e4564983b34700c468f27d85(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-更新版本.html');

	ToggleLinks(e, 'u36LinksClick');
}
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u8'] = 'top';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u6'] = 'top';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u38'] = 'top';u43.tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';u41.tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u46'] = 'center';u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	SetPanelState('u7', 'pd1u7','none','',500,'none','',500);

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u49'] = 'top';u51.tabIndex = 0;

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', u51Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u51LinksClick'></div>")
var u51LinksClick = document.getElementById('u51LinksClick');
function u51Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u51LinksClick');
}

InsertBeforeEnd(u51LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u51Clicku37083d0923a74b04b54f4b63ace52241(event)'>已获取</div>");
function u51Clicku37083d0923a74b04b54f4b63ace52241(e)
{

	SetPanelState('u17', 'pd0u17','none','',500,'none','',500);

	ToggleLinks(e, 'u51LinksClick');
}

InsertBeforeEnd(u51LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u51Clicku9377250572374ad1bc43a859b418df07(event)'>获取失败</div>");
function u51Clicku9377250572374ad1bc43a859b418df07(e)
{

	SetPanelState('u17', 'pd1u17','none','',500,'none','',500);

	ToggleLinks(e, 'u51LinksClick');
}

InsertBeforeEnd(u51LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u51Clicku39e5781eb140418f97fbb6fa60602927(event)'>包名称不匹配</div>");
function u51Clicku39e5781eb140418f97fbb6fa60602927(e)
{

	SetPanelState('u17', 'pd2u17','none','',500,'none','',500);

	ToggleLinks(e, 'u51LinksClick');
}

InsertBeforeEnd(u51LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u51Clicku528b2089a90046d09c8bc7f8a0da85d9(event)'>版本过低</div>");
function u51Clicku528b2089a90046d09c8bc7f8a0da85d9(e)
{

	SetPanelState('u17', 'pd3u17','none','',500,'none','',500);

	ToggleLinks(e, 'u51LinksClick');
}
gv_vAlignTable['u51'] = 'top';document.getElementById('u45_img').tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
u52.tabIndex = 0;

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u52'] = 'top';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u33'] = 'top';