﻿for(var i = 0; i < 24; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u12'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-未提交.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u11'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帮助.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u13'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('申请Key.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u7'] = 'center';