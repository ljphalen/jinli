﻿for(var i = 0; i < 131; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if ((GetGlobalVariableValue('a')) == ('1')) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('a')) == ('2')) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}

});
document.getElementById('u51_img').tabIndex = 0;
HookClick('u51', false);

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('版本详情-已上线.html');

}
});
u113.tabIndex = 0;

u113.style.cursor = 'pointer';
$axure.eventManager.click('u113', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u25'] = 'top';document.getElementById('u16_img').tabIndex = 0;
HookClick('u16', false);

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('版本详情-审核不通过.html');

}
});
gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u80'] = 'center';u107.tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u107'] = 'top';u102.tabIndex = 0;

u102.style.cursor = 'pointer';
$axure.eventManager.click('u102', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('ftp上传.html');

}
});
gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u62'] = 'top';document.getElementById('u53_img').tabIndex = 0;
HookClick('u53', false);

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('版本详情-已下线.html');

}
});
gv_vAlignTable['u36'] = 'top';u119.tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u38'] = 'center';document.getElementById('u115_img').tabIndex = 0;

u115.style.cursor = 'pointer';
$axure.eventManager.click('u115', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u64'] = 'top';document.getElementById('u100_img').tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	SetPanelVisibility('u65','','none',500);

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u15'] = 'top';document.getElementById('u66_img').tabIndex = 0;

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	SetPanelVisibility('u65','hidden','none',500);

	SetPanelVisibility('u68','','none',500);

}
});
gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u92'] = 'center';document.getElementById('u83_img').tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelVisibility('u78','hidden','none',500);

}
});
document.getElementById('u98_img').tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	SetPanelVisibility('u78','hidden','none',500);

}
});
gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u50'] = 'top';u106.tabIndex = 0;

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u14'] = 'center';u111.tabIndex = 0;

u111.style.cursor = 'pointer';
$axure.eventManager.click('u111', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u111'] = 'top';document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', u69Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u69LinksClick'></div>")
var u69LinksClick = document.getElementById('u69LinksClick');
function u69Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u69LinksClick');
}

InsertBeforeEnd(u69LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u69Clickuc4e1b52c78a548bd816d9f589779a681(event)'>上传成功</div>");
function u69Clickuc4e1b52c78a548bd816d9f589779a681(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('填写信息-新应用.html');

	ToggleLinks(e, 'u69LinksClick');
}

InsertBeforeEnd(u69LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u69Clicku5869bf8a149d46b698dda14f655c3fbf(event)'>包解析失败</div>");
function u69Clicku5869bf8a149d46b698dda14f655c3fbf(e)
{

	SetPanelState('u78', 'pd0u78','none','',500,'none','',500);

	SetPanelVisibility('u68','hidden','none',500);

	ToggleLinks(e, 'u69LinksClick');
}

InsertBeforeEnd(u69LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u69Clicku9f04c66ea9734514b110b39af6a24f89(event)'>包名不匹配</div>");
function u69Clicku9f04c66ea9734514b110b39af6a24f89(e)
{

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

	SetPanelVisibility('u68','hidden','none',500);

	ToggleLinks(e, 'u69LinksClick');
}

InsertBeforeEnd(u69LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u69Clicku32f73de51d84434485e631e4daf3e70c(event)'>版本低于当前版本</div>");
function u69Clicku32f73de51d84434485e631e4daf3e70c(e)
{

	SetPanelState('u78', 'pd2u78','none','',500,'none','',500);

	SetPanelVisibility('u68','hidden','none',500);

	ToggleLinks(e, 'u69LinksClick');
}
u105.tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'top';document.getElementById('u26_img').tabIndex = 0;
HookClick('u26', false);

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('版本详情-待审核.html');

}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u84'] = 'center';document.getElementById('u9_img').tabIndex = 0;
HookClick('u9', false);

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('版本详情-审核中.html');

}
});
gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u39'] = 'top';u108.tabIndex = 0;

u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u108'] = 'top';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

	SetPanelVisibility('u78','hidden','none',500);

}
});
