﻿for(var i = 0; i < 346; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if ((GetGlobalVariableValue('x')) == ('1')) {

}

if ((GetGlobalVariableValue('x')) == ('2')) {

}

});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u194'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u298'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u332'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u302'] = 'center';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u67'] = 'top';document.getElementById('u269_img').tabIndex = 0;

u269.style.cursor = 'pointer';
$axure.eventManager.click('u269', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交状态.html');

}
});
u331.tabIndex = 0;

u331.style.cursor = 'pointer';
$axure.eventManager.click('u331', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u331'] = 'top';gv_vAlignTable['u321'] = 'center';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u287'] = 'top';gv_vAlignTable['u48'] = 'top';u345.tabIndex = 0;

u345.style.cursor = 'pointer';
$axure.eventManager.click('u345', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u345'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u65'] = 'top';document.getElementById('u318_img').tabIndex = 0;

u318.style.cursor = 'pointer';
$axure.eventManager.click('u318', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-未提交.html');

}
});
gv_vAlignTable['u268'] = 'center';u330.tabIndex = 0;

u330.style.cursor = 'pointer';
$axure.eventManager.click('u330', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u330'] = 'top';gv_vAlignTable['u227'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u344'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u307'] = 'top';gv_vAlignTable['u285'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u306'] = 'top';gv_vAlignTable['u342'] = 'center';u329.tabIndex = 0;

u329.style.cursor = 'pointer';
$axure.eventManager.click('u329', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u329'] = 'top';gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u229'] = 'top';document.getElementById('u148_img').tabIndex = 0;

u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if (true) {

	SetPanelVisibility('u147','hidden','none',500);

}
});
gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u305'] = 'top';gv_vAlignTable['u283'] = 'top';gv_vAlignTable['u279'] = 'top';gv_vAlignTable['u241'] = 'top';gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u297'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u304'] = 'top';gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u33'] = 'top';document.getElementById('u173_img').tabIndex = 0;

u173.style.cursor = 'pointer';
$axure.eventManager.click('u173', function(e) {

if (true) {

}
});
gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u303'] = 'top';gv_vAlignTable['u281'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u317'] = 'center';gv_vAlignTable['u295'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u253'] = 'top';gv_vAlignTable['u46'] = 'top';document.getElementById('u316_img').tabIndex = 0;

u316.style.cursor = 'pointer';
$axure.eventManager.click('u316', function(e) {

if (true) {

	SetPanelVisibility('u310','hidden','none',500);

}
});
gv_vAlignTable['u294'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u266'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u239'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u315'] = 'top';gv_vAlignTable['u293'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u251'] = 'top';document.getElementById('u170_img').tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

	SetPanelVisibility('u276','','none',500);

}
});
gv_vAlignTable['u265'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u314'] = 'center';gv_vAlignTable['u77'] = 'top';document.getElementById('u145_img').tabIndex = 0;

u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('提交状态.html');

}
});
gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u164'] = 'top';
u213.style.cursor = 'pointer';
$axure.eventManager.click('u213', function(e) {

if (true) {

	SetPanelState('u30', 'pd1u30','none','',500,'none','',500);

}
});
gv_vAlignTable['u327'] = 'center';gv_vAlignTable['u146'] = 'center';document.getElementById('u274_img').tabIndex = 0;

u274.style.cursor = 'pointer';
$axure.eventManager.click('u274', function(e) {

if (true) {

}
});
document.getElementById('u277_img').tabIndex = 0;

u277.style.cursor = 'pointer';
$axure.eventManager.click('u277', function(e) {

if (true) {

	SetPanelVisibility('u273','','none',500);

	SetPanelVisibility('u276','hidden','none',500);

}
});
gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u262'] = 'top';gv_vAlignTable['u249'] = 'top';
u211.style.cursor = 'pointer';
$axure.eventManager.click('u211', function(e) {

if (true) {

	SetPanelState('u30', 'pd0u30','none','',500,'none','',500);

}
});
gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u275'] = 'center';gv_vAlignTable['u210'] = 'center';gv_vAlignTable['u44'] = 'top';document.getElementById('u341_img').tabIndex = 0;

u341.style.cursor = 'pointer';
$axure.eventManager.click('u341', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('站内信.html');

}
});
gv_vAlignTable['u260'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u309'] = 'top';u328.tabIndex = 0;

u328.style.cursor = 'pointer';
$axure.eventManager.click('u328', function(e) {

if (true) {

	SetPanelVisibility('u310','','none',500);

}
});
gv_vAlignTable['u328'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u237'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u272'] = 'center';gv_vAlignTable['u336'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u104'] = 'top';u308.tabIndex = 0;

u308.style.cursor = 'pointer';
$axure.eventManager.click('u308', function(e) {

if (true) {

	NewTab('#', "");

}
});
gv_vAlignTable['u308'] = 'top';gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u235'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u208'] = 'top';document.getElementById('u271_img').tabIndex = 0;

u271.style.cursor = 'pointer';
$axure.eventManager.click('u271', function(e) {

if (true) {

	SetPanelVisibility('u276','','none',500);

}
});
gv_vAlignTable['u312'] = 'center';gv_vAlignTable['u98'] = 'top';u339.tabIndex = 0;

u339.style.cursor = 'pointer';
$axure.eventManager.click('u339', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u339'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u270'] = 'center';
u199.style.cursor = 'pointer';
$axure.eventManager.click('u199', function(e) {

if (true) {

	SetPanelState('u30', 'pd1u30','none','',500,'none','',500);

}
});
gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u300'] = 'center';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u186'] = 'top';gv_vAlignTable['u233'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u319'] = 'center';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u219'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u169'] = 'top';u187.tabIndex = 0;

u187.style.cursor = 'pointer';
$axure.eventManager.click('u187', function(e) {

if (true) {

	NewTab('#', "");

}
});
gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u325'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u324'] = 'top';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u289'] = 'top';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u323'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u291'] = 'top';u337.tabIndex = 0;

u337.style.cursor = 'pointer';
$axure.eventManager.click('u337', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u337'] = 'top';gv_vAlignTable['u256'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u179'] = 'top';
u197.style.cursor = 'pointer';
$axure.eventManager.click('u197', function(e) {

if (true) {

	SetPanelState('u30', 'pd0u30','none','',500,'none','',500);

}
});
gv_vAlignTable['u255'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u258'] = 'top';document.getElementById('u320_img').tabIndex = 0;

u320.style.cursor = 'pointer';
$axure.eventManager.click('u320', function(e) {

if (true) {

	SetPanelVisibility('u310','hidden','none',500);

}
});
gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u225'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u334'] = 'center';gv_vAlignTable['u153'] = 'top';