﻿for(var i = 0; i < 230; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u226'] = 'center';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u159'] = 'top';u229.tabIndex = 0;

u229.style.cursor = 'pointer';
$axure.eventManager.click('u229', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('帮助.html'), "");

}
});
gv_vAlignTable['u229'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u186'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u197'] = 'center';u203.tabIndex = 0;

u203.style.cursor = 'pointer';
$axure.eventManager.click('u203', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('游戏联运（无记录）.html');

}
});
gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u153'] = 'top';u202.tabIndex = 0;

u202.style.cursor = 'pointer';
$axure.eventManager.click('u202', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u123'] = 'top';u223.tabIndex = 0;

u223.style.cursor = 'pointer';
$axure.eventManager.click('u223', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('帐户.html');

}
});
gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u166'] = 'top';u221.tabIndex = 0;

u221.style.cursor = 'pointer';
$axure.eventManager.click('u221', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u79'] = 'top';document.getElementById('u225_img').tabIndex = 0;

u225.style.cursor = 'pointer';
$axure.eventManager.click('u225', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u193'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u211'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u164'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u228'] = 'center';gv_vAlignTable['u209'] = 'top';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u162'] = 'center';u204.tabIndex = 0;

u204.style.cursor = 'pointer';
$axure.eventManager.click('u204', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u217'] = 'top';u129.tabIndex = 0;

u129.style.cursor = 'pointer';
$axure.eventManager.click('u129', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u144'] = 'top';u205.tabIndex = 0;

u205.style.cursor = 'pointer';
$axure.eventManager.click('u205', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('SDK下载.html');

}
});
gv_vAlignTable['u205'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u142'] = 'top';u93.tabIndex = 0;

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u201'] = 'center';gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u215'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u220'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u194'] = 'top';