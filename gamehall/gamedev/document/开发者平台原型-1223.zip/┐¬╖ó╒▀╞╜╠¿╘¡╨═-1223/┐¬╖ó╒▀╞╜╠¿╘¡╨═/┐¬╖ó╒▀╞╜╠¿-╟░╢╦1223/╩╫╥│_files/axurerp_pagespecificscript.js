﻿for(var i = 0; i < 46; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'top';document.getElementById('u16_img').tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('忘记密码.html');

}
});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'center';document.getElementById('u7_img').tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('我的应用-已提交.html');

}
});
gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u25'] = 'center';document.getElementById('u18_img').tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册帐户.html');

}
});
gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u0'] = 'top';