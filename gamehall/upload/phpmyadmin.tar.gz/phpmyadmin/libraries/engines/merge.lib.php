<?php
/* $Id: merge.lib.php 8104 2005-12-07 10:49:43Z cybot_tm $ */
// vim: expandtab sw=4 ts=4 sts=4:

class PMA_StorageEngine_merge extends PMA_StorageEngine
{
}

?>
