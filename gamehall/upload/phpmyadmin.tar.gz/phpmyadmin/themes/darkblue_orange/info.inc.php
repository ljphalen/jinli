<?php
/* $Id: info.inc.php 9302 2006-08-14 12:41:29Z cybot_tm $ */
/* Theme information */
$theme_name = 'Darkblue/orange';
$theme_full_version = '2.9';
?>
